from model import *
class ClsUpdateAllDtls:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

	def save_tc_api_token_dtls(self,session,date_created=None,date_used=None,hash=None,id=None,name=None,user_id=None):
		try:    
			query = session.query(TcApiTokenDtl).filter(TcApiTokenDtl.org_id==self.org_id,TcApiTokenDtl.entity_cre_flg==self.entity_cre_flg,TcApiTokenDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcApiTokenDtl.id== id)
			if date_created:	query = query.date_created=date_created
			if date_used:	query = query.date_used=date_used
			if hash:	query = query.hash=hash
			if id:	query = query.id=id
			if name:	query = query.name=name
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_api_token_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_dtls(self,session,bug_text_id=None,build=None,category_id=None,date_submitted=None,due_date=None,duplicate_id=None,eta=None,fixed_in_version=None,handler_id=None,id=None,last_updated=None,os=None,os_build=None,platform=None,priority=None,profile_id=None,project_id=None,projection=None,reporter_id=None,reproducibility=None,resolution=None,severity=None,sponsorship_total=None,status=None,sticky=None,summary=None,target_version=None,version=None,view_state=None):
		try:    
			query = session.query(TcBugDtl).filter(TcBugDtl.org_id==self.org_id,TcBugDtl.entity_cre_flg==self.entity_cre_flg,TcBugDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugDtl.id== id)
			if bug_text_id:	query = query.bug_text_id=bug_text_id
			if build:	query = query.build=build
			if category_id:	query = query.category_id=category_id
			if date_submitted:	query = query.date_submitted=date_submitted
			if due_date:	query = query.due_date=due_date
			if duplicate_id:	query = query.duplicate_id=duplicate_id
			if eta:	query = query.eta=eta
			if fixed_in_version:	query = query.fixed_in_version=fixed_in_version
			if handler_id:	query = query.handler_id=handler_id
			if id:	query = query.id=id
			if last_updated:	query = query.last_updated=last_updated
			if os:	query = query.os=os
			if os_build:	query = query.os_build=os_build
			if platform:	query = query.platform=platform
			if priority:	query = query.priority=priority
			if profile_id:	query = query.profile_id=profile_id
			if project_id:	query = query.project_id=project_id
			if projection:	query = query.projection=projection
			if reporter_id:	query = query.reporter_id=reporter_id
			if reproducibility:	query = query.reproducibility=reproducibility
			if resolution:	query = query.resolution=resolution
			if severity:	query = query.severity=severity
			if sponsorship_total:	query = query.sponsorship_total=sponsorship_total
			if status:	query = query.status=status
			if sticky:	query = query.sticky=sticky
			if summary:	query = query.summary=summary
			if target_version:	query = query.target_version=target_version
			if version:	query = query.version=version
			if view_state:	query = query.view_state=view_state
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_file_dtls(self,session,bug_id=None,bugnote_id=None,content=None,date_added=None,description=None,diskfile=None,file_type=None,filename=None,filesize=None,folder=None,id=None,title=None,user_id=None):
		try:    
			query = session.query(TcBugFileDtl).filter(TcBugFileDtl.org_id==self.org_id,TcBugFileDtl.entity_cre_flg==self.entity_cre_flg,TcBugFileDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugFileDtl.id== id)
			if bug_id:	query = query.bug_id=bug_id
			if bugnote_id:	query = query.bugnote_id=bugnote_id
			if content:	query = query.content=content
			if date_added:	query = query.date_added=date_added
			if description:	query = query.description=description
			if diskfile:	query = query.diskfile=diskfile
			if file_type:	query = query.file_type=file_type
			if filename:	query = query.filename=filename
			if filesize:	query = query.filesize=filesize
			if folder:	query = query.folder=folder
			if id:	query = query.id=id
			if title:	query = query.title=title
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_file_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_history_dtls(self,session,bug_id=None,date_modified=None,field_name=None,id=None,new_value=None,old_value=None,type=None,user_id=None):
		try:    
			query = session.query(TcBugHistoryDtl).filter(TcBugHistoryDtl.org_id==self.org_id,TcBugHistoryDtl.entity_cre_flg==self.entity_cre_flg,TcBugHistoryDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugHistoryDtl.id== id)
			if bug_id:	query = query.bug_id=bug_id
			if date_modified:	query = query.date_modified=date_modified
			if field_name:	query = query.field_name=field_name
			if id:	query = query.id=id
			if new_value:	query = query.new_value=new_value
			if old_value:	query = query.old_value=old_value
			if type:	query = query.type=type
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_history_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_monitor_dtls(self,session,bug_id=None,user_id=None):
		try:    
			query = session.query(TcBugMonitorDtl).filter(TcBugMonitorDtl.org_id==self.org_id,TcBugMonitorDtl.entity_cre_flg==self.entity_cre_flg,TcBugMonitorDtl.del_flg==self.del_flg)
			if bug_id:
				query = query.filter(TcBugMonitorDtl.bug_id== bug_id)
			if user_id:
				query = query.filter(TcBugMonitorDtl.user_id== user_id)
			if bug_id:	query = query.bug_id=bug_id
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_monitor_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_relationship_dtls(self,session,destination_bug_id=None,id=None,relationship_type=None,source_bug_id=None):
		try:    
			query = session.query(TcBugRelationshipDtl).filter(TcBugRelationshipDtl.org_id==self.org_id,TcBugRelationshipDtl.entity_cre_flg==self.entity_cre_flg,TcBugRelationshipDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugRelationshipDtl.id== id)
			if destination_bug_id:	query = query.destination_bug_id=destination_bug_id
			if id:	query = query.id=id
			if relationship_type:	query = query.relationship_type=relationship_type
			if source_bug_id:	query = query.source_bug_id=source_bug_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_relationship_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_revision_dtls(self,session,bug_id=None,bugnote_id=None,id=None,timestamp=None,type=None,user_id=None,value=None):
		try:    
			query = session.query(TcBugRevisionDtl).filter(TcBugRevisionDtl.org_id==self.org_id,TcBugRevisionDtl.entity_cre_flg==self.entity_cre_flg,TcBugRevisionDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugRevisionDtl.id== id)
			if bug_id:	query = query.bug_id=bug_id
			if bugnote_id:	query = query.bugnote_id=bugnote_id
			if id:	query = query.id=id
			if timestamp:	query = query.timestamp=timestamp
			if type:	query = query.type=type
			if user_id:	query = query.user_id=user_id
			if value:	query = query.value=value
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_revision_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_tag_dtls(self,session,bug_id=None,date_attached=None,tag_id=None,user_id=None):
		try:    
			query = session.query(TcBugTagDtl).filter(TcBugTagDtl.org_id==self.org_id,TcBugTagDtl.entity_cre_flg==self.entity_cre_flg,TcBugTagDtl.del_flg==self.del_flg)
			if bug_id:
				query = query.filter(TcBugTagDtl.bug_id== bug_id)
			if tag_id:
				query = query.filter(TcBugTagDtl.tag_id== tag_id)
			if bug_id:	query = query.bug_id=bug_id
			if date_attached:	query = query.date_attached=date_attached
			if tag_id:	query = query.tag_id=tag_id
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_tag_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bug_text_dtls(self,session,additional_information=None,description=None,id=None,steps_to_reproduce=None):
		try:    
			query = session.query(TcBugTextDtl).filter(TcBugTextDtl.org_id==self.org_id,TcBugTextDtl.entity_cre_flg==self.entity_cre_flg,TcBugTextDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugTextDtl.id== id)
			if additional_information:	query = query.additional_information=additional_information
			if description:	query = query.description=description
			if id:	query = query.id=id
			if steps_to_reproduce:	query = query.steps_to_reproduce=steps_to_reproduce
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bug_text_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bugnote_dtls(self,session,bug_id=None,bugnote_text_id=None,date_submitted=None,id=None,last_modified=None,note_attr=None,note_type=None,reporter_id=None,time_tracking=None,view_state=None):
		try:    
			query = session.query(TcBugnoteDtl).filter(TcBugnoteDtl.org_id==self.org_id,TcBugnoteDtl.entity_cre_flg==self.entity_cre_flg,TcBugnoteDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugnoteDtl.id== id)
			if bug_id:	query = query.bug_id=bug_id
			if bugnote_text_id:	query = query.bugnote_text_id=bugnote_text_id
			if date_submitted:	query = query.date_submitted=date_submitted
			if id:	query = query.id=id
			if last_modified:	query = query.last_modified=last_modified
			if note_attr:	query = query.note_attr=note_attr
			if note_type:	query = query.note_type=note_type
			if reporter_id:	query = query.reporter_id=reporter_id
			if time_tracking:	query = query.time_tracking=time_tracking
			if view_state:	query = query.view_state=view_state
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bugnote_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_bugnote_text_dtls(self,session,id=None,note=None):
		try:    
			query = session.query(TcBugnoteTextDtl).filter(TcBugnoteTextDtl.org_id==self.org_id,TcBugnoteTextDtl.entity_cre_flg==self.entity_cre_flg,TcBugnoteTextDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcBugnoteTextDtl.id== id)
			if id:	query = query.id=id
			if note:	query = query.note=note
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_bugnote_text_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_category_dtls(self,session,id=None,name=None,project_id=None,status=None,user_id=None):
		try:    
			query = session.query(TcCategoryDtl).filter(TcCategoryDtl.org_id==self.org_id,TcCategoryDtl.entity_cre_flg==self.entity_cre_flg,TcCategoryDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcCategoryDtl.id== id)
			if id:	query = query.id=id
			if name:	query = query.name=name
			if project_id:	query = query.project_id=project_id
			if status:	query = query.status=status
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_category_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_config_dtls(self,session,access_reqd=None,config_id=None,project_id=None,type=None,user_id=None,value=None):
		try:    
			query = session.query(TcConfigDtl).filter(TcConfigDtl.org_id==self.org_id,TcConfigDtl.entity_cre_flg==self.entity_cre_flg,TcConfigDtl.del_flg==self.del_flg)
			if config_id:
				query = query.filter(TcConfigDtl.config_id== config_id)
			if project_id:
				query = query.filter(TcConfigDtl.project_id== project_id)
			if user_id:
				query = query.filter(TcConfigDtl.user_id== user_id)
			if access_reqd:	query = query.access_reqd=access_reqd
			if config_id:	query = query.config_id=config_id
			if project_id:	query = query.project_id=project_id
			if type:	query = query.type=type
			if user_id:	query = query.user_id=user_id
			if value:	query = query.value=value
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_config_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_custom_field_dtls(self,session,access_level_r=None,access_level_rw=None,default_value=None,display_closed=None,display_report=None,display_resolved=None,display_update=None,filter_by=None,id=None,length_max=None,length_min=None,name=None,possible_values=None,require_closed=None,require_report=None,require_resolved=None,require_update=None,type=None,valid_regexp=None):
		try:    
			query = session.query(TcCustomFieldDtl).filter(TcCustomFieldDtl.org_id==self.org_id,TcCustomFieldDtl.entity_cre_flg==self.entity_cre_flg,TcCustomFieldDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcCustomFieldDtl.id== id)
			if access_level_r:	query = query.access_level_r=access_level_r
			if access_level_rw:	query = query.access_level_rw=access_level_rw
			if default_value:	query = query.default_value=default_value
			if display_closed:	query = query.display_closed=display_closed
			if display_report:	query = query.display_report=display_report
			if display_resolved:	query = query.display_resolved=display_resolved
			if display_update:	query = query.display_update=display_update
			if filter_by:	query = query.filter_by=filter_by
			if id:	query = query.id=id
			if length_max:	query = query.length_max=length_max
			if length_min:	query = query.length_min=length_min
			if name:	query = query.name=name
			if possible_values:	query = query.possible_values=possible_values
			if require_closed:	query = query.require_closed=require_closed
			if require_report:	query = query.require_report=require_report
			if require_resolved:	query = query.require_resolved=require_resolved
			if require_update:	query = query.require_update=require_update
			if type:	query = query.type=type
			if valid_regexp:	query = query.valid_regexp=valid_regexp
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_custom_field_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_custom_field_project_dtls(self,session,field_id=None,project_id=None,sequence=None):
		try:    
			query = session.query(TcCustomFieldProjectDtl).filter(TcCustomFieldProjectDtl.org_id==self.org_id,TcCustomFieldProjectDtl.entity_cre_flg==self.entity_cre_flg,TcCustomFieldProjectDtl.del_flg==self.del_flg)
			if field_id:
				query = query.filter(TcCustomFieldProjectDtl.field_id== field_id)
			if project_id:
				query = query.filter(TcCustomFieldProjectDtl.project_id== project_id)
			if field_id:	query = query.field_id=field_id
			if project_id:	query = query.project_id=project_id
			if sequence:	query = query.sequence=sequence
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_custom_field_project_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_custom_field_string_dtls(self,session,bug_id=None,field_id=None,text=None,value=None):
		try:    
			query = session.query(TcCustomFieldStringDtl).filter(TcCustomFieldStringDtl.org_id==self.org_id,TcCustomFieldStringDtl.entity_cre_flg==self.entity_cre_flg,TcCustomFieldStringDtl.del_flg==self.del_flg)
			if bug_id:
				query = query.filter(TcCustomFieldStringDtl.bug_id== bug_id)
			if field_id:
				query = query.filter(TcCustomFieldStringDtl.field_id== field_id)
			if bug_id:	query = query.bug_id=bug_id
			if field_id:	query = query.field_id=field_id
			if text:	query = query.text=text
			if value:	query = query.value=value
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_custom_field_string_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_email_dtls(self,session,body=None,email=None,email_id=None,metadata_=None,subject=None,submitted=None):
		try:    
			query = session.query(TcEmailDtl).filter(TcEmailDtl.org_id==self.org_id,TcEmailDtl.entity_cre_flg==self.entity_cre_flg,TcEmailDtl.del_flg==self.del_flg)
			if email_id:
				query = query.filter(TcEmailDtl.email_id== email_id)
			if body:	query = query.body=body
			if email:	query = query.email=email
			if email_id:	query = query.email_id=email_id
			if metadata_:	query = query.metadata_=metadata_
			if subject:	query = query.subject=subject
			if submitted:	query = query.submitted=submitted
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_email_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_filters_dtls(self,session,filter_string=None,id=None,is_public=None,name=None,project_id=None,user_id=None):
		try:    
			query = session.query(TcFiltersDtl).filter(TcFiltersDtl.org_id==self.org_id,TcFiltersDtl.entity_cre_flg==self.entity_cre_flg,TcFiltersDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcFiltersDtl.id== id)
			if filter_string:	query = query.filter_string=filter_string
			if id:	query = query.id=id
			if is_public:	query = query.is_public=is_public
			if name:	query = query.name=name
			if project_id:	query = query.project_id=project_id
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_filters_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_news_dtls(self,session,announcement=None,body=None,date_posted=None,headline=None,id=None,last_modified=None,poster_id=None,project_id=None,view_state=None):
		try:    
			query = session.query(TcNewsDtl).filter(TcNewsDtl.org_id==self.org_id,TcNewsDtl.entity_cre_flg==self.entity_cre_flg,TcNewsDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcNewsDtl.id== id)
			if announcement:	query = query.announcement=announcement
			if body:	query = query.body=body
			if date_posted:	query = query.date_posted=date_posted
			if headline:	query = query.headline=headline
			if id:	query = query.id=id
			if last_modified:	query = query.last_modified=last_modified
			if poster_id:	query = query.poster_id=poster_id
			if project_id:	query = query.project_id=project_id
			if view_state:	query = query.view_state=view_state
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_news_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_plugin_dtls(self,session,basename=None,enabled=None,priority=None,protected=None):
		try:    
			query = session.query(TcPluginDtl).filter(TcPluginDtl.org_id==self.org_id,TcPluginDtl.entity_cre_flg==self.entity_cre_flg,TcPluginDtl.del_flg==self.del_flg)
			if basename:
				query = query.filter(TcPluginDtl.basename== basename)
			if basename:	query = query.basename=basename
			if enabled:	query = query.enabled=enabled
			if priority:	query = query.priority=priority
			if protected:	query = query.protected=protected
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_plugin_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_project_dtls(self,session,access_min=None,category_id=None,description=None,enabled=None,file_path=None,id=None,inherit_global=None,name=None,status=None,view_state=None):
		try:    
			query = session.query(TcProjectDtl).filter(TcProjectDtl.org_id==self.org_id,TcProjectDtl.entity_cre_flg==self.entity_cre_flg,TcProjectDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcProjectDtl.id== id)
			if access_min:	query = query.access_min=access_min
			if category_id:	query = query.category_id=category_id
			if description:	query = query.description=description
			if enabled:	query = query.enabled=enabled
			if file_path:	query = query.file_path=file_path
			if id:	query = query.id=id
			if inherit_global:	query = query.inherit_global=inherit_global
			if name:	query = query.name=name
			if status:	query = query.status=status
			if view_state:	query = query.view_state=view_state
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_project_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_project_file_dtls(self,session,content=None,date_added=None,description=None,diskfile=None,file_type=None,filename=None,filesize=None,folder=None,id=None,project_id=None,title=None,user_id=None):
		try:    
			query = session.query(TcProjectFileDtl).filter(TcProjectFileDtl.org_id==self.org_id,TcProjectFileDtl.entity_cre_flg==self.entity_cre_flg,TcProjectFileDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcProjectFileDtl.id== id)
			if content:	query = query.content=content
			if date_added:	query = query.date_added=date_added
			if description:	query = query.description=description
			if diskfile:	query = query.diskfile=diskfile
			if file_type:	query = query.file_type=file_type
			if filename:	query = query.filename=filename
			if filesize:	query = query.filesize=filesize
			if folder:	query = query.folder=folder
			if id:	query = query.id=id
			if project_id:	query = query.project_id=project_id
			if title:	query = query.title=title
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_project_file_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_project_user_list_dtls(self,session,access_level=None,project_id=None,user_id=None):
		try:    
			query = session.query(TcProjectUserListDtl).filter(TcProjectUserListDtl.org_id==self.org_id,TcProjectUserListDtl.entity_cre_flg==self.entity_cre_flg,TcProjectUserListDtl.del_flg==self.del_flg)
			if project_id:
				query = query.filter(TcProjectUserListDtl.project_id== project_id)
			if user_id:
				query = query.filter(TcProjectUserListDtl.user_id== user_id)
			if access_level:	query = query.access_level=access_level
			if project_id:	query = query.project_id=project_id
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_project_user_list_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_project_version_dtls(self,session,date_order=None,description=None,id=None,obsolete=None,project_id=None,released=None,version=None):
		try:    
			query = session.query(TcProjectVersionDtl).filter(TcProjectVersionDtl.org_id==self.org_id,TcProjectVersionDtl.entity_cre_flg==self.entity_cre_flg,TcProjectVersionDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcProjectVersionDtl.id== id)
			if date_order:	query = query.date_order=date_order
			if description:	query = query.description=description
			if id:	query = query.id=id
			if obsolete:	query = query.obsolete=obsolete
			if project_id:	query = query.project_id=project_id
			if released:	query = query.released=released
			if version:	query = query.version=version
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_project_version_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_sponsorship_dtls(self,session,amount=None,bug_id=None,date_submitted=None,id=None,last_updated=None,logo=None,paid=None,url=None,user_id=None):
		try:    
			query = session.query(TcSponsorshipDtl).filter(TcSponsorshipDtl.org_id==self.org_id,TcSponsorshipDtl.entity_cre_flg==self.entity_cre_flg,TcSponsorshipDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcSponsorshipDtl.id== id)
			if amount:	query = query.amount=amount
			if bug_id:	query = query.bug_id=bug_id
			if date_submitted:	query = query.date_submitted=date_submitted
			if id:	query = query.id=id
			if last_updated:	query = query.last_updated=last_updated
			if logo:	query = query.logo=logo
			if paid:	query = query.paid=paid
			if url:	query = query.url=url
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_sponsorship_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_tag_dtls(self,session,date_created=None,date_updated=None,description=None,id=None,name=None,user_id=None):
		try:    
			query = session.query(TcTagDtl).filter(TcTagDtl.org_id==self.org_id,TcTagDtl.entity_cre_flg==self.entity_cre_flg,TcTagDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcTagDtl.id== id)
			if name:
				query = query.filter(TcTagDtl.name== name)
			if date_created:	query = query.date_created=date_created
			if date_updated:	query = query.date_updated=date_updated
			if description:	query = query.description=description
			if id:	query = query.id=id
			if name:	query = query.name=name
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_tag_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_tokens_dtls(self,session,expiry=None,id=None,owner=None,timestamp=None,type=None,value=None):
		try:    
			query = session.query(TcTokensDtl).filter(TcTokensDtl.org_id==self.org_id,TcTokensDtl.entity_cre_flg==self.entity_cre_flg,TcTokensDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcTokensDtl.id== id)
			if expiry:	query = query.expiry=expiry
			if id:	query = query.id=id
			if owner:	query = query.owner=owner
			if timestamp:	query = query.timestamp=timestamp
			if type:	query = query.type=type
			if value:	query = query.value=value
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_tokens_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_user_dtls(self,session,access_level=None,cookie_string=None,date_created=None,email=None,enabled=None,failed_login_count=None,id=None,last_visit=None,login_count=None,lost_password_request_count=None,password=None,protected=None,realname=None,username=None):
		try:    
			query = session.query(TcUserDtl).filter(TcUserDtl.org_id==self.org_id,TcUserDtl.entity_cre_flg==self.entity_cre_flg,TcUserDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcUserDtl.id== id)
			if access_level:	query = query.access_level=access_level
			if cookie_string:	query = query.cookie_string=cookie_string
			if date_created:	query = query.date_created=date_created
			if email:	query = query.email=email
			if enabled:	query = query.enabled=enabled
			if failed_login_count:	query = query.failed_login_count=failed_login_count
			if id:	query = query.id=id
			if last_visit:	query = query.last_visit=last_visit
			if login_count:	query = query.login_count=login_count
			if lost_password_request_count:	query = query.lost_password_request_count=lost_password_request_count
			if password:	query = query.password=password
			if protected:	query = query.protected=protected
			if realname:	query = query.realname=realname
			if username:	query = query.username=username
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_user_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_user_pref_dtls(self,session,bugnote_order=None,default_profile=None,default_project=None,email_bugnote_limit=None,email_on_assigned=None,email_on_assigned_min_severity=None,email_on_bugnote=None,email_on_bugnote_min_severity=None,email_on_closed=None,email_on_closed_min_severity=None,email_on_feedback=None,email_on_feedback_min_severity=None,email_on_new=None,email_on_new_min_severity=None,email_on_priority=None,email_on_priority_min_severity=None,email_on_reopened=None,email_on_reopened_min_severity=None,email_on_resolved=None,email_on_resolved_min_severity=None,email_on_status=None,email_on_status_min_severity=None,id=None,language=None,project_id=None,redirect_delay=None,refresh_delay=None,timezone=None,user_id=None):
		try:    
			query = session.query(TcUserPrefDtl).filter(TcUserPrefDtl.org_id==self.org_id,TcUserPrefDtl.entity_cre_flg==self.entity_cre_flg,TcUserPrefDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcUserPrefDtl.id== id)
			if bugnote_order:	query = query.bugnote_order=bugnote_order
			if default_profile:	query = query.default_profile=default_profile
			if default_project:	query = query.default_project=default_project
			if email_bugnote_limit:	query = query.email_bugnote_limit=email_bugnote_limit
			if email_on_assigned:	query = query.email_on_assigned=email_on_assigned
			if email_on_assigned_min_severity:	query = query.email_on_assigned_min_severity=email_on_assigned_min_severity
			if email_on_bugnote:	query = query.email_on_bugnote=email_on_bugnote
			if email_on_bugnote_min_severity:	query = query.email_on_bugnote_min_severity=email_on_bugnote_min_severity
			if email_on_closed:	query = query.email_on_closed=email_on_closed
			if email_on_closed_min_severity:	query = query.email_on_closed_min_severity=email_on_closed_min_severity
			if email_on_feedback:	query = query.email_on_feedback=email_on_feedback
			if email_on_feedback_min_severity:	query = query.email_on_feedback_min_severity=email_on_feedback_min_severity
			if email_on_new:	query = query.email_on_new=email_on_new
			if email_on_new_min_severity:	query = query.email_on_new_min_severity=email_on_new_min_severity
			if email_on_priority:	query = query.email_on_priority=email_on_priority
			if email_on_priority_min_severity:	query = query.email_on_priority_min_severity=email_on_priority_min_severity
			if email_on_reopened:	query = query.email_on_reopened=email_on_reopened
			if email_on_reopened_min_severity:	query = query.email_on_reopened_min_severity=email_on_reopened_min_severity
			if email_on_resolved:	query = query.email_on_resolved=email_on_resolved
			if email_on_resolved_min_severity:	query = query.email_on_resolved_min_severity=email_on_resolved_min_severity
			if email_on_status:	query = query.email_on_status=email_on_status
			if email_on_status_min_severity:	query = query.email_on_status_min_severity=email_on_status_min_severity
			if id:	query = query.id=id
			if language:	query = query.language=language
			if project_id:	query = query.project_id=project_id
			if redirect_delay:	query = query.redirect_delay=redirect_delay
			if refresh_delay:	query = query.refresh_delay=refresh_delay
			if timezone:	query = query.timezone=timezone
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_user_pref_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_user_print_pref_dtls(self,session,print_pref=None,user_id=None):
		try:    
			query = session.query(TcUserPrintPrefDtl).filter(TcUserPrintPrefDtl.org_id==self.org_id,TcUserPrintPrefDtl.entity_cre_flg==self.entity_cre_flg,TcUserPrintPrefDtl.del_flg==self.del_flg)
			if user_id:
				query = query.filter(TcUserPrintPrefDtl.user_id== user_id)
			if print_pref:	query = query.print_pref=print_pref
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_user_print_pref_dtls Error :",str(e))
			return {'status' : "ERROR"}


	def save_tc_user_profile_dtls(self,session,description=None,id=None,os=None,os_build=None,platform=None,user_id=None):
		try:    
			query = session.query(TcUserProfileDtl).filter(TcUserProfileDtl.org_id==self.org_id,TcUserProfileDtl.entity_cre_flg==self.entity_cre_flg,TcUserProfileDtl.del_flg==self.del_flg)
			if id:
				query = query.filter(TcUserProfileDtl.id== id)
			if description:	query = query.description=description
			if id:	query = query.id=id
			if os:	query = query.os=os
			if os_build:	query = query.os_build=os_build
			if platform:	query = query.platform=platform
			if user_id:	query = query.user_id=user_id
			session.add(query)
			return {'status' : "SUCCESS"}
		except Exception as e:
			print(" {*} update_tc_user_profile_dtls Error :",str(e))
			return {'status' : "ERROR"}
