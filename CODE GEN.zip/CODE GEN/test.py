def subscore(name, dimensions=[], min_val=0, max_val=100, take_log=False, mixins=[]):
  def func(cls):
    print("cls : ",cls)
    cls.name = name
    cls.dimensions = dimensions
    cls.min_val = min_val
    cls.max_val = max_val
    cls.take_log = take_log
    cls.mixins = mixins
    return cls
  return func

class BuildingOperatingHoursSubScore:
  pass

class BuildingDistanceSubScore:
  pass


class HiScoreSubScore:
  print("Hello ->","HiScoreSubScore")



@subscore(name='ezhil')
class CityAirQualitySubScore(HiScoreSubScore):


  @classmethod
  def hello(cls,h):
    print(cls.name)
    print(h)

a = CityAirQualitySubScore.hello("hi")
print(a)








class UploadFile:
  pass