import model
from sqlalchemy.ext.declarative.api import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.sql.elements import TextClause


def update_func(class_obj,classname,column_list,primary_keys_list):
    try:
        print("primary_keys_list -> ",primary_keys_list)
        if 'org_id' in primary_keys_list:
            primary_keys_list.remove('org_id')
        print("2 primary_keys_list -> ",primary_keys_list)
        pk = ""
        pk_len = len(primary_keys_list)-1
        for id,col in enumerate(primary_keys_list):
            if "org_id" != col:
                print("test ->",pk_len," > ",id)
                pk += "\t\t\t"
                pk += f"if {col}:\n\t\t\t\t"
                if pk_len > id:
                    pk += f"query = query.filter({class_obj}.{col}== {col})\n"
                else:
                    pk += f"query = query.filter({class_obj}.{col}== {col})"
        
        cl = ""
        cl_len = len(column_list)-1
        for id,col in enumerate(column_list):
            if "org_id" != col:
                print("test ->",cl_len," > ",id)
                cl += "\t\t\t"
                cl += f"if {col}:\t"
                if cl_len > id:
                    cl += f"query = query.{col}={col}\n"
                else:
                    cl += f"query = query.{col}={col}"

        


        string = '''\n\n\tdef save_{classname}(self,session,{ckl}=None):
\t\ttry:    
\t\t\tquery = session.query({class_obj}).filter({class_obj}.org_id==self.org_id,{class_obj}.entity_cre_flg==self.entity_cre_flg,{class_obj}.del_flg==self.del_flg)\n{pk}\n{cl}
\t\t\tsession.add(query)
\t\t\treturn ['status' : "SUCCESS"]
\t\texcept Exception as e:
\t\t\tprint(" [*] update_{classname} Error :",str(e))
\t\t\treturn ['status' : "ERROR"]\n'''.format(cl=cl,class_obj=class_obj,pk=pk,pkl='=None,'.join(primary_keys_list),ckl='=None,'.join(column_list),classname=classname).replace("[","{").replace("]","}")
        return string
    except Exception as e:
        print("hello ->",e)

class_output = ""
class_output += f"from model import *\n"
class_output += f"class ClsUpdateAllDtls:"
class_output += f"\n\tdef __init__(self,org_id):"
class_output += f"\n\t\tself.org_id=org_id"
class_output += f"\n\t\tself.entity_cre_flg='Y'"
class_output += f"\n\t\tself.del_flg='N'"
for i in dir(model):
    try:
        classname = getattr(model, i)
        if type(classname)==DeclarativeMeta:
            column_list = []
            primary_keys_list = []
            for column in dir(classname):
                col_name = getattr(classname, column)
                try:
                    if col_name.primary_key == True:
                        print("col_name.primary_key :",column,col_name.primary_key)
                        primary_keys_list.append(column)
                    # if col_name.nullable == True:
                    #     print("col_name.nullable :",column,col_name.nullable)
                    if col_name.server_default != None:
                        print("col_name.server_default :",column,col_name.server_default)
                except:
                    pass
            for column in dir(classname):
                col_name = getattr(classname, column)
                if (type(col_name)==InstrumentedAttribute):
                    column_list.append(column)

            outstring = update_func(i,classname.__table__,column_list,primary_keys_list)
            class_output += outstring              
    except:
        pass

f = open(f"SAVE/SAVEAllDtls_model.py", "w")
f.write(class_output)
f.close()