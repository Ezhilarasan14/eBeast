# coding: utf-8
from sqlalchemy import Column, Index, Integer, SmallInteger, String, Table, Text, text
from sqlalchemy.dialects.mysql import INTEGER, LONGBLOB, LONGTEXT, TINYINT
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata


class TcApiTokenDtl(Base):
    __tablename__ = 'tc_api_token_dtls'
    __table_args__ = (
        Index('idx_user_id_name', 'user_id', 'name', unique=True),
    )

    id = Column(INTEGER, primary_key=True)
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    name = Column(String(128), nullable=False)
    hash = Column(String(128), nullable=False)
    date_created = Column(INTEGER, nullable=False, server_default=text("'1'"))
    date_used = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcBugDtl(Base):
    __tablename__ = 'tc_bug_dtls'

    id = Column(INTEGER, primary_key=True)
    project_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    reporter_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    handler_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    duplicate_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    priority = Column(SmallInteger, nullable=False, server_default=text("'30'"))
    severity = Column(SmallInteger, nullable=False, server_default=text("'50'"))
    reproducibility = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    status = Column(SmallInteger, nullable=False, index=True, server_default=text("'10'"))
    resolution = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    projection = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    eta = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    bug_text_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    os = Column(String(32), nullable=False, server_default=text("''"))
    os_build = Column(String(32), nullable=False, server_default=text("''"))
    platform = Column(String(32), nullable=False, server_default=text("''"))
    version = Column(String(64), nullable=False, server_default=text("''"))
    fixed_in_version = Column(String(64), nullable=False, index=True, server_default=text("''"))
    build = Column(String(32), nullable=False, server_default=text("''"))
    profile_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    view_state = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    summary = Column(String(128), nullable=False, server_default=text("''"))
    sponsorship_total = Column(Integer, nullable=False, index=True, server_default=text("'0'"))
    sticky = Column(TINYINT, nullable=False, server_default=text("'0'"))
    target_version = Column(String(64), nullable=False, server_default=text("''"))
    category_id = Column(INTEGER, nullable=False, server_default=text("'1'"))
    date_submitted = Column(INTEGER, nullable=False, server_default=text("'1'"))
    due_date = Column(INTEGER, nullable=False, server_default=text("'1'"))
    last_updated = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcBugFileDtl(Base):
    __tablename__ = 'tc_bug_file_dtls'

    id = Column(INTEGER, primary_key=True)
    bug_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    title = Column(String(250), nullable=False, server_default=text("''"))
    description = Column(String(250), nullable=False, server_default=text("''"))
    diskfile = Column(String(250), nullable=False, index=True, server_default=text("''"))
    filename = Column(String(250), nullable=False, server_default=text("''"))
    folder = Column(String(250), nullable=False, server_default=text("''"))
    filesize = Column(Integer, nullable=False, server_default=text("'0'"))
    file_type = Column(String(250), nullable=False, server_default=text("''"))
    content = Column(LONGBLOB)
    date_added = Column(INTEGER, nullable=False, server_default=text("'1'"))
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    bugnote_id = Column(INTEGER, server_default=text("'0'"))


class TcBugHistoryDtl(Base):
    __tablename__ = 'tc_bug_history_dtls'

    id = Column(INTEGER, primary_key=True)
    user_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    bug_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    field_name = Column(String(64), nullable=False)
    old_value = Column(String(255), nullable=False)
    new_value = Column(String(255), nullable=False)
    type = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    date_modified = Column(INTEGER, nullable=False, index=True, server_default=text("'1'"))


class TcBugMonitorDtl(Base):
    __tablename__ = 'tc_bug_monitor_dtls'

    user_id = Column(INTEGER, primary_key=True, nullable=False, server_default=text("'0'"))
    bug_id = Column(INTEGER, primary_key=True, nullable=False, index=True, server_default=text("'0'"))


class TcBugRelationshipDtl(Base):
    __tablename__ = 'tc_bug_relationship_dtls'

    id = Column(INTEGER, primary_key=True)
    source_bug_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    destination_bug_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    relationship_type = Column(SmallInteger, nullable=False, server_default=text("'0'"))


class TcBugRevisionDtl(Base):
    __tablename__ = 'tc_bug_revision_dtls'
    __table_args__ = (
        Index('idx_bug_rev_id_time', 'bug_id', 'timestamp'),
    )

    id = Column(INTEGER, primary_key=True)
    bug_id = Column(INTEGER, nullable=False)
    bugnote_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    user_id = Column(INTEGER, nullable=False)
    type = Column(INTEGER, nullable=False, index=True)
    value = Column(LONGTEXT, nullable=False)
    timestamp = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcBugTagDtl(Base):
    __tablename__ = 'tc_bug_tag_dtls'

    bug_id = Column(INTEGER, primary_key=True, nullable=False, server_default=text("'0'"))
    tag_id = Column(INTEGER, primary_key=True, nullable=False, index=True, server_default=text("'0'"))
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    date_attached = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcBugTextDtl(Base):
    __tablename__ = 'tc_bug_text_dtls'

    id = Column(INTEGER, primary_key=True)
    description = Column(LONGTEXT, nullable=False)
    steps_to_reproduce = Column(LONGTEXT, nullable=False)
    additional_information = Column(LONGTEXT, nullable=False)


class TcBugnoteDtl(Base):
    __tablename__ = 'tc_bugnote_dtls'

    id = Column(INTEGER, primary_key=True)
    bug_id = Column(INTEGER, nullable=False, index=True, server_default=text("'0'"))
    reporter_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    bugnote_text_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    view_state = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    note_type = Column(Integer, server_default=text("'0'"))
    note_attr = Column(String(250), server_default=text("''"))
    time_tracking = Column(INTEGER, nullable=False, server_default=text("'0'"))
    last_modified = Column(INTEGER, nullable=False, index=True, server_default=text("'1'"))
    date_submitted = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcBugnoteTextDtl(Base):
    __tablename__ = 'tc_bugnote_text_dtls'

    id = Column(INTEGER, primary_key=True)
    note = Column(LONGTEXT, nullable=False)


class TcCategoryDtl(Base):
    __tablename__ = 'tc_category_dtls'
    __table_args__ = (
        Index('idx_category_project_name', 'project_id', 'name', unique=True),
    )

    id = Column(INTEGER, primary_key=True)
    project_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    name = Column(String(128), nullable=False, server_default=text("''"))
    status = Column(INTEGER, nullable=False, server_default=text("'0'"))


class TcConfigDtl(Base):
    __tablename__ = 'tc_config_dtls'

    config_id = Column(String(64), primary_key=True, nullable=False)
    project_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"))
    user_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"))
    access_reqd = Column(Integer, server_default=text("'0'"))
    type = Column(Integer, server_default=text("'90'"))
    value = Column(LONGTEXT, nullable=False)


class TcCustomFieldDtl(Base):
    __tablename__ = 'tc_custom_field_dtls'

    id = Column(Integer, primary_key=True)
    name = Column(String(64), nullable=False, index=True, server_default=text("''"))
    type = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    possible_values = Column(Text, nullable=False)
    default_value = Column(String(255), nullable=False, server_default=text("''"))
    valid_regexp = Column(String(255), nullable=False, server_default=text("''"))
    access_level_r = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    access_level_rw = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    length_min = Column(Integer, nullable=False, server_default=text("'0'"))
    length_max = Column(Integer, nullable=False, server_default=text("'0'"))
    require_report = Column(TINYINT, nullable=False, server_default=text("'0'"))
    require_update = Column(TINYINT, nullable=False, server_default=text("'0'"))
    display_report = Column(TINYINT, nullable=False, server_default=text("'0'"))
    display_update = Column(TINYINT, nullable=False, server_default=text("'1'"))
    require_resolved = Column(TINYINT, nullable=False, server_default=text("'0'"))
    display_resolved = Column(TINYINT, nullable=False, server_default=text("'0'"))
    display_closed = Column(TINYINT, nullable=False, server_default=text("'0'"))
    require_closed = Column(TINYINT, nullable=False, server_default=text("'0'"))
    filter_by = Column(TINYINT, nullable=False, server_default=text("'1'"))


class TcCustomFieldProjectDtl(Base):
    __tablename__ = 'tc_custom_field_project_dtls'

    field_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"))
    project_id = Column(INTEGER, primary_key=True, nullable=False, server_default=text("'0'"))
    sequence = Column(SmallInteger, nullable=False, server_default=text("'0'"))


class TcCustomFieldStringDtl(Base):
    __tablename__ = 'tc_custom_field_string_dtls'

    field_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"))
    bug_id = Column(Integer, primary_key=True, nullable=False, index=True, server_default=text("'0'"))
    value = Column(String(255), nullable=False, server_default=text("''"))
    text = Column(LONGTEXT)


class TcEmailDtl(Base):
    __tablename__ = 'tc_email_dtls'

    email_id = Column(INTEGER, primary_key=True)
    email = Column(String(191), nullable=False, server_default=text("''"))
    subject = Column(String(250), nullable=False, server_default=text("''"))
    metadata_ = Column('metadata', LONGTEXT, nullable=False)
    body = Column(LONGTEXT, nullable=False)
    submitted = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcFiltersDtl(Base):
    __tablename__ = 'tc_filters_dtls'

    id = Column(INTEGER, primary_key=True)
    user_id = Column(Integer, nullable=False, server_default=text("'0'"))
    project_id = Column(Integer, nullable=False, server_default=text("'0'"))
    is_public = Column(TINYINT)
    name = Column(String(64), nullable=False, server_default=text("''"))
    filter_string = Column(LONGTEXT, nullable=False)


class TcNewsDtl(Base):
    __tablename__ = 'tc_news_dtls'

    id = Column(INTEGER, primary_key=True)
    project_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    poster_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    view_state = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    announcement = Column(TINYINT, nullable=False, server_default=text("'0'"))
    headline = Column(String(64), nullable=False, server_default=text("''"))
    body = Column(LONGTEXT, nullable=False)
    last_modified = Column(INTEGER, nullable=False, server_default=text("'1'"))
    date_posted = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcPluginDtl(Base):
    __tablename__ = 'tc_plugin_dtls'

    basename = Column(String(40), primary_key=True)
    enabled = Column(TINYINT, nullable=False, server_default=text("'0'"))
    protected = Column(TINYINT, nullable=False, server_default=text("'0'"))
    priority = Column(INTEGER, nullable=False, server_default=text("'3'"))


class TcProjectDtl(Base):
    __tablename__ = 'tc_project_dtls'

    id = Column(INTEGER, primary_key=True)
    name = Column(String(128), nullable=False, unique=True, server_default=text("''"))
    status = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    enabled = Column(TINYINT, nullable=False, server_default=text("'1'"))
    view_state = Column(SmallInteger, nullable=False, index=True, server_default=text("'10'"))
    access_min = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    file_path = Column(String(250), nullable=False, server_default=text("''"))
    description = Column(LONGTEXT, nullable=False)
    category_id = Column(INTEGER, nullable=False, server_default=text("'1'"))
    inherit_global = Column(TINYINT, nullable=False, server_default=text("'0'"))


class TcProjectFileDtl(Base):
    __tablename__ = 'tc_project_file_dtls'

    id = Column(INTEGER, primary_key=True)
    project_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    title = Column(String(250), nullable=False, server_default=text("''"))
    description = Column(String(250), nullable=False, server_default=text("''"))
    diskfile = Column(String(250), nullable=False, server_default=text("''"))
    filename = Column(String(250), nullable=False, server_default=text("''"))
    folder = Column(String(250), nullable=False, server_default=text("''"))
    filesize = Column(Integer, nullable=False, server_default=text("'0'"))
    file_type = Column(String(250), nullable=False, server_default=text("''"))
    content = Column(LONGBLOB)
    date_added = Column(INTEGER, nullable=False, server_default=text("'1'"))
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))


t_tc_project_hierarchy_dtls = Table(
    'tc_project_hierarchy_dtls', metadata,
    Column('child_id', INTEGER, nullable=False, index=True),
    Column('parent_id', INTEGER, nullable=False, index=True),
    Column('inherit_parent', TINYINT, nullable=False, server_default=text("'0'")),
    Index('idx_project_hierarchy', 'child_id', 'parent_id', unique=True)
)


class TcProjectUserListDtl(Base):
    __tablename__ = 'tc_project_user_list_dtls'

    project_id = Column(INTEGER, primary_key=True, nullable=False, server_default=text("'0'"))
    user_id = Column(INTEGER, primary_key=True, nullable=False, index=True, server_default=text("'0'"))
    access_level = Column(SmallInteger, nullable=False, server_default=text("'10'"))


class TcProjectVersionDtl(Base):
    __tablename__ = 'tc_project_version_dtls'
    __table_args__ = (
        Index('idx_project_version', 'project_id', 'version', unique=True),
    )

    id = Column(Integer, primary_key=True)
    project_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    version = Column(String(64), nullable=False, server_default=text("''"))
    description = Column(LONGTEXT, nullable=False)
    released = Column(TINYINT, nullable=False, server_default=text("'1'"))
    obsolete = Column(TINYINT, nullable=False, server_default=text("'0'"))
    date_order = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcSponsorshipDtl(Base):
    __tablename__ = 'tc_sponsorship_dtls'

    id = Column(Integer, primary_key=True)
    bug_id = Column(Integer, nullable=False, index=True, server_default=text("'0'"))
    user_id = Column(Integer, nullable=False, index=True, server_default=text("'0'"))
    amount = Column(Integer, nullable=False, server_default=text("'0'"))
    logo = Column(String(128), nullable=False, server_default=text("''"))
    url = Column(String(128), nullable=False, server_default=text("''"))
    paid = Column(TINYINT, nullable=False, server_default=text("'0'"))
    date_submitted = Column(INTEGER, nullable=False, server_default=text("'1'"))
    last_updated = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcTagDtl(Base):
    __tablename__ = 'tc_tag_dtls'

    id = Column(INTEGER, primary_key=True, nullable=False)
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    name = Column(String(100), primary_key=True, nullable=False, index=True, server_default=text("''"))
    description = Column(LONGTEXT, nullable=False)
    date_created = Column(INTEGER, nullable=False, server_default=text("'1'"))
    date_updated = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcTokensDtl(Base):
    __tablename__ = 'tc_tokens_dtls'
    __table_args__ = (
        Index('idx_typeowner', 'type', 'owner'),
    )

    id = Column(Integer, primary_key=True)
    owner = Column(Integer, nullable=False)
    type = Column(Integer, nullable=False)
    value = Column(LONGTEXT, nullable=False)
    timestamp = Column(INTEGER, nullable=False, server_default=text("'1'"))
    expiry = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcUserDtl(Base):
    __tablename__ = 'tc_user_dtls'

    id = Column(INTEGER, primary_key=True)
    username = Column(String(191), nullable=False, unique=True, server_default=text("''"))
    realname = Column(String(191), nullable=False, server_default=text("''"))
    email = Column(String(191), nullable=False, index=True, server_default=text("''"))
    password = Column(String(64), nullable=False, server_default=text("''"))
    enabled = Column(TINYINT, nullable=False, index=True, server_default=text("'1'"))
    protected = Column(TINYINT, nullable=False, server_default=text("'0'"))
    access_level = Column(SmallInteger, nullable=False, index=True, server_default=text("'10'"))
    login_count = Column(Integer, nullable=False, server_default=text("'0'"))
    lost_password_request_count = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    failed_login_count = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    cookie_string = Column(String(64), nullable=False, unique=True, server_default=text("''"))
    last_visit = Column(INTEGER, nullable=False, server_default=text("'1'"))
    date_created = Column(INTEGER, nullable=False, server_default=text("'1'"))


class TcUserPrefDtl(Base):
    __tablename__ = 'tc_user_pref_dtls'

    id = Column(INTEGER, primary_key=True)
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    project_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    default_profile = Column(INTEGER, nullable=False, server_default=text("'0'"))
    default_project = Column(INTEGER, nullable=False, server_default=text("'0'"))
    refresh_delay = Column(Integer, nullable=False, server_default=text("'0'"))
    redirect_delay = Column(Integer, nullable=False, server_default=text("'0'"))
    bugnote_order = Column(String(4), nullable=False, server_default=text("'ASC'"))
    email_on_new = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_assigned = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_feedback = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_resolved = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_closed = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_reopened = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_bugnote = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_status = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_priority = Column(TINYINT, nullable=False, server_default=text("'0'"))
    email_on_priority_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_status_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_bugnote_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_reopened_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_closed_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_resolved_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_feedback_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_assigned_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_on_new_min_severity = Column(SmallInteger, nullable=False, server_default=text("'10'"))
    email_bugnote_limit = Column(SmallInteger, nullable=False, server_default=text("'0'"))
    language = Column(String(32), nullable=False, server_default=text("'english'"))
    timezone = Column(String(32), nullable=False, server_default=text("''"))


class TcUserPrintPrefDtl(Base):
    __tablename__ = 'tc_user_print_pref_dtls'

    user_id = Column(INTEGER, primary_key=True, server_default=text("'0'"))
    print_pref = Column(String(64), nullable=False)


class TcUserProfileDtl(Base):
    __tablename__ = 'tc_user_profile_dtls'

    id = Column(INTEGER, primary_key=True)
    user_id = Column(INTEGER, nullable=False, server_default=text("'0'"))
    platform = Column(String(32), nullable=False, server_default=text("''"))
    os = Column(String(32), nullable=False, server_default=text("''"))
    os_build = Column(String(32), nullable=False, server_default=text("''"))
    description = Column(LONGTEXT, nullable=False)
