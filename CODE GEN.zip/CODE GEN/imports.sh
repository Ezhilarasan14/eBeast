sqlacodegen mysql+pymysql://root:tocodetech@localhost/bugtracker > model.py

sed -i -e 's/model_bug/model/g' GenerateUpdateAllByPrimaryKey.py
# python3 GenerateUpdateAllByPrimaryKey.py