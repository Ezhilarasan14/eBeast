import modelnew
from sqlalchemy.ext.declarative.api import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.sql.elements import TextClause
from sqlalchemy.sql.schema import DefaultClause

def get_func(classObj,classname,primary_keys_list):
    try:
        print("primary_keys_list -> ",primary_keys_list)
        if 'org_id' in primary_keys_list:
            primary_keys_list.remove('org_id')
        print("2 primary_keys_list -> ",primary_keys_list)
        pk = ""
        pk_len = len(primary_keys_list)-1
        for id,col in enumerate(primary_keys_list):
            if "org_id" != col:
                print("test ->",pk_len," > ",id)
                pk += "\t\t\t"
                pk += f"if {col} != None:\n\t\t\t\t"
                if pk_len > id:
                    pk += f"query = query.filter({classObj}.{col} == {col})\n"
                else:
                    pk += f"query = query.filter({classObj}.{col} == {col})"


        string = '''\n\n\tdef get_{classname}(self,session,{pkl}=None,return_type='J'):
\t\ttry:
\t\t\tquery = session.query({classObj}).filter(
\t\t\t{classObj}.org_id == self.org_id,
\t\t\t{classObj}.entity_cre_flg == self.entity_cre_flg,
\t\t\t{classObj}.del_flg == self.del_flg)\n{pk}
\t\t\tquery = query.all()
\t\t\tif return_type == 'O':
\t\t\t\treturn query
\t\t\treturn SqlAlchemyModelEncoder(query,return_type)
\t\texcept Exception as e:
\t\t\tprint(" [*] get_{column} Error :",str(e))
\t\t\treturn ['status' : "ERROR"]\n'''.format(classObj=classObj,pk=pk,pkl='=None,'.join(primary_keys_list),column=column,classname=classname).replace("[","{").replace("]","}")
        return string
    except Exception as e:
        print("hello ->",e)

class_output = ""
class_output += f"from modelnew import *\n"
class_output += f"import SqlAlchemyModelEncoder\n\n"
class_output += f"class ClsAllColumnDtls:\n\t"
class_output += f"def __init__(self,org_id):\n\t\t"
# class_output += f"\n\t\tpass"
class_output += f"self.org_id=org_id\n\t\t"
class_output += f"self.entity_cre_flg='Y'\n\t\t"
class_output += f"self.del_flg='N'"

for i in dir(modelnew):
    try:
        classname = getattr(modelnew, i)
        if type(classname)==DeclarativeMeta:
            column_list = []
            primary_keys_list = []
            for column in dir(classname):
                col_name = getattr(classname, column)
                try:
                    if col_name.primary_key == True:
                        print("col_name.primary_key :",column,col_name.primary_key)
                        primary_keys_list.append(column)
                    # if col_name.nullable == True:
                    #     print("col_name.nullable :",column,col_name.nullable)
                    if col_name.server_default != None:
                        print("col_name.server_default :",column,col_name.server_default)
                except Exception as e:
                    # print("e ->",e)
                    pass
            print("\n")
            outstring = get_func(i,classname.__table__,primary_keys_list)
            class_output += outstring
    except:
        pass
f = open(f"GETALL/getAlldtls.py", "w")
f.write(class_output)
f.close()