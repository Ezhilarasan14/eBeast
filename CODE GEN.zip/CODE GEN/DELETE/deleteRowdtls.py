from modelnew import *

class ClsRowSoftDelete:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def delete_app_data_comp(self,session,user_id,comp_id):
        try:
            query = session.query(app_data_comp).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if comp_id:
				query = query.filter(app_data_comp.comp_id== comp_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_data_compare(self,session,user_id,app_step_id,doc_code,doc_type,id,info_key):
        try:
            query = session.query(app_data_compare).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if app_step_id:
				query = query.filter(app_data_compare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(app_data_compare.doc_code== doc_code)
			if doc_type:
				query = query.filter(app_data_compare.doc_type== doc_type)
			if id:
				query = query.filter(app_data_compare.id== id)
			if info_key:
				query = query.filter(app_data_compare.info_key== info_key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_data_val(self,session,user_id,data_val_id):
        try:
            query = session.query(app_data_val).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if data_val_id:
				query = query.filter(app_data_val.data_val_id== data_val_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_doc_dtls(self,session,user_id,doc_id):
        try:
            query = session.query(app_doc_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if doc_id:
				query = query.filter(app_doc_dtls.doc_id== doc_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_doc_val(self,session,user_id,doc_val_id):
        try:
            query = session.query(app_doc_val).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if doc_val_id:
				query = query.filter(app_doc_val.doc_val_id== doc_val_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_emp_dtls(self,session,user_id,employer_id):
        try:
            query = session.query(app_emp_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if employer_id:
				query = query.filter(app_emp_dtls.employer_id== employer_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_years_of_exp Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_id_ver(self,session,user_id,id_ver_no):
        try:
            query = session.query(app_id_ver).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id_ver_no:
				query = query.filter(app_id_ver.id_ver_no== id_ver_no)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_integ(self,session,user_id,app_integ_id):
        try:
            query = session.query(app_integ).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if app_integ_id:
				query = query.filter(app_integ.app_integ_id== app_integ_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_location(self,session,user_id,loc_id):
        try:
            query = session.query(app_location).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if loc_id:
				query = query.filter(app_location.loc_id== loc_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_other_fields(self,session,user_id,id):
        try:
            query = session.query(app_other_fields).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(app_other_fields.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_app_steps(self,session,user_id,app_step_id):
        try:
            query = session.query(app_steps).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if app_step_id:
				query = query.filter(app_steps.app_step_id== app_step_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_verified_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_application_dtls(self,session,user_id,application_id):
        try:
            query = session.query(application_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if application_id:
				query = query.filter(application_dtls.application_id== application_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_video_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_appointment_dtls(self,session,user_id,appointment_id):
        try:
            query = session.query(appointment_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if appointment_id:
				query = query.filter(appointment_dtls.appointment_id== appointment_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_venue Error :",str(e))
            return {'status' : "ERROR"}


    def delete_audit_dtls(self,session,user_id,req_id):
        try:
            query = session.query(audit_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if req_id:
				query = query.filter(audit_dtls.req_id== req_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auditlog_logentry(self,session,user_id,id):
        try:
            query = session.query(auditlog_logentry).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auditlog_logentry.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_timestamp Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auditor(self,session,user_id,id):
        try:
            query = session.query(auditor).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auditor.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_group(self,session,user_id,id):
        try:
            query = session.query(auth_group).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_group.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_group_permissions(self,session,user_id,id):
        try:
            query = session.query(auth_group_permissions).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_group_permissions.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_permission_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_matrix_config(self,session,user_id,auth_matrix_id):
        try:
            query = session.query(auth_matrix_config).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if auth_matrix_id:
				query = query.filter(auth_matrix_config.auth_matrix_id== auth_matrix_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_permission(self,session,user_id,id):
        try:
            query = session.query(auth_permission).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_permission.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_token(self,session,user_id,key):
        try:
            query = session.query(auth_token).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if key:
				query = query.filter(auth_token.key== key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_user(self,session,user_id,id):
        try:
            query = session.query(auth_user).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_user.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_username Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_user_groups(self,session,user_id,id):
        try:
            query = session.query(auth_user_groups).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_user_groups.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_auth_user_user_permissions(self,session,user_id,id):
        try:
            query = session.query(auth_user_user_permissions).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(auth_user_user_permissions.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_authtoken_token(self,session,user_id,key):
        try:
            query = session.query(authtoken_token).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if key:
				query = query.filter(authtoken_token.key== key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_calendar_dtls(self,session,user_id,mmyyyy):
        try:
            query = session.query(calendar_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if mmyyyy:
				query = query.filter(calendar_dtls.mmyyyy== mmyyyy)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_call_requests(self,session,user_id,req_id):
        try:
            query = session.query(call_requests).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if req_id:
				query = query.filter(call_requests.req_id== req_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_category_dtls(self,session,user_id,cat_id):
        try:
            query = session.query(category_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cat_id:
				query = query.filter(category_dtls.cat_id== cat_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_cities(self,session,user_id,id):
        try:
            query = session.query(cities).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(cities.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}


    def delete_co_applicants(self,session,user_id,co_applicant_id):
        try:
            query = session.query(co_applicants).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if co_applicant_id:
				query = query.filter(co_applicants.co_applicant_id== co_applicant_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_coa_dtls(self,session,user_id,coa_id):
        try:
            query = session.query(coa_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if coa_id:
				query = query.filter(coa_dtls.coa_id== coa_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_countries(self,session,user_id,id):
        try:
            query = session.query(countries).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(countries.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}


    def delete_country_dtls(self,session,user_id,cntry_code,crncy_code):
        try:
            query = session.query(country_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cntry_code:
				query = query.filter(country_dtls.cntry_code== cntry_code)
			if crncy_code:
				query = query.filter(country_dtls.crncy_code== crncy_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_currency_dtls(self,session,user_id,crncy_code):
        try:
            query = session.query(currency_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if crncy_code:
				query = query.filter(currency_dtls.crncy_code== crncy_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_cust_bank_dtls(self,session,user_id,cust_id):
        try:
            query = session.query(cust_bank_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(cust_bank_dtls.cust_id== cust_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_cust_category(self,session,user_id,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            query = session.query(cust_category).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(cust_category.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(cust_category.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(cust_category.tran_date== tran_date)
			if tran_id:
				query = query.filter(cust_category.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(cust_category.user_cat_id== user_cat_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_cust_contact(self,session,user_id,cont_id):
        try:
            query = session.query(cust_contact).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cont_id:
				query = query.filter(cust_contact.cont_id== cont_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_customer_dtls(self,session,user_id,cust_id):
        try:
            query = session.query(customer_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(customer_dtls.cust_id== cust_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_daily_tran_dtls(self,session,user_id,int_tran_id):
        try:
            query = session.query(daily_tran_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if int_tran_id:
				query = query.filter(daily_tran_dtls.int_tran_id== int_tran_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_value_date Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_admin_log(self,session,user_id,id):
        try:
            query = session.query(django_admin_log).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_admin_log.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_celery_pending_list(self,session,user_id,cache_key):
        try:
            query = session.query(django_celery_pending_list).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cache_key:
				query = query.filter(django_celery_pending_list.cache_key== cache_key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_value Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_celery_results_chordcounter(self,session,user_id,id):
        try:
            query = session.query(django_celery_results_chordcounter).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_celery_results_chordcounter.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_sub_tasks Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_celery_results_groupresult(self,session,user_id,id):
        try:
            query = session.query(django_celery_results_groupresult).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_celery_results_groupresult.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_result Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_celery_results_taskresult(self,session,user_id,id):
        try:
            query = session.query(django_celery_results_taskresult).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_celery_results_taskresult.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_worker Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_content_type(self,session,user_id,id):
        try:
            query = session.query(django_content_type).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_content_type.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_model Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_migrations(self,session,user_id,id):
        try:
            query = session.query(django_migrations).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(django_migrations.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def delete_django_session(self,session,user_id,session_key):
        try:
            query = session.query(django_session).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if session_key:
				query = query.filter(django_session.session_key== session_key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_session_key Error :",str(e))
            return {'status' : "ERROR"}


    def delete_drf_api_logs(self,session,user_id,id):
        try:
            query = session.query(drf_api_logs).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(drf_api_logs.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_status_code Error :",str(e))
            return {'status' : "ERROR"}


    def delete_entity_access(self,session,user_id,entity_int_id,finserv_id):
        try:
            query = session.query(entity_access).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if entity_int_id:
				query = query.filter(entity_access.entity_int_id== entity_int_id)
			if finserv_id:
				query = query.filter(entity_access.finserv_id== finserv_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_entity_dtls(self,session,user_id,bank_id,entity_id,entity_int_id):
        try:
            query = session.query(entity_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if bank_id:
				query = query.filter(entity_dtls.bank_id== bank_id)
			if entity_id:
				query = query.filter(entity_dtls.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(entity_dtls.entity_int_id== entity_int_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}


    def delete_fees_dtls(self,session,user_id,fee_code,fee_crncy_code,finserv_id):
        try:
            query = session.query(fees_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if fee_code:
				query = query.filter(fees_dtls.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(fees_dtls.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(fees_dtls.finserv_id== finserv_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_finserv_branch(self,session,user_id,br_id,finserv_id):
        try:
            query = session.query(finserv_branch).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if br_id:
				query = query.filter(finserv_branch.br_id== br_id)
			if finserv_id:
				query = query.filter(finserv_branch.finserv_id== finserv_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_wkly_off Error :",str(e))
            return {'status' : "ERROR"}


    def delete_finserv_contact(self,session,user_id,contact_sub_type,contact_type,finserv_id):
        try:
            query = session.query(finserv_contact).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if contact_sub_type:
				query = query.filter(finserv_contact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(finserv_contact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(finserv_contact.finserv_id== finserv_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_finserv_dtls(self,session,user_id,finserv_id):
        try:
            query = session.query(finserv_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if finserv_id:
				query = query.filter(finserv_dtls.finserv_id== finserv_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_form_details(self,session,user_id,field_id,form_id,id,section_id):
        try:
            query = session.query(form_details).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if field_id:
				query = query.filter(form_details.field_id== field_id)
			if form_id:
				query = query.filter(form_details.form_id== form_id)
			if id:
				query = query.filter(form_details.id== id)
			if section_id:
				query = query.filter(form_details.section_id== section_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_form_section(self,session,user_id,field_id,id,section_id):
        try:
            query = session.query(form_section).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if field_id:
				query = query.filter(form_section.field_id== field_id)
			if id:
				query = query.filter(form_section.id== id)
			if section_id:
				query = query.filter(form_section.section_id== section_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_general_code(self,session,user_id,gen_id):
        try:
            query = session.query(general_code).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if gen_id:
				query = query.filter(general_code.gen_id== gen_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_goal_dtls(self,session,user_id,cust_id,goal_name):
        try:
            query = session.query(goal_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(goal_dtls.cust_id== cust_id)
			if goal_name:
				query = query.filter(goal_dtls.goal_name== goal_name)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_interview_dtls(self,session,user_id,application_id,call_id,ques_no):
        try:
            query = session.query(interview_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if application_id:
				query = query.filter(interview_dtls.application_id== application_id)
			if call_id:
				query = query.filter(interview_dtls.call_id== call_id)
			if ques_no:
				query = query.filter(interview_dtls.ques_no== ques_no)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_lead_contact(self,session,user_id,contact_sub_type,contact_type,lead_id):
        try:
            query = session.query(lead_contact).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if contact_sub_type:
				query = query.filter(lead_contact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(lead_contact.contact_type== contact_type)
			if lead_id:
				query = query.filter(lead_contact.lead_id== lead_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_leads_dtls(self,session,user_id,lead_id):
        try:
            query = session.query(leads_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if lead_id:
				query = query.filter(leads_dtls.lead_id== lead_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_mail_audit_dtls(self,session,user_id,req_id):
        try:
            query = session.query(mail_audit_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if req_id:
				query = query.filter(mail_audit_dtls.req_id== req_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_my_cache_table(self,session,user_id,cache_key):
        try:
            query = session.query(my_cache_table).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cache_key:
				query = query.filter(my_cache_table.cache_key== cache_key)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_value Error :",str(e))
            return {'status' : "ERROR"}


    def delete_network_dir(self,session,user_id,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            query = session.query(network_dir).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if file_source:
				query = query.filter(network_dir.file_source== file_source)
			if file_type:
				query = query.filter(network_dir.file_type== file_type)
			if ref_key:
				query = query.filter(network_dir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(network_dir.unq_bank_identifier== unq_bank_identifier)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_unq_bank_identifier Error :",str(e))
            return {'status' : "ERROR"}


    def delete_ntfn_conf(self,session,user_id,notif_code):
        try:
            query = session.query(ntfn_conf).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if notif_code:
				query = query.filter(ntfn_conf.notif_code== notif_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_org_branch(self,session,user_id,br_id):
        try:
            query = session.query(org_branch).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if br_id:
				query = query.filter(org_branch.br_id== br_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_wkly_off Error :",str(e))
            return {'status' : "ERROR"}


    def delete_org_dtls(self,session,user_id,):
        try:
            query = session.query(org_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)

            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_week_begins_on Error :",str(e))
            return {'status' : "ERROR"}


    def delete_org_integ(self,session,user_id,org_integ_id):
        try:
            query = session.query(org_integ).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if org_integ_id:
				query = query.filter(org_integ.org_integ_id== org_integ_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_otp_dtls(self,session,user_id,otp_uniq_id):
        try:
            query = session.query(otp_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if otp_uniq_id:
				query = query.filter(otp_dtls.otp_uniq_id== otp_uniq_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_pass_hist(self,session,user_id,pw_hist_id):
        try:
            query = session.query(pass_hist).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if pw_hist_id:
				query = query.filter(pass_hist.pw_hist_id== pw_hist_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_pass_policy(self,session,user_id,policy_id):
        try:
            query = session.query(pass_policy).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if policy_id:
				query = query.filter(pass_policy.policy_id== policy_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_preferences(self,session,user_id,cust_id,pref_event_name,pref_type,rem_parent_cat_id,rem_sys_cat_id):
        try:
            query = session.query(preferences).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(preferences.cust_id== cust_id)
			if pref_event_name:
				query = query.filter(preferences.pref_event_name== pref_event_name)
			if pref_type:
				query = query.filter(preferences.pref_type== pref_type)
			if rem_parent_cat_id:
				query = query.filter(preferences.rem_parent_cat_id== rem_parent_cat_id)
			if rem_sys_cat_id:
				query = query.filter(preferences.rem_sys_cat_id== rem_sys_cat_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_preference_dtls(self,session,user_id,cust_id,pref_event_name,pref_type,remind_par_cat_id,sys_tran_cat_id,user_id):
        try:
            query = session.query(preference_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(preference_dtls.cust_id== cust_id)
			if pref_event_name:
				query = query.filter(preference_dtls.pref_event_name== pref_event_name)
			if pref_type:
				query = query.filter(preference_dtls.pref_type== pref_type)
			if remind_par_cat_id:
				query = query.filter(preference_dtls.remind_par_cat_id== remind_par_cat_id)
			if sys_tran_cat_id:
				query = query.filter(preference_dtls.sys_tran_cat_id== sys_tran_cat_id)
			if user_id:
				query = query.filter(preference_dtls.user_id== user_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_preproc_dtls(self,session,user_id,cust_id,preproc_as_on):
        try:
            query = session.query(preproc_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(preproc_dtls.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(preproc_dtls.preproc_as_on== preproc_as_on)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_preproc_hist_dtls(self,session,user_id,cust_id,preproc_as_on,preproc_srl_num):
        try:
            query = session.query(preproc_hist_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(preproc_hist_dtls.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(preproc_hist_dtls.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(preproc_hist_dtls.preproc_srl_num== preproc_srl_num)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_prod_steps_config(self,session,user_id,prod_step_id):
        try:
            query = session.query(prod_steps_config).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if prod_step_id:
				query = query.filter(prod_steps_config.prod_step_id== prod_step_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_product_addons(self,session,user_id,add_on_code,crncy_code,finserv_id,prod_code):
        try:
            query = session.query(product_addons).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if add_on_code:
				query = query.filter(product_addons.add_on_code== add_on_code)
			if crncy_code:
				query = query.filter(product_addons.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(product_addons.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(product_addons.prod_code== prod_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_product_doc_dtls(self,session,user_id,prod_doc_id):
        try:
            query = session.query(product_doc_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if prod_doc_id:
				query = query.filter(product_doc_dtls.prod_doc_id== prod_doc_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_product_dtls(self,session,user_id,crncy_code,finserv_id,prod_code):
        try:
            query = session.query(product_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if crncy_code:
				query = query.filter(product_dtls.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(product_dtls.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(product_dtls.prod_code== prod_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_withdrawal_basis_flg Error :",str(e))
            return {'status' : "ERROR"}


    def delete_product_fees(self,session,user_id,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            query = session.query(product_fees).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if fee_code:
				query = query.filter(product_fees.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(product_fees.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(product_fees.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(product_fees.prod_code== prod_code)
			if prod_crncy_code:
				query = query.filter(product_fees.prod_crncy_code== prod_crncy_code)
			if prod_type:
				query = query.filter(product_fees.prod_type== prod_type)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_product_master(self,session,user_id,finserv_id,prod_code):
        try:
            query = session.query(product_master).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if finserv_id:
				query = query.filter(product_master.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(product_master.prod_code== prod_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_users Error :",str(e))
            return {'status' : "ERROR"}


    def delete_rec_dtls(self,session,user_id,cust_id,finserv_id,prod_code):
        try:
            query = session.query(rec_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(rec_dtls.cust_id== cust_id)
			if finserv_id:
				query = query.filter(rec_dtls.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(rec_dtls.prod_code== prod_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_rec_hist_dtls(self,session,user_id,cust_id,finserv_id,prod_code):
        try:
            query = session.query(rec_hist_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if cust_id:
				query = query.filter(rec_hist_dtls.cust_id== cust_id)
			if finserv_id:
				query = query.filter(rec_hist_dtls.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(rec_hist_dtls.prod_code== prod_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_reg_tax_dtls(self,session,user_id,tax_code,tax_name,tax_type):
        try:
            query = session.query(reg_tax_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if tax_code:
				query = query.filter(reg_tax_dtls.tax_code== tax_code)
			if tax_name:
				query = query.filter(reg_tax_dtls.tax_name== tax_name)
			if tax_type:
				query = query.filter(reg_tax_dtls.tax_type== tax_type)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_action_access(self,session,user_id,action_id):
        try:
            query = session.query(role_action_access).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if action_id:
				query = query.filter(role_action_access.action_id== action_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_view_perm Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_crncy_dtls(self,session,user_id,crncy_code,role_code):
        try:
            query = session.query(role_crncy_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if crncy_code:
				query = query.filter(role_crncy_dtls.crncy_code== crncy_code)
			if role_code:
				query = query.filter(role_crncy_dtls.role_code== role_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_xfer_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_dtls(self,session,user_id,role_id):
        try:
            query = session.query(role_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if role_id:
				query = query.filter(role_dtls.role_id== role_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_permission_dtls(self,session,user_id,perm_id):
        try:
            query = session.query(role_permission_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if perm_id:
				query = query.filter(role_permission_dtls.perm_id== perm_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_verifier Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_prod_access(self,session,user_id,role_prod_id):
        try:
            query = session.query(role_prod_access).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if role_prod_id:
				query = query.filter(role_prod_access.role_prod_id== role_prod_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_role_workflow_access(self,session,user_id,role_wf_id):
        try:
            query = session.query(role_workflow_access).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if role_wf_id:
				query = query.filter(role_workflow_access.role_wf_id== role_wf_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_rpt_perm(self,session,user_id,rpt_perm_id):
        try:
            query = session.query(rpt_perm).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if rpt_perm_id:
				query = query.filter(rpt_perm.rpt_perm_id== rpt_perm_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_session_dtls(self,session,user_id,sess_uniq_id):
        try:
            query = session.query(session_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if sess_uniq_id:
				query = query.filter(session_dtls.sess_uniq_id== sess_uniq_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_silk_profile(self,session,user_id,id):
        try:
            query = session.query(silk_profile).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(silk_profile.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_time_taken Error :",str(e))
            return {'status' : "ERROR"}


    def delete_silk_profile_queries(self,session,user_id,id):
        try:
            query = session.query(silk_profile_queries).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(silk_profile_queries.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_sqlquery_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_silk_request(self,session,user_id,id):
        try:
            query = session.query(silk_request).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(silk_request.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_view_name Error :",str(e))
            return {'status' : "ERROR"}


    def delete_silk_response(self,session,user_id,id):
        try:
            query = session.query(silk_response).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(silk_response.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_status_code Error :",str(e))
            return {'status' : "ERROR"}


    def delete_silk_sqlquery(self,session,user_id,id):
        try:
            query = session.query(silk_sqlquery).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(silk_sqlquery.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_traceback Error :",str(e))
            return {'status' : "ERROR"}


    def delete_states(self,session,user_id,id):
        try:
            query = session.query(states).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if id:
				query = query.filter(states.id== id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}


    def delete_sub_dtls(self,session,user_id,plan_id):
        try:
            query = session.query(sub_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if plan_id:
				query = query.filter(sub_dtls.plan_id== plan_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_tax_dtls(self,session,user_id,fee_code,finserv_id,tax_code):
        try:
            query = session.query(tax_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if fee_code:
				query = query.filter(tax_dtls.fee_code== fee_code)
			if finserv_id:
				query = query.filter(tax_dtls.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(tax_dtls.tax_code== tax_code)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_tbl_audit_dtl(self,session,user_id,log_id):
        try:
            query = session.query(tbl_audit_dtl).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if log_id:
				query = query.filter(tbl_audit_dtl.log_id== log_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_ts_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def delete_user_contact(self,session,user_id,contact_sub_type,contact_type,user_id):
        try:
            query = session.query(user_contact).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if contact_sub_type:
				query = query.filter(user_contact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(user_contact.contact_type== contact_type)
			if user_id:
				query = query.filter(user_contact.user_id== user_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_user_dtls(self,session,user_id,user_id):
        try:
            query = session.query(user_dtls).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if user_id:
				query = query.filter(user_dtls.user_id== user_id)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def delete_yodlee_provider(self,session,user_id,providerAccountId,providerId):
        try:
            query = session.query(yodlee_provider).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)
			if providerAccountId:
				query = query.filter(yodlee_provider.providerAccountId== providerAccountId)
			if providerId:
				query = query.filter(yodlee_provider.providerId== providerId)
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" {*} get_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}
