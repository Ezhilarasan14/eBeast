# coding: utf-8
from optparse import Values
from sqlalchemy import BigInteger, CHAR, Column,Unicode, DECIMAL, Date, DateTime, ForeignKey, Index, Integer, SmallInteger, String, TIMESTAMP, Text, text, CheckConstraint
from sqlalchemy.dialects.mysql import DATETIME, INTEGER, LONGTEXT, SMALLINT, TINYINT
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from django.contrib.auth.hashers import make_password, check_password
from sqlalchemy.ext.hybrid import hybrid_property, hybrid_method
from sqlalchemy import event
from sqlalchemy.pool import Pool
from sqlalchemy_utils import EncryptedType
from SqlalchemyEncryptedHelper import AesEngine
from sqlalchemy.orm.attributes import get_history
from SqlAlchemyModelEncoder import AlchemyEncoder
import uuid,sqlalchemy,json

PII_KEY = 'ikolpedhu#ju76hyHUjiesh789@#$hyn'
PII_ENCRYPT = "NO"

Base = declarative_base()
metadata = Base.metadata


def before_update_log(table_name, unique_id):
    def before_update_in(mapper, connection, target):
        po = TblAuditDtl.__table__
        row = target.__dict__
        instanceState = row['_sa_instance_state'].__dict__
        modified_fields = {}
        for key, value in instanceState['committed_state'].items():
            history = get_history(target, key)

            if not history[1]:
                modified_fields[key] = str(history[0][0]) + "|" + str(history[2][0]) if len(history[2])>0 else None
        
        tbl_unique_id = ''
        lchg_user_id = row['lchg_user_id'] if 'lchg_user_id' in row else 'SYSTEM'
        rcre_user_id = row['rcre_user_id'] if 'rcre_user_id' in row else 'SYSTEM'
        if type(unique_id)==list:
            for item in unique_id:
                tbl_unique_id += str(row[item]) + "|" if item in row else ''
        else:
            tbl_unique_id = str(row[unique_id]) + "|" if unique_id in row else ''
        
        tbl_org_id = row['org_id'] if 'org_id' in row else ''
        
        table_key = str(tbl_unique_id) + str(tbl_org_id)
        
        if modified_fields:
            connection.execute(po.insert().values(table_name=table_name, table_key=table_key, operation='update', modified_fields = json.dumps(modified_fields, cls=AlchemyEncoder), org_id = target.org_id, lchg_user_id=lchg_user_id, rcre_user_id=rcre_user_id))
    return before_update_in


class AppDataComp(Base):
    __tablename__ = 'app_data_comp'
    __table_args__ = (
        Index('ix2_app_data_comp', 'application_id', 'org_id'),
        {'comment': 'Application data coparision details table'}
    )

    comp_id = Column(Integer, primary_key=True, nullable=False, comment='Auto-Increment ID', autoincrement=True)
    application_id = Column(Integer, nullable=False)
    ## HEMA - Co-Appliant / Nominee
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    field_name = Column(String(255), nullable=False, comment='Field Name')
    doc_values = Column(String(255), comment='Document Field Values')
    sys_status = Column(CHAR(1), nullable=False, server_default=text("'O'"), comment='Status of the Step O - Open, M - Matched, U - Unmatched, P - Partial Match')
    user_status = Column(CHAR(1), nullable=False, server_default=text("'O'"), comment='Status of the Step O - Open, M - Matched, U - Unmatched')
    user_remarks = Column(String(255), comment='Approver Remarks on the field')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified, N means just created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record created by user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last changed time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Org id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppDataComp, "before_update", before_update_log('app_data_comp', 'comp_id'))

class NtfnConf(Base):
    __tablename__ = 'ntfn_conf'

    notif_code = Column(String(50), primary_key=True, nullable=False, comment='otp scenario code')
    notif_desc = Column(String(50), comment='otp scenario description')
    mobile = Column(String(1), server_default=text("'N'"), comment='Mobile OTP flag. Y - Yes, N - No')
    email = Column(String(1), server_default=text("'N'"), comment='Email OTP flag. Y - Yes, N - No')
    org_id = Column(String(50), primary_key=True, nullable=False)
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(NtfnConf, "before_update", before_update_log('ntfn_conf', 'notif_code'))

class AppDataCompare(Base):
    __tablename__ = 'app_data_compare'
    __table_args__ = {'comment': 'Application data coparision details table'}

    id = Column(Integer, primary_key=True, nullable=False, comment='Auto-Increment', autoincrement=True)
    app_step_id = Column(Integer, primary_key=True, nullable=False, comment='Step id of the application for which the verification is being done')
    application_id = Column(Integer)
    cust_id = Column(String(15), comment='Customer ID')
    step_name = Column(String(30), comment='Name of the step - Document Verification, Legal Assessment, Income Assesment')
    doc_type = Column(String(15), primary_key=True, nullable=False, comment='Type of document that is needed as proof. ID , ADDRESS , INCOME , TAX etc')
    doc_code = Column(String(15), primary_key=True, nullable=False, comment='Code of document that is needed as proof ID - PASSPORT , AADHAR , INCOME - SALARY , TAX -PAN')
    info_key = Column(String(20), primary_key=True, nullable=False, comment='Information field that is being validated like First name, Last Name etc')
    info_value = Column(String(50), comment='Information value that is being validated like First name, Last Name etc')
    system_comp_status = Column(CHAR(1), nullable=False, server_default=text("'O'"), comment='Status of the Step O - Open, M - Matched, U - Unmatched, P - Partial Match')
    user_accept_status = Column(CHAR(1), nullable=False, server_default=text("'O'"), comment='Status of the Step O - Open, M - Matched, U - Unmatched')
    user_remarks = Column(String(255), comment='Approver Remarks on the field')
    entity_cre_flg = Column(CHAR(1), nullable=False, server_default=text("'Y'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), nullable=False, server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record created by user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last changed time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppDataCompare, "before_update", before_update_log('app_data_compare', 'app_step_id'))

class AppDocDtl(Base):
    __tablename__ = 'app_doc_dtls'
    __table_args__ = (
        Index('ix4_app_doc_dtls', 'cust_id', 'org_id'),
        Index('ix5_app_doc_dtls', 'application_id', 'cust_id', 'org_id'),
        Index('ix2_app_doc_dtls', 'application_id', 'org_id'),
        Index('ix1_app_doc_dtls', 'application_id', 'doc_type', 'doc_code', 'org_id'),
        Index('ix3_app_doc_dtls', 'doc_number', 'org_id'),
        {'comment': 'Uploaded document details for an application'}
    )

    doc_id = Column(Integer, primary_key=True, nullable=False, comment='Auto increment ID', autoincrement=True)
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    application_id = Column(Integer, nullable=False)
    purpose_of_doc = Column(String(4), nullable=False, server_default=text("'PROD'"))
    doc_type = Column(String(15), nullable=False)
    doc_code = Column(String(15), nullable=False)
    doc_src = Column(String(1), comment='Document Source - C => Customer, B => Back office')
    doc_number = Column(String(30), nullable=False, comment='Number of document')
    doc_host = Column(String(100), comment='Host in which the document is being stored')
    back_doc_host = Column(String(100), comment='Host in which the document backside is being stored')
    doc_path = Column(String(150), comment='Path where the document gets stored')
    back_doc_path = Column(String(150), comment='Path where the document backside gets stored')
    request_id = Column(String(20), comment='API Request id in case of remote storage through API')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    ocr_content = Column(LONGTEXT, comment='OCR Réponse JSON data (PAN, AADHAR, PASSPORT)')
    ocr_status = Column(String(1), nullable=False, server_default=text("'N'"), comment='N-Default , P - Processing , C - Completed')
    ocr_extract_list = Column(LONGTEXT, comment='Raw text from image returned by mmocr')
    back_ocr_extract_list = Column(LONGTEXT, comment='Raw text from image returned by mmocr from backside of card')
    back_ocr_content = Column(LONGTEXT, comment='Back document OCR Réponse JSON data (PAN, AADHAR, PASSPORT)')
    obj_det_content = Column(LONGTEXT, comment='Object Detection Réponse JSON data (PAN, AADHAR, PASSPORT)')
    back_obj_det_content = Column(LONGTEXT, comment='Back document Object Detection Réponse JSON data (PAN, AADHAR, PASSPORT)')
    front_obj_cont = Column(LONGTEXT, comment='Object Detection Reponse JSON data (PAN, AADHAR, PASSPORT)')
    back_obj_cont = Column(LONGTEXT, comment='Back document Object Detection Reponse JSON data (PAN, AADHAR, PASSPORT)')
    img_match_score = Column(DECIMAL(20, 2), comment='Euclidean Distance calculated from document image and original image')
    system_status = Column(CHAR(1), server_default=text("'P'"), comment='Document Approved or Rejected- A - Approved, R - Rejected, P - Pending')
    manual_status = Column(CHAR(1), server_default=text("'P'"), comment='Document Approved or Rejected- A - Approved, R - Rejected, P - Pending')
    remarks = Column(Text, comment='Officer will enter remark when he will reject or resubmit the document')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer)
    org_id = Column(String(50), primary_key=True, nullable=False)

    if PII_ENCRYPT == "YES":
        file_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        back_file_name= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        img_filename= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
    else:
        file_name = Column(String(50), comment='Name of the file that is being uploaded by the customer')
        back_file_name = Column(String(50), comment='Name of the back file that is being uploaded by the customer')
        img_filename = Column(String(100), comment='Cropped image file name from document')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppDocDtl, "before_update", before_update_log('app_doc_dtls', 'application_id'))

class AppEmpDtl(Base):
    __tablename__ = 'app_emp_dtls'
    __table_args__ = (
        Index('ix2_app_emp_dtls', 'cust_id', 'org_id'),
        Index('ix1_app_emp_dtls', 'application_id', 'org_id')
    )

    employer_id = Column(Integer, primary_key=True, nullable=False, comment='Employer id of the employee', autoincrement=True)
    application_id = Column(Integer, primary_key=True, nullable=False, comment='Id of the application')
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    employer_type = Column(String(15), comment='Employment type of the employer')
    employer_address = Column(String(15), comment='Address of the employer')
    employer_city = Column(String(30), comment='City code of the employer')
    employer_state = Column(String(15), comment='State code of the employer')
    employer_country = Column(String(50), comment='Country code of the employer')
    employer_pin = Column(String(50), comment='Pin code of the employer')
    role = Column(String(50), comment='International bank Number of the Bank')
    years_of_exp = Column(String(50), comment='International bank Number of the Bank')
    salary_currency = Column(String(3), comment=' Currency of the salary')
    gross_salary = Column(DECIMAL(20, 4), server_default=text("'0.00'"), comment='Salary of the customer')
    sector = Column(String(30), comment='Sector to which the employer belongs to')
    from_yr = Column(Date, comment='Year of starting experience')
    to_yr = Column(Date, comment='Year of ending experience')
    image_path = Column(String(50), comment='Path where the image of the bank is stored')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Bank id to which this record belongs to')

    if PII_ENCRYPT == "YES":
        employer_name= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
    else:
        employer_name = Column(String(50), comment='Name of the Emplyer')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppEmpDtl, "before_update", before_update_log('app_emp_dtls', 'application_id'))

class AppIdVer(Base):
    __tablename__ = 'app_id_ver'
    __table_args__ = (
        Index('ix1_app_id_ver', 'application_id', 'org_id'),
    )

    id_ver_no = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    application_id = Column(Integer, nullable=False)
    ## HEMA - Co-Appliant / Nominee
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    ph_doc_code = Column(String(45))
    ph_vid_fig = Column(CHAR(1), comment='P - Photos, V - Video')
    img_status = Column(CHAR(1), server_default=text("'P'"), comment='P - Processing, C - Completed')
    otp_status = Column(CHAR(1), server_default=text("'P'"))
    spoof_status = Column(CHAR(1), server_default=text("'P'"))
    applnt_status = Column(CHAR(1), server_default=text("'N'"), comment='Applicant Level Identity Verification acceptance by the user C - Accept, U - Recollect')
    applnt_status_remarks = Column(String(50), comment='Remarks by User')
    face_score = Column(DECIMAL(20, 4))
    face_dist = Column(DECIMAL(20, 4))
    spoof_score = Column(DECIMAL(20, 4))
    otp_gen = Column(String(5))
    otp_det = Column(String(8))
    frame_rate = Column(Integer)
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1), server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    if PII_ENCRYPT == "YES":
        ph_doc_path= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        ph_cap_path= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        capt_path= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        proc_path= Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
    else:
        ph_doc_path = Column(String(100))
        ph_cap_path = Column(String(100))
        capt_path = Column(String(100))
        proc_path = Column(String(100))

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppIdVer, "before_update", before_update_log('app_id_ver', 'application_id'))

class AppInteg(Base):
    __tablename__ = 'app_integ'
    __table_args__ = (
        Index('uix_app_integ', 'app_id', 'sys_name', 'trigger_step', 'trigger_action', 'trigger_seq', 'integ_url', 'org_id', unique=True),
        {'comment': 'Application Integration Table'}
    )

    app_integ_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True, comment='App integration ID')
    app_id = Column(Integer, nullable=False, comment='Application ID')
    integ_type = Column(CHAR(10), comment='Integration type')
    trigger_step = Column(CHAR(5), comment='The Step in which it is triggered')
    trigger_action = Column(CHAR(10), comment='The event or action of the trigger')
    trigger_seq = Column(Integer, comment='Triggering sequence')
    integ_url = Column(String(255), comment='Url to integrate')
    dep_on = Column(String(255), comment='Dependant on')
    is_api_revokable = Column(CHAR(1), comment='Is this api revokable Y - Yes,N - No')
    sys_name = Column(CHAR(10), comment='Integration system name')
    api_status = Column(String(1), comment='The api status of the Integration S - Success, F - Failure')
    entity_id = Column(String(50), comment='Id of the entity created')
    result = Column(String(255), comment='Result from the called api')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppInteg, "before_update", before_update_log('app_integ', 'app_id'))

class AppLocation(Base):
    __tablename__ = 'app_location'
    __table_args__ = (
        Index('ix2_app_location', 'cust_id', 'org_id'),
        Index('ix1_app_location', 'application_id', 'org_id')
    )

    loc_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True, comment='Location id primary key')
    application_id = Column(Integer)
    cust_id = Column(String(15))
    latitude = Column(DECIMAL(11, 9))
    longitude = Column(DECIMAL(11, 9))
    display_name = Column(Text)
    response = Column(Text)
    sys_info = Column(Text, comment='System Informations')
    sys_status = Column(CHAR(1), server_default=text("'N'"), comment='Validation result by the system P - Pass, F - Fail, N - None')
    user_status = Column(CHAR(1), server_default=text("'N'"), comment='Validation acceptance by the user C - Accept, U - Recollect, N - None')
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    entity_cre_flg = Column(CHAR(1), nullable=False, server_default=text("'Y'"))
    del_flg = Column(CHAR(1), nullable=False, server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(INTEGER,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppLocation, "before_update", before_update_log('app_location', 'application_id'))

class AppOtherField(Base):
    __tablename__ = 'app_other_fields'
    __table_args__ = (
        Index('uix1_app_other_fields', 'application_id', 'cust_id', 'section_id', 'field_id', 'org_id', unique=True),
    )

    id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    application_id = Column(Integer, nullable=False)
    cust_id = Column(String(15), nullable=False)
    form_id = Column(String(30))
    section_id = Column(String(30))
    field_type = Column(String(10))
    field_id = Column(String(35))
    field_value = Column(String(45))
    ref_type = Column(String(5), comment='General code ref_type')
    entity_cre_flg = Column(CHAR(1), server_default=text("'Y'"))
    del_flg = Column(CHAR(1), server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppOtherField, "before_update", before_update_log('app_other_fields', 'application_id'))

class AppStep(Base):
    __tablename__ = 'app_steps'
    __table_args__ = (
        Index('uix1_app_steps', 'application_id', 'org_id', 'step_code', unique=True),
        Index('ix1_ app_steps', 'application_id', 'org_id'),
        Index('ix2_ app_steps', 'application_id', 'prod_step_id', 'org_id'),
        {'comment': 'Applicaton process flow Details Table'}
    )

    app_step_id = Column(Integer, primary_key=True, nullable=False, comment='Unique Id of the application step', autoincrement=True)
    application_id = Column(Integer, comment='Id of the application')
    prod_step_id = Column(Integer, comment='Unique ID of the application step configuration table')
    step_num = Column(Integer, comment='Number of the process step of this product')
    step_code = Column(String(8), nullable=False, comment='An unique code for the step ')
    step_name = Column(String(30))
    mandatory = Column(CHAR(1), server_default=text("'N'"), comment='Tells whether this step is mandatory or optional  (Y - Yes, N - No)')
    step_status = Column(CHAR(1), nullable=False, comment=' Status of the Step O - Open, C - Completed, R - Referred')
    user_remarks = Column(String(255), comment='Approver Remarks on the field')
    data_overall_point = Column(DECIMAL(10, 2), server_default=text("'0.00'"), comment='Data uploaded and verify Points')
    total_doc_cnt = Column(Integer, comment='Total upload document')
    uploaded_doc_cnt = Column(Integer, comment='Uploaded document count')
    verified_doc_cnt = Column(Integer, comment='Verified Document count')
    auth_matrix_code = Column(String(25), comment='Autorization Matrix code for escalation matrix')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppStep, "before_update", before_update_log('app_steps',['application_id','step_code']))

class ApplicationDtl(Base):
    __tablename__ = 'application_dtls'
    __table_args__ = (
        Index('ix2_application_dtls', 'applying_user_id', 'org_id'),
        Index('ix3_application_dtls', 'applying_prod_type', 'org_id'),
        Index('ix1_application_dtls', 'applied_for_user_id', 'org_id'),
        Index('ix4_application_dtls', 'applying_prod_code', 'org_id'),
        {'comment': 'Applicaton Details Table'}
    )

    application_id = Column(Integer, primary_key=True, nullable=False, comment='Id of the application', autoincrement=True)
    parent_application_id = Column(Integer)
    applied_by = Column(String(1), nullable=False, comment='Application applied by A - Aggregator, C - Customer')
    applying_user_id = Column(String(15), nullable=False, comment='Code of the Financial Services company')
    applied_for_user_nature = Column(String(1), nullable=False, comment='For Customer or Lead. C - Customer , L - Lead ')
    applied_for_user_type = Column(String(1), nullable=False, comment='Customer type R - Retail , C - Corporate')
    applied_for_user_id = Column(String(15), nullable=False, comment='Id of the user for whom the applicationis initiated for')
    app_owner_id = Column(String(15),comment='Id of the application owner id')
    app_owner_role = Column(String(15),comment='Role code of the application owner')
    applied_on = Column(DateTime, comment='Application date and time')
    app_status = Column(String(1), nullable=False, server_default=text("'I'"), comment='Status of the application. I - Initiated, P - Progress, C - Completed, R - Rejected')
    app_mode = Column(String(1), nullable=False, server_default=text("'S'"), comment='Application mode - S => Single applicant, M => Multi Applicants')
    entity_status = Column(String(1), server_default=text("'N'"), comment='Status of the entity. For Account , N-None, C-Created')
    entity_id = Column(String(30), comment='External Id of the entity')
    finserv_id = Column(String(50), nullable=False, comment='Code of the Financial Services company')
    applying_prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    applying_prod_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    applying_prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    applying_prod_code = Column(String(8), nullable=False, comment='Product code for which the application is for')
    crncy_code = Column(String(6), comment='Application currency code ')
    loan_amount = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Loan amount sought by the customer')
    deposit_amount = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Deposit amount sought by the customer')
    tenure = Column(Integer, server_default=text("'0'"), comment='Period of deposit or loan or insurance - in months')
    installment_freq = Column(String(1), comment='M - Monthly , Q - Quarterly , H - Half yearly , Y - Yearly , F - Fortnightly ')
    add_ons_opted = Column(String(20), comment='List of Add ons opted for')
    int_rate = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Interest Rate sought by the customer')
    emi_amount = Column(DECIMAL(20, 4), comment='EMI Amount')
    request_id = Column(String(20), comment='API Request id in case of remote storage through API')
    verification_mode = Column(String(1))
    captured_video = Column(String(100))
    processed_video = Column(String(100))
    face_match_score = Column(DECIMAL(20, 4))
    face_match_distance = Column(DECIMAL(20, 4))
    cam_org_img = Column(String(100), comment='Path of the Image captured from camera')
    otp_gen = Column(String(5))
    otp_det = Column(String(8))
    video_status = Column(String(1), comment='U - Uploaded, P - Processing, C - Completed')
    signature = Column(String(100), comment='Path of the signature drawn by the user')
    sign_status = Column(CHAR(1), server_default=text("'N'"), comment='Signature Approved or Rejected- A - Approved, R - Rejected, P - Pending')
    sign_remarks = Column(String(50), comment='Remarks by User')
    pdf_path = Column(String(100))
    app_step_nxt_num = Column(Integer, comment='Next App Step number')
    app_step_nxt_name = Column(String(150), comment='Next App Step Name')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified  COMMENT  COMMENT , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ApplicationDtl, "before_update", before_update_log('application_dtls','application_id'))

class AppointmentDtl(Base):
    __tablename__ = 'appointment_dtls'
    __table_args__ = {'comment': 'Appointment details  Details Table'}

    appointment_id = Column(Integer, primary_key=True, nullable=False, comment='Id of the appointment', autoincrement=True)
    appointment_type = Column(String(20), nullable=False, comment='Type of appointment. Meeting , Call , Conference ')
    appointment_owner = Column(String(20), nullable=False, comment='Officer who fixed the appointment')
    appointment_date = Column(Date, nullable=False, comment='Date of the appointment')
    appointment_day = Column(String(20), nullable=False, comment='Day of the appointment')
    start_time = Column(TIMESTAMP, comment='Start time of the appointment')
    end_time = Column(TIMESTAMP, comment='End time of the appointment')
    time_zone = Column(String(20))
    target_person_type = Column(String(15), nullable=False, comment='Customer , Lead , Others ')
    target_person_id = Column(Integer, nullable=False, comment='Customer or Lead Id')
    topic = Column(String(100), nullable=False, comment='Topic of the appointment')
    venue = Column(String(250), nullable=False, comment='Venue details of the appointment')
    agent_person_id = Column(Integer, comment='Agent Id')
    appointment_status = Column(String(1), nullable=False, server_default=text("'O'"), comment='Status of the appointment O - Open, C - Completed, E - Expired, R - Rescheduled')
    entity_cre_flg = Column(CHAR(1), nullable=False, server_default=text("'Y'"), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), nullable=False, server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')
    appointment_comments = Column(String(160), server_default=text("'appointment comments'"))

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppointmentDtl, "before_update", before_update_log('appointment_dtls', 'appointment_id'))

class AuditDtl(Base):
    __tablename__ = 'audit_dtls'
    __table_args__ = (
        Index('ix1_audit_dtls', 'req_orig', 'org_id'),
        {'comment': 'API Request Response Deails Table'}
    )

    req_id = Column(Integer, primary_key=True, nullable=False, comment='Id of the Request - incremented for each record', autoincrement=True)
    req_orig = Column(String(50), nullable=False, comment='Originator of the Request - API Call')
    calling_url = Column(Text, nullable=False, comment='Calling url name')
    request = Column(Text, nullable=False, comment='Actual Request that came inside the application')
    response = Column(Text, nullable=False, comment='Actual Response that was given back by the application')
    api_name = Column(Text, nullable=False, comment='Name of the API that is getting called - ')
    resp_type = Column(String(1), comment='Nature of Response - F- Failure, S-Success')
    reason = Column(String(100))
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified  COMMENT  COMMENT , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

class AuthGroup(Base):
    __tablename__ = 'auth_group'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(80), nullable=False, unique=True)


class AuthMatrixConfig(Base):
    __tablename__ = 'auth_matrix_config'
    __table_args__ = (
        Index('ix1_auth_matrix_config', 'auth_matrix_code', 'org_id'),
        {'comment': 'Authorization Matrix'}
    )

    auth_matrix_id = Column(Integer, primary_key=True, nullable=False, comment='Auth matrix unique row ID', autoincrement=True)
    auth_matrix_code = Column(String(25), nullable=False, comment='Autorization Matrix code for escalation matrix')
    role_code = Column(String(15), comment='Role Id defined for the bank')
    auth_nature = Column(CHAR(1), nullable=False, comment='Nature of the Action - C - Creator, A - Approver, R - Reviewer')
    auth_level = Column(Integer, nullable=False, comment='Number of level for this authorization')
    Idle_measure_unit = Column(String(3), nullable=False, server_default=text("'DYS'"), comment='Measure of idle time in MIN-Minutes, HRS-Hours, DYS-Days, WEK-Week, MON-Month')
    Idle_measure_value = Column(Integer, nullable=False, server_default=text("'1'"), comment='Value of the idel measure unit 30 MIN, 1 HRS, 4 DYS etc')
    br_scope = Column(CHAR(1), nullable=False, server_default=text("'B'"), comment='Scope of the branch of the approval authhority. B - Same branch, S - Set , A - All')
    br_set_id = Column(String(10), nullable=False, comment='If the approving branch scope is a SET , then the branch set to which the escalation can be made')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')


    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

class AuthToken(Base):
    __tablename__ = 'auth_token'

    key = Column(Text, primary_key=True)
    created = Column(DATETIME(fsp=6), nullable=False)
    user_id = Column(String(15), nullable=False, unique=True)


class AuthUser(Base):
    __tablename__ = 'auth_user'

    id = Column(Integer, primary_key=True, autoincrement=True)
    password = Column(String(128), nullable=False)
    last_login = Column(DATETIME(fsp=6))
    is_superuser = Column(TINYINT(1), nullable=False)
    username = Column(String(150), nullable=False, unique=True)
    first_name = Column(String(30), nullable=False)
    last_name = Column(String(150), nullable=False)
    email = Column(String(254), nullable=False)
    is_staff = Column(TINYINT(1), nullable=False)
    is_active = Column(TINYINT(1), nullable=False)
    date_joined = Column(DATETIME(fsp=6), nullable=False)


class CalendarDtl(Base):
    __tablename__ = 'calendar_dtls'
    __table_args__ = {'comment': 'Calender Dtls Table'}

    mmyyyy = Column(Integer, primary_key=True, nullable=False, comment='Month and year of the selected date')
    holiday = Column(String(31), comment='Working day and holiday of selected month')
    br_id = Column(Integer, comment='ID of the branch')
    br_set = Column(String(30), comment='Branch set')
    Start_time = Column(String(20), comment='Start time of the branch')
    End_time = Column(String(20), comment='End time of the branch')
    call_duration = Column(String(20), comment='Duration of the call')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CalendarDtl, "before_update", before_update_log('calendar_dtls', 'mmyyyy'))

class CallRequest(Base):
    __tablename__ = 'call_requests'
    __table_args__ = (
        Index('ix3_call_requests', 'application_id', 'cust_id', 'org_id'),
        Index('ix1_call_requests', 'application_id', 'org_id'),
        Index('ix4_call_requests', 'agent_id', 'org_id'),
        Index('ix2_call_requests', 'cust_id', 'org_id'),
        {'comment': 'Call Requests Table'}
    )

    req_id = Column(Integer, primary_key=True, nullable=False, comment='Auto Generated Request Id',autoincrement=True)
    agent_id = Column(Integer, comment='agent id')
    application_id = Column(Integer, nullable=False, comment='Id of the application')
    cust_id = Column(Integer, nullable=False, comment='customer id')
    pref_lang = Column(CHAR(5), comment='Preferred language')
    consent = Column(CHAR(1), comment='Y - Yes , N - No')
    sched_type = Column(CHAR(1), comment='I - Immediate, L - Later')
    sched_on = Column(Date, comment='Scheduled on')
    time_zone = Column(String(10), comment='Time zone in which the organization operates')
    from_time = Column(String(9), comment='Scheduled from_time')
    to_time = Column(String(9), comment='Scheduled to_time')
    start_time = Column(String(15), comment='Start time of the video KYC')
    end_time = Column(String(15), comment='End time of the video KYC')
    call_status = Column(String(1), comment='I - In Progress, C - Completed , D- Disconnected, W-Waiting')
    rsn_type = Column(String(10), comment='Reason Type of the reasons')
    rsn_code = Column(String(15), comment='Reason Code under the reason type')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CallRequest, "before_update", before_update_log('call_requests', 'req_id'))

class CategoryDtl(Base):
    __tablename__ = 'category_dtls'
    __table_args__ = (
        Index('ix3_category_dtls', 'parent_cat_id', 'org_id'),
        Index('ix1_category_dtls', 'cat_name', 'cat_type', 'org_id'),
        Index('ix2_category_dtls', 'cust_id', 'org_id'),
        {'comment': 'Transaction category details table'}
    )

    cat_id = Column(Integer, primary_key=True, nullable=False, comment='Unique ID of the Transaction Category', autoincrement=True)
    cat_name = Column(String(100), nullable=False, comment='Description of Category')
    cat_type = Column(String(2), nullable=False, comment='Type of Category E-Expense, I-Income')
    cat_cust_type = Column(String(1), nullable=False, comment='Nature of the category . R - Retail , C - Corporate')
    cat_owner = Column(String(1), nullable=False, comment='This category is created by S - System, C - Customer')
    cust_id = Column(String(15), comment='Customer who wanted this category')
    level = Column(Integer, nullable=False, comment='LEVEL of COA - 0 - Root categrory , 1 - Sub category Level 1 , 2 -  Sub category Level 2')
    parent_cat_id = Column(Integer, nullable=False, comment='Parent Category ID')
    recurring = Column(CHAR(1), nullable=False, comment='Valid Values - Y , N. Column to tell if this kind of category is repetitive in nature')
    category_img = Column(String(255), comment='Image path of the category where it is stored')
    category_color = Column(String(45), comment='Color code to be used to denote the category in the screen')
    coa_head = Column(CHAR(1), nullable=False, comment='A-assests,L-liability,I-income,E-Expense,C-equity')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CategoryDtl, "before_update", before_update_log('category_dtls', 'cat_id'))

class CoApplicant(Base):
    __tablename__ = 'co_applicants'
    __table_args__ = (
        Index('ix2_co_applicants', 'cust_id', 'org_id'),
        Index('ix1_co_applicants', 'application_id', 'org_id'),
        {'comment': 'This table is used to store all the co-applicants for each application'}
    )

    co_applicant_id = Column(Integer, primary_key=True, nullable=False, comment='Co-Applicant auto increment ID')
    application_id = Column(Integer, nullable=False, comment='Id of the application')
    cust_id = Column(String(15), nullable=False, comment='Id of the customer for whom the application is initiated for')
    applicant_type = Column(String(1), nullable=False, server_default=text("'C'"), comment='C = Co-Applicant')
    signature = Column(String(45), comment='Path of the signature drawn by the user')
    cam_org_img = Column(String(100), comment='Path of the Image captured from camera for the Co Applicant')
    app_status = Column(String(1), nullable=False, server_default=text("'I'"), comment='Status of the application. I - Initiated, P - Progress, C - Completed, R - Rejected for the Co Applicant')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1), nullable=False, server_default=text("'N'"))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Bank id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CoApplicant, "before_update", before_update_log('co_applicants', 'application_id'))

class CoaDtl(Base):
    __tablename__ = 'coa_dtls'
    __table_args__ = {'comment': 'Chart of Account Details'}

    coa_id = Column(Integer, primary_key=True, nullable=False, comment='Unique ID of the COA', autoincrement=True)
    coa_name = Column(String(100), nullable=False, comment='Description of COA')
    coa_type = Column(String(2), nullable=False, comment='Type of COA H-Head , L-Ledger , S-Subledger1')
    level = Column(Integer, nullable=False, comment='LEVEL of COA - 0 - HEADER , 1 - Expense Category Level 1 , 2 - Expense Category Level 2')
    parent_coa_id = Column(Integer, nullable=False, comment='Parent COA ID')
    head = Column(Integer, comment='A-assests,L-liability,I-income,E-Expense,C-equity')
    sys_cat_id = Column(Integer, comment='Category Id of the Transaction')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CoaDtl, "before_update", before_update_log('coa_dtls', 'coa_id'))

class CountryDtl(Base):
    __tablename__ = 'country_dtls'
    __table_args__ = (
        Index('ix2_country_dtls', 'crncy_code', 'org_id'),
        Index('ix1_country_dtls', 'cntry_code', 'org_id'),
        {'comment': 'Country table with its details'}
    )

    cntry_code = Column(String(20), primary_key=True, nullable=False, comment='ISO Currency Code in 2 alphabets')
    cntry_code_alpha3 = Column(String(3), comment='ISO Currency Code in 3 alphates')
    iso_cntry_num = Column(Integer, comment='ISO Country number where the currency is used')
    cntry_name = Column(String(60), comment='Country name uses this currency')
    crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code. INR , USD etc')
    status = Column(String(1), nullable=False, server_default=text("'O'"), comment='O - Operate, B - Block')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), nullable=False, comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), nullable=False, comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CountryDtl, "before_update", before_update_log('country_dtls', 'cntry_code'))

class CurrencyDtl(Base):
    __tablename__ = 'currency_dtls'
    __table_args__ = {'comment': 'Currency table with its details'}

    crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code. INR , USD etc')
    crncy_name = Column(String(40), comment='Name of Currency. Indian Rupee , Americal Dollar etc')
    alt_crncy_name = Column(String(40), comment='Currency Name in alternate language')
    currency_id = Column(Integer, comment='HTML ID of the currency symbol')
    dec_digits = Column(Integer, comment='Number of digits allowed for decimal')
    dec_desc = Column(String(10), comment='Name of the decimal description. Like P - Paise , C - Cents')
    rnd_off_ind = Column(String(1), comment='Rounding off Indicator. H - Nearest , L - Lowest')
    rnd_off_amt = Column(DECIMAL(20, 4), comment='Number of digits that is allowed maximum for rounding off')
    crncy_alias = Column(String(3), comment='Alias of the Currency to maintain a sort order')
    iso_crncy_num = Column(Integer, comment='ISO Currency Number')
    strong_crncy = Column(String(1), server_default=text("'N'"), comment=' Indicates if this is a strong currency for conversion rate')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), nullable=False, comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), nullable=False, comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CurrencyDtl, "before_update", before_update_log('currency_dtls', 'crncy_code'))

class CustBankDtl(Base):
    __tablename__ = 'cust_bank_dtls'

    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Customer ID')
    bank_name = Column(String(50), comment='Name of the Bank')
    bank_code = Column(String(11), comment='Code of the Bank')
    branch_code = Column(String(11), comment='Code of the Branch')
    swift_code = Column(String(15), comment='Swift Code of the Bank')
    acct_number = Column(String(50), comment='Account Number of the Bank')
    iban_number = Column(String(50), comment='International bank Number of the Bank')
    sector = Column(String(30), comment='Sector to which the bank belongs to')
    image_path = Column(String(50), comment='Path where the image of the bank is stored')
    payment_integration = Column(String(4), server_default=text("'N'"), comment='Y - Integrated, N - Not Integrated')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, server_default=text("'JENNY'"), comment='Bank id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CustBankDtl, "before_update", before_update_log('cust_bank_dtls', 'cust_id'))

class CustCategory(Base):
    __tablename__ = 'cust_category'
    __table_args__ = {'comment': 'customer Category Details'}

    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Customer who wanted this configuration')
    global_change = Column(String(1), server_default=text("'Y'"), comment='Is this categorization applicable for all accounts of the same customer Or only for specific account. G - Global , S - Specific ')
    entity_int_id = Column(String(25), comment='Internal Id of the entity')
    tran_id = Column(String(15), primary_key=True, nullable=False, comment='Transaction id of the transaction')
    tran_date = Column(Date, primary_key=True, nullable=False, comment='Date of the Transaction ')
    sys_cat_id = Column(Integer, primary_key=True, nullable=False, comment='Unique ID of the Transaction Category')
    sys_cat_name = Column(String(100), nullable=False, comment='Description of Category')
    sys_cat_type = Column(String(2), nullable=False, comment='Type of Category E-Expense, I-Income')
    sys_cat_level = Column(Integer, nullable=False, comment='LEVEL of COA - 0 - HEADER , 1 - Expense Category Level 1 , 2 - Expense Category Level 2')
    sys_parent_cat_id = Column(Integer, nullable=False, comment='Parent Category ID')
    sys_head = Column(Integer, nullable=False, comment='A-assests,L-liability,I-income,E-Expense,C-equity')
    user_cat_id = Column(Integer, primary_key=True, nullable=False, comment='Unique ID of the Transaction Category')
    user_cat_name = Column(String(100), nullable=False, comment='Description of Category')
    user_cat_type = Column(String(2), nullable=False, comment='Type of Category E-Expense, I-Income')
    user_cat_level = Column(Integer, nullable=False, comment='LEVEL of COA - 0 - HEADER , 1 - Expense Category Level 1 , 2 - Expense Category Level 2')
    user_parent_cat_id = Column(Integer, nullable=False, comment='Parent Category ID')
    user_head = Column(Integer, nullable=False, comment='A-assests,L-liability,I-income,E-Expense,C-equity')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CustCategory, "before_update", before_update_log('cust_category', 'cust_id'))

class CustContact(Base):
    __tablename__ = 'cust_contact'
    __table_args__ = (
        Index('ix1_cust_contact', 'cust_id', 'org_id'),
        Index('uix1_cust_contact', 'contact_type', 'cust_id', 'org_id', 'contact_sub_type', unique=True),
        {'comment': 'Customer Contact Details Table'}
    )

    cont_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    contact_type = Column(String(10), nullable=False, comment='Type of Contact. PHONE , EMAIL , ADDRESS ')
    contact_sub_type = Column(String(25), nullable=False, comment='Sub Type of the contanct. HOME , PERSONAL , OFFICE ')
    address_format = Column(String(1), comment='Format of the address. F - FreeText , S - Structured')
    address_line1 = Column(Text, comment='Address Line 1 of the customer')
    address_line2 = Column(Text, comment='Address Line 2 of the customer')
    address_line3 = Column(Text, comment='Address Line 3 of the customer')
    city = Column(String(50), comment='City of the customer')
    state = Column(String(50), comment='State of the customer')
    country = Column(String(50), comment='Country of the customer')
    region = Column(String(50), comment='Region of the customer')
    pin = Column(String(8), comment='Pin code of the customer')
    phone_no = Column(String(10), comment='Phone number of the customer')
    phoneno_localcode = Column(String(2), comment='Local code of the customer')
    phoneno_countrycode = Column(String(2), comment='Country code of the customer')
    email = Column(String(50), comment='Email id of the customer')
    building_num = Column(Integer, server_default=text("'0'"), comment='House Number or Door No')
    Plot_num = Column(Integer, server_default=text("'0'"), comment='Plot Number ')
    premise_name = Column(String(20), comment='Building Name , community name')
    floor_no = Column(Integer, comment='Floor Number ')
    street_no = Column(Integer, comment='Street Number')
    street_name = Column(String(20), comment='Name of the street')
    locality = Column(String(20), comment='Locality of the customer')
    domicle = Column(String(20), comment='Domicle of the customer')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified  COMMENT  COMMENT , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP)
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP)
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CustContact, "before_update", before_update_log('cust_contact', 'cust_id'))

class CustomerDtl(Base):
    __tablename__ = 'customer_dtls'
    __table_args__ = (
        Index('ix2_customer_dtls', 'cust_phone', 'org_id'),
        Index('uix1_customer_dtls', 'cust_email', 'cust_phone', 'org_id', unique=True),
        Index('ix1_customer_dtls', 'cust_email', 'org_id'),
        {'comment': 'Customer Details Table'}
    )

    cust_id = Column(Integer, primary_key=True, nullable=False, comment='Auto Generated cust id', autoincrement=True)
    cust_email = Column(String(30), nullable=False, comment='Email id of the customer')
    cust_phone_cntry = Column(String(2), nullable=False, comment='Country code of the customer')
    cust_phone = Column(String(15), nullable=False, comment='Phone number of the customer')
    cust_type = Column(String(1), nullable=False, comment='Customer type R - Retail , C - Corporate')
    preferred_language = Column(String(45), comment='Preferred Language of the cust')
    cust_status = Column(String(1), server_default=text("'A'"), comment=' A- Active, I-Inactive, D-Disabled')
    entity_status = Column(String(1), server_default=text("'N'"), comment='Status of the entity. For Account , N-None, C-Created')
    entity_id = Column(String(30), comment='External Id of the entity')
    cust_dob = Column(Date, comment='DOB of the customer')
    doc_number = Column(String(30), comment='Number of document')
    gender = Column(String(1), comment='Gender of the customer')
    marital_status = Column(String(1), comment='D - Divorced, M - Married, U - Unmarried, S - Single')
    disabled_from_date = Column(Date, comment='cust is disabled from this date')
    disabled_to_date = Column(Date, comment='cust is disabled until this date')
    employee_id = Column(String(10), comment='If the logged in cust id belongs to an Employee, then the employee id of the cust')
    gross_salary = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Salary received by the customer')
    view_access_id = Column(String(255), comment='Access code to view a certain screen')
    temp_view_access_id = Column(String(255), comment='Temporary Access code allocated to the cust')
    temp_view_valid_till = Column(Date, comment='Temporary access valid till')
    primary_rm_id = Column(String(8), comment='Primary Relationship Manager id')
    secondary_rm_id = Column(String(8), comment='Secondary Relationship Manager id')
    income_avg = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Month on Month Average Income of a customer')
    expense_avg = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Month on Month Average Expense of a customer')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation cust id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed cust id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    if PII_ENCRYPT == "YES":
        first_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        middle_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        last_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        preferred_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_first_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_middle_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_last_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_preferred_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
    else:
        first_name = Column(String(30), comment='Name of the file that is being uploaded by the customer')
        middle_name = Column(String(30), comment='Middle name of the cust')
        last_name = Column(String(30), comment='Last name of the cust')
        preferred_name = Column(String(30), comment='Preferred name of the cust')
        alt_first_name = Column(String(30), comment='First name of the cust in alternat language')
        alt_middle_name = Column(String(30), comment='Middle name of the cust in alternat language')
        alt_last_name = Column(String(30), comment='Last name of the cust in alternat language')
        alt_preferred_name = Column(String(30), comment='Preferred Language of the cust in alternat language')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(CustomerDtl, "before_update", before_update_log('customer_dtls', 'cust_id'))

class DailyTranDtl(Base):
    __tablename__ = 'daily_tran_dtls'
    __table_args__ = (
        Index('daily_tran_dtls_UQ_1', 'tran_id', 'tran_date', 'part_tran_srl_num', 'entity_int_id', 'org_id', unique=True),
        {'comment': 'Transacton Details Table'}
    )

    int_tran_id = Column(Integer, primary_key=True, nullable=False, comment='Internal id generated for the transaction', autoincrement=True)
    tran_id = Column(String(15), nullable=False, comment='Transaction id of the transaction')
    tran_date = Column(Date, nullable=False, comment='Value date of the transaction')
    part_tran_srl_num = Column(Integer, nullable=False, comment='Part Transactions Srl Number')
    tran_type = Column(String(1), nullable=False, comment='Type of the Transaction. T - Transfer , C - Cash')
    tran_sub_type = Column(String(2), nullable=False, comment='Sub-Type of the Transaction BI - Bank Induced , CI - Customer Induced')
    part_tran_type = Column(String(1), nullable=False, comment='D - Debit , C - Credit')
    entity_int_id = Column(String(25), nullable=False, comment='Internal Id of the entity')
    cust_id = Column(String(20), comment='Customer Id of the account number')
    value_date = Column(Date, nullable=False, comment='Value date of the transaction')
    sys_cat_id = Column(Integer, comment='Transaction Category Id allocated by System')
    user_cat_id = Column(Integer, comment='Transaction Category Id allocated by User')
    parent_sys_cat_id = Column(Integer, comment='Parent system category ID')
    parent_user_cat_id = Column(Integer, comment='Parent user category ID')
    sys_cat_name = Column(String(100), comment='System Transaction category labelled for training')
    user_cat_name = Column(String(100), comment='User Transaction category labelled for training')
    tran_amt = Column(DECIMAL(20, 4), nullable=False, server_default=text("'0.0000'"), comment='Transaction Amount')
    tran_crncy_code = Column(String(3), nullable=False, comment='Currency code in which the transaction has taken place')
    ref_crncy_code = Column(String(3), nullable=False, comment='Home currency code of the organization')
    rate = Column(DECIMAL(20, 4), comment='If transaction currency is different from home currency then the conversion rate used')
    ref_amt = Column(DECIMAL(20, 4), nullable=False, server_default=text("'0.0000'"), comment='Converted amount in Home currency code. ')
    br_id = Column(Integer, nullable=False, comment='Branch Id from which the transaction is initiated')
    pstd_flg = Column(String(1), server_default=text("'N'"), comment='Flag to express if the transaction is posted or not')
    tran_particular_1 = Column(String(50), comment='Transaction Particulars ')
    tran_particular_2 = Column(String(50), comment='Transaction Particulars ')
    tran_rmks_1 = Column(String(255), comment=' Transaction Remarks')
    tran_rmks_2 = Column(String(30), comment=' Transaction Remarks')
    merchant_cat_code = Column(String(30), comment=' Transaction Remarks')
    Orig_bank_code = Column(String(11), comment='Bank Code of the transaction originator bank')
    Orig_branch_code = Column(String(11), comment='Branch Code of the transaction originator bank')
    Orig_ifsc_code = Column(String(8), comment='IFSC Code of the transaction originator bank')
    ben_bank_code = Column(String(11), comment='Beneficiary Bank Code')
    ben_branch_code = Column(String(11), comment='Beneficiary Branch Code')
    ben_ifsc_code = Column(String(8), comment='Beneficairy IFSC Code')
    ben_acct_num = Column(String(20), comment='Beneficiary Acct Number')
    si_num = Column(String(12), comment='Standing instruction number')
    si_exec_date = Column(Date, comment='Standing Instruction executed date')
    instr_type = Column(String(5), comment='Type of the Instrument , DD, CHQ')
    instr_num = Column(String(16), comment='Number of the Instrument , DD, CHQ')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization for which this record belongs to ')
    bank_id = Column(String(8), primary_key=True, nullable=False, comment='Bankid which this record is created under')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(DailyTranDtl, "before_update", before_update_log('daily_tran_dtls', 'tran_id'))

class DjangoContentType(Base):
    __tablename__ = 'django_content_type'
    __table_args__ = (
        Index('django_content_type_app_label_model_76bd3d3b_uniq', 'app_label', 'model', unique=True),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    app_label = Column(String(100), nullable=False)
    model = Column(String(100), nullable=False)


class DjangoMigration(Base):
    __tablename__ = 'django_migrations'

    id = Column(Integer, primary_key=True, autoincrement=True)
    app = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)
    applied = Column(DATETIME(fsp=6), nullable=False)


class DjangoSession(Base):
    __tablename__ = 'django_session'

    session_key = Column(String(40), primary_key=True)
    session_data = Column(LONGTEXT, nullable=False)
    expire_date = Column(DATETIME(fsp=6), nullable=False, index=True)


class DrfApiLog(Base):
    __tablename__ = 'drf_api_logs'
    __table_args__ = (
        CheckConstraint('(`status_code` >= 0)'),
    )

    id = Column(BigInteger, primary_key=True)
    added_on = Column(DATETIME(fsp=6), nullable=False)
    api = Column(String(1024), nullable=False)
    headers = Column(LONGTEXT, nullable=False)
    body = Column(LONGTEXT, nullable=False)
    method = Column(String(10), nullable=False, index=True)
    client_ip_address = Column(String(50), nullable=False)
    response = Column(LONGTEXT, nullable=False)
    status_code = Column(SMALLINT, nullable=False, index=True)
    execution_time = Column(DECIMAL(8, 5), nullable=False)


class EntityAcces(Base):
    __tablename__ = 'entity_access'
    __table_args__ = {'comment': 'Entity detail table holds data of User Access '}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Id of the financial services to which the entity is associated')
    entity_int_id = Column(String(25), primary_key=True, nullable=False, comment='Internal Id of the entity')
    user_id = Column(Integer, comment='User Id of the customer')
    access_id = Column(String(20), nullable=False, comment='Access code given to the user for the account')
    cust_id = Column(String(15), comment='Customer Id who holds this entity')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(EntityAcces, "before_update", before_update_log('entity_access', 'entity_int_id'))

class EntityDtl(Base):
    __tablename__ = 'entity_dtls'
    __table_args__ = (
        Index('IX_UQ_ENT_NCK_NME', 'cust_id', 'entity_nick_name', 'bank_id', unique=True),
        Index('IX_UQ_ENT_EXT_ID', 'entity_ext_id', 'bank_code', 'bank_id', unique=True),
        {'comment': 'Entity detail table holds data of all products such as Accounts, Cards  ,  Insurance '}
    )

    entity_id = Column(Integer, primary_key=True, nullable=False)
    entity_int_id = Column(String(25), primary_key=True, nullable=False)
    entity_nick_name = Column(String(50), comment='Name of the Account,card or Insurance Policy')
    entity_ext_id = Column(String(25), nullable=False, comment='External Id of the entity')
    iban_num = Column(String(35), comment='IBAN Number of the account')
    entity_name = Column(String(50), comment='Name of the Account,Card or Insurance Policy')
    entity_alt_name = Column(String(50), comment='Name of the entity in alternate language')
    entity_branch = Column(String(8), comment='Id of the branch to which the entity is associated')
    int_ext_flg = Column(CHAR(1), comment='Internal External Flg - I or E')
    bank_code = Column(String(11))
    bank_name = Column(String(50), comment='Name of the bank')
    branch_code = Column(String(11))
    branch_name = Column(String(50), comment='Name of the branch')
    ifsc_code = Column(String(10), comment='IFSC Code of the branch')
    upi_id = Column(String(50), comment='UPI ID for payments')
    user_id = Column(Integer)
    cust_id = Column(String(15))
    entity_cust_type = Column(String(1), nullable=False, comment='Customer type who holds this entity. R- Retail , C- Corporate')
    entity_nature = Column(String(1), nullable=False, comment='Nature of Entity A - Account, C - Card, I - Insurance')
    product_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc')
    product_code = Column(String(20), nullable=False, comment='Code of the product like , KIDSAVER , 30DAYDEPOSIT')
    crncy_code = Column(String(3), nullable=False, comment='Currency Code in which this product operates')
    entity_limit = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Limit that is allocated for this Entity')
    entity_curr_bal = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Current Balnce if the entity is account')
    eff_interest_rate = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Interest rate of the account')
    entity_open_date = Column(Date, nullable=False, comment='Date on which this entity is effective from')
    entity_cls_flg = Column(String(1), server_default=text("'N'"), comment='Entity Close Flag. Has Y if it is closed ')
    entity_cls_date = Column(Date, comment='Entity close date. The date on which the entity has been closed')
    entity_cash_dr_lim = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Debit limit through Cash mode')
    entity_xfer_dr_lim = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Debit limit through Transfer mode')
    primary_rm_id = Column(String(8), comment='Primary Relationship manager id')
    secondary_rm_id = Column(String(8), comment='Secondary Relationship manager id')
    chq_opt_flg = Column(String(1), comment='Flag describes if chequebook has been opted')
    sweep_opt_flg = Column(String(1), server_default=text("'N'"), comment='Flag describes if sweep has been opted')
    sweep_pool_id = Column(String(12), comment='Pool Id under which the entity belongs to')
    asset_category = Column(String(1), nullable=False, server_default=text("'P'"), comment='Category of Asset. For Account, N - Non performing, P - performing.')
    entity_status = Column(String(1), server_default=text("'A'"), comment='Status of the entity. For Account , A-Active, D - Dormant, I - Inactive.For Insurance, A-Active, E - Elapsed, I- Inactive ')
    entity_pd_days = Column(Integer, server_default=text("'0'"), comment='Number of days past due')
    entity_pd_times = Column(Integer, server_default=text("'0'"), comment='Number of times it has crossed past due')
    upcoming_due_date = Column(Date, comment='Upcoming due date')
    upcoming_due_amt = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Upcoming due amount')
    total_due_amt = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Total due amount till date')
    coll_mode_ind = Column(String(1), comment='Mode by which collection can be made ')
    coll_acct_ind = Column(String(1), comment='Collection done through Account. I - Internal , E - External ')
    coll_acct_num = Column(String(1), comment='Account number from which the collection to be made')
    coll_acct_name = Column(String(30), comment='Name of the collection Account Number')
    coll_acct_bank_code = Column(String(11), comment='Bank code of the collection Account Number')
    coll_acct_branch_code = Column(String(11), comment='Branch code of the collection Account Number')
    coll_acct_swift_code = Column(String(45), comment='Swift code of the collection Account Number')
    pay_mode_ind = Column(String(1), comment='Mode by which payment can be made ')
    pay_acct_ind = Column(String(1), comment='Payment done through Account. I - Internal , E - External ')
    pay_acct_num = Column(String(1), comment='Account number from which the payment to be made')
    pay_acct_name = Column(String(30), comment='Name of the payment Account Number')
    pay_acct_bank_code = Column(String(11), comment='Bank code of the payment Account Number')
    pay_acct_branch_code = Column(String(11), comment='Branch code of the payment Account Number')
    pay_acct_swift_code = Column(String(45), comment='Swift code of the collection Account Number')
    tot_installments = Column(Integer, server_default=text("'0'"), comment='Total Installments of the account')
    rem_installments = Column(Integer, server_default=text("'0'"), comment='Remaining Installments of the account')
    maturity_date = Column(Date, comment='Maturity date of the account')
    bank_id = Column(String(8), primary_key=True, nullable=False, comment='Bank id to which this record belongs to')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    goal_id = Column(String(20), comment='ID given to the goal by the system')
    providerId = Column(Integer, comment='Yodlee providerId')
    provider_account_id = Column(String(30))
    yodlee_status = Column(String(30), comment='LOGIN_IN_PROGRESS, IN_PROGRESS, SUCCESS, Partial SUCCESS, FAILED')
    requestId = Column(String(30), comment='Yodlee account request id')
    aggregation_source = Column(String(30))
    acc_added_type = Column(String(1), comment='M - Manual, A- Auto ')
    yodlee_account_id = Column(Integer, comment='Yodlee Approved Account ID')
    total_limit = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Credit Card Max Limit for account')
    available_balance = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Credit Card Available Balacnce in the account')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(EntityDtl, "before_update", before_update_log('entity_dtls', 'entity_id'))

class FeesDtl(Base):
    __tablename__ = 'fees_dtls'
    __table_args__ = {'comment': 'All fee details'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    fee_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the fee')
    fee_crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code of the fee')
    fee_desc = Column(String(30), comment='Description of fee')
    fee_desc_alt = Column(String(30), comment='Description of fee in alternate language')
    fee_amt_ind = Column(CHAR(1), comment='Amount Indicator of fee - fixed , p - percentage')
    fee_amount = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Amount of fee if it is a fixed')
    fee_pcnt = Column(DECIMAL(4, 2), server_default=text("'0.00'"), comment='Percentage for the fee amount ')
    tax_apply = Column(String(1), comment='Is tax applied for this fee')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization which this record is created under')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FeesDtl, "before_update", before_update_log('fees_dtls', 'fee_code'))

class FinservBranch(Base):
    __tablename__ = 'finserv_branch'
    __table_args__ = {'comment': 'Branch Configuration details'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    br_id = Column(Integer, primary_key=True, nullable=False, comment='Unique id of a branch within a bank')
    br_desc = Column(String(30), comment='Internal Name of the branch')
    br_nature = Column(String(1), nullable=False, comment='Nature of the branch. V - Virtual , R - Real')
    br_type = Column(String(1), nullable=False, comment='Type of the branch, V - Virtual, M - Mall, R - Rural, U - Urban')
    br_code = Column(String(30), comment='External code of the branch')
    br_name = Column(String(30), comment='External Name of the branch')
    br_desc_alt = Column(String(50), comment='Branchs name in alternate language')
    br_address1 = Column(String(80), comment='Address line1')
    br_address2 = Column(String(80), comment='Address line2')
    city_code = Column(String(30), comment='City code of the branch')
    state_code = Column(String(8), comment='State code of the branch')
    pin_code = Column(String(8), comment='Pin code of the branch')
    country_code = Column(String(8), comment='Country Code of the branch')
    wkly_off = Column(String(7), comment='Days which are weekly off SAT,SUN,MON')
    br_cls_date = Column(Date, comment='Date for which the branch is closed')
    br_bod_date = Column(Date, comment='Date on which the bank is operating')
    br_alias = Column(String(3), comment='Alias name of branch')
    home_crncy_code = Column(String(3), comment='Home currency code of the bank')
    week_begins_on = Column(String(3), comment='Week begins on SUN,MON,')
    time_zone = Column(String(10), comment='Time zone in which the bank operates')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Bank id under which this record is added')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FinservBranch, "before_update", before_update_log('finserv_branch', 'finserv_id'))

class FinservContact(Base):
    __tablename__ = 'finserv_contact'
    __table_args__ = {'comment': 'Customer Contact Details Table'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    contact_type = Column(String(10), primary_key=True, nullable=False, comment='Type of Contact. PHONE , EMAIL , ADDRESS ')
    contact_sub_type = Column(String(25), primary_key=True, nullable=False, comment='Sub Type of the contanct. HOME , PERSONAL , OFFICE ')
    address_format = Column(String(1), comment='Format of the address. F - FreeText , S - Structured')
    address_line1 = Column(Text, comment='Address Line 1 of the customer')
    address_line2 = Column(Text, comment='Address Line 2 of the customer')
    address_line3 = Column(Text, comment='Address Line 3 of the customer')
    city = Column(String(30), comment='City of the customer')
    state = Column(String(8), comment='State of the customer')
    country = Column(String(30), comment='Country of the customer')
    region = Column(String(8), comment='Region of the customer')
    pin = Column(String(8), comment='Pin code of the customer')
    phone_no = Column(String(10), comment='Phone number of the customer')
    phoneno_localcode = Column(String(2), comment='Local code of the customer')
    phoneno_countrycode = Column(String(2), comment='Country code of the customer')
    email = Column(String(50), comment='Email id of the customer')
    building_num = Column(Integer, server_default=text("'0'"), comment='House Number or Door No')
    Plot_num = Column(Integer, server_default=text("'0'"), comment='Plot Number ')
    premise_name = Column(String(20), comment='Building Name , community name')
    floor_no = Column(Integer, comment='Floor Number ')
    street_no = Column(Integer, comment='Street Number')
    street_name = Column(String(20), comment='Name of the street')
    locality = Column(String(20), comment='Locality of the customer')
    domicle = Column(String(20), comment='Domicle of the customer')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FinservContact, "before_update", before_update_log('finserv_contact', 'finserv_id'))

class FinservDtl(Base):
    __tablename__ = 'finserv_dtls'
    __table_args__ = {'comment': 'Financil Service Details Table'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    finserv_type = Column(String(15), nullable=False, comment='Type of the Financial Services company. B - Bank, I - Insurance, P - P2P lenders, C - Cards')
    finserv_name = Column(String(50), comment='Name of the Financial Services company where the customer has an entity')
    cntry_code = Column(String(20), nullable=False, comment='ISO Currency Code in 2 alphabets')
    swift_code = Column(String(15), comment='Swift Code of the fs-org')
    sector = Column(String(30), comment='Sector to which the fs-org belongs to')
    image_path = Column(String(50), comment='Path where the image of the fs-org is stored')
    pymt_intgn = Column(String(4), server_default=text("'N'"), comment='Payment Integration available or not. Y - Integrated, N - Not Integrated')
    ocr_enabled = Column(String(1), server_default=text("'N'"), comment='OCR for reading the bank statement is enabled or not')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FinservDtl, "before_update", before_update_log('finserv_dtls', 'finserv_id'))

class FormDetail(Base):
    __tablename__ = 'form_details'
    __table_args__ = (
        Index('idx2_form_details', 'form_name', 'section_name', 'field_name'),
    )

    id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    form_id = Column(String(30), primary_key=True, nullable=False)
    form_name = Column(String(30), nullable=False, index=True)
    section_id = Column(String(30), primary_key=True, nullable=False)
    section_name = Column(String(30), nullable=False)
    section_identifier = Column(String(2), comment='MA - Main Applicant, RP - Related Party, OF - Official')
    field_id = Column(String(35), primary_key=True, nullable=False)
    order_id = Column(Integer)
    field_name = Column(String(30), nullable=False)
    field_help_info = Column(String(50))
    field_type = Column(String(10), nullable=False, server_default=text("'text'"))
    field_pattern = Column(String(20))
    error_msg = Column(String(50))
    select_ref_type = Column(String(8))
    ocr_field = Column(String(30))
    allowed_field_format = Column(CHAR(1), server_default=text("'B'"), comment='N - Numbers only, L - Letters only, B - Both numbers and letters')
    is_mandatory = Column(CHAR(1), comment='Y - Yes, N - No, B - Based on another field')
    is_data_owner = Column(CHAR(1), server_default=text("'N'"))
    script_file = Column(String(30),comment="script based")
    condition = Column(CHAR(1), comment='S - Show when, H - Hide when')
    dependant_section_id = Column(String(30))
    dependant_field_id = Column(String(30))
    dependant_field_logic = Column(CHAR(2), comment='LT - Less than, GT - Greater than, ET - Equal to, LE - Less or Equal to, GE - Greater or Equal to, NE - Not equal to')
    logic_value = Column(DECIMAL(20, 4))
    default = Column(CHAR(1), server_default=text("'N'"), comment='Y - Yes, N - No')
    entity_cre_flg = Column(String(1), server_default=text("'N'"))
    del_flg = Column(String(1), server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FormDetail, "before_update", before_update_log('form_details', 'form_id'))

class FormSection(Base):
    __tablename__ = 'form_section'
    __table_args__ = (
        Index('idx_form_section', 'section_name', 'field_name'),
    )

    id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    section_id = Column(String(30), primary_key=True, nullable=False)
    section_name = Column(String(30), nullable=False)
    section_identifier = Column(String(45), comment='MA - Main Applicant, RP - Related Party, OF - Official')
    field_id = Column(String(35), primary_key=True, nullable=False)
    order_id = Column(Integer)
    field_name = Column(String(30), nullable=False)
    field_help_info = Column(String(50))
    field_type = Column(String(10), nullable=False, server_default=text("'text'"))
    field_pattern = Column(String(20))
    error_msg = Column(String(50))
    allowed_field_format = Column(CHAR(1), server_default=text("'B'"), comment='N - Numbers only, L - Letters only, B - Both numbers and letters')
    select_ref_type = Column(String(8))
    ocr_field = Column(String(30))
    is_mandatory = Column(CHAR(1), comment='Y - Yes, N - No, B - Based on another field')
    is_data_owner = Column(CHAR(1), server_default=text("'N'"))
    condition = Column(CHAR(1), comment='S - Show when, H - Hide when')
    dependant_section_id = Column(String(30))
    dependant_field_id = Column(String(30))
    dependant_field_logic = Column(CHAR(2), comment='LT - Less than, GT - Greater than, ET - Equal to, LE - Less or Equal to, GE - Greater or Equal to, NE - Not equal to')
    logic_value = Column(DECIMAL(20, 4))
    default = Column(CHAR(1), comment='Y - Yes, N - No')
    entity_cre_flg = Column(String(1), server_default=text("'N'"))
    del_flg = Column(String(1), server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(FormSection, "before_update", before_update_log('form_section', 'section_id'))

class GeneralCode(Base):
    __tablename__ = 'general_code'
    __table_args__ = (
        Index('ix1_general_code', 'ref_type', 'org_id', 'ref_code'),
        Index('ix3_general_code', 'ref_type', 'org_id'),
        Index('ix4_general_code', 'parent_ref_type', 'org_id'),
        Index('uix1_general_code', 'ref_type', 'ref_code', 'org_id', 'parent_ref_code', 'parent_ref_type', unique=True),
        Index('ix2_general_code', 'parent_ref_type', 'parent_ref_code', 'org_id'),
        {'comment': 'Configuration values called reference codes'}
    )

    gen_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    nature = Column(String(1), comment='If flag "C" - captured document, "A" - ref desc starts with API, Only the ref_code which has nature "G" allows to edit or delete')
    ref_type = Column(String(5), nullable=False, comment='Reference Type of the major categories. CITY , STATE, CNTRY etc')
    ref_type_desc = Column(String(30), nullable=False, comment='Description of the Parameter')
    ref_code = Column(String(15), nullable=False, comment='Reference code under the reference type')
    ref_desc = Column(String(50), comment='Description of the reference rode')
    alt_ref_desc = Column(String(50), comment='Alternat description of the Reference Code')
    parent_ref_type = Column(String(5))
    parent_ref_code = Column(String(15))
    level = Column(Integer, server_default=text("'1'"), comment='Level of the hierarchy')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(GeneralCode, "before_update", before_update_log('general_code', 'ref_type'))

class GoalDtl(Base):
    __tablename__ = 'goal_dtls'
    __table_args__ = {'comment': 'Goal details Table'}

    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Customer ID - customer_dtls table')
    goal_status = Column(String(1), server_default=text("'O'"), comment='Status of the goal. I - In Progress , O - Open , C - Completed')
    goal_nature = Column(String(1), nullable=False, comment='Type of Category E-Expense, I-Income')
    goal_name = Column(String(20), primary_key=True, nullable=False, comment='Name of the goal')
    goal_type = Column(String(1), nullable=False, comment='P - Percentage , A - Amount')
    goal_tgt_amt = Column(DECIMAL(20, 4), nullable=False, server_default=text("'0.0000'"), comment='Transaction Amount')
    goal_tgt_crncy = Column(String(3), nullable=False, comment='Currency for the target amount of the goal')
    goal_period_metric = Column(String(1), nullable=False, comment='M-Month,W-Week')
    goal_period_num = Column(Integer, nullable=False, comment='Number of days,weeks,month, year')
    goal_frequency = Column(String(1), nullable=False, comment='M-Monthly , D -Daily , Q-Quarterly')
    goal_inst_amt = Column(DECIMAL(20, 4), nullable=False, server_default=text("'0.0000'"), comment='Transaction Amount')
    goal_inst_crncy = Column(String(3), nullable=False, comment='Inst currency for the goal')
    expense_cat_id = Column(Integer, comment='Expense category id')
    frequency_type = Column(String(2), comment='A-Automatic, M-Manual')
    target_date = Column(Date, nullable=False, comment='Date by which the goal is going to be achieved')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(GoalDtl, "before_update", before_update_log('goal_dtls', 'cust_id'))

class InterviewDtl(Base):
    __tablename__ = 'interview_dtls'
    __table_args__ = (
        Index('ix1_interview_dtls', 'application_id', 'org_id'),
        {'comment': 'Interview Dtls Table'}
    )

    call_id = Column(Integer, primary_key=True, nullable=False, comment='Call Id for the initiated call')
    application_id = Column(Integer, primary_key=True, nullable=False, comment='Id of the application')
    ques_no = Column(Integer, primary_key=True, nullable=False, comment='Question number')
    question = Column(String(255), comment='Question asked to customer')
    answer = Column(String(255), comment='Answer for the questions')
    ans_status = Column(String(1), comment='M - Match, U - Unmatched , N - Not sure')
    remarks = Column(String(255), comment='Remarks for click not sure')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(InterviewDtl, "before_update", before_update_log('interview_dtls', 'application_id'))

class LeadContact(Base):
    __tablename__ = 'lead_contact'
    __table_args__ = {'comment': 'Lead Contact Details Table'}

    lead_id = Column(Integer, primary_key=True, nullable=False, comment='Lead ID')
    contact_type = Column(String(10), primary_key=True, nullable=False, comment='Type of Contact. PHONE , EMAIL , ADDRESS ')
    contact_sub_type = Column(String(25), primary_key=True, nullable=False, comment='Sub Type of the contanct. HOME , PERSONAL , OFFICE ')
    address_format = Column(String(1), comment='Format of the address. F - FreeText , S - Structured')
    address_line1 = Column(Text, comment='Address Line 1 of the customer')
    address_line2 = Column(Text, comment='Address Line 2 of the customer')
    address_line3 = Column(Text, comment='Address Line 3 of the customer')
    city = Column(String(30), comment='City of the customer')
    state = Column(String(8), comment='State of the customer')
    country = Column(String(30), comment='Country of the customer')
    region = Column(String(8), comment='Region of the customer')
    pin = Column(String(8), comment='Pin code of the customer')
    phone_no = Column(String(10), comment='Phone number of the customer')
    phoneno_localcode = Column(String(2), comment='Local code of the customer')
    phoneno_countrycode = Column(String(2), comment='Country code of the customer')
    email = Column(String(50), comment='Email id of the customer')
    building_num = Column(Integer, server_default=text("'0'"), comment='House Number or Door No')
    Plot_num = Column(Integer, server_default=text("'0'"), comment='Plot Number ')
    premise_name = Column(String(20), comment='Building Name , community name')
    floor_no = Column(Integer, comment='Floor Number ')
    street_no = Column(Integer, comment='Street Number')
    street_name = Column(String(20), comment='Name of the street')
    locality = Column(String(20), comment='Locality of the customer')
    domicle = Column(String(20), comment='Domicle of the customer')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified  COMMENT  COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP)
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP)
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(LeadContact, "before_update", before_update_log('lead_contact', 'lead_id'))

class LeadsDtl(Base):
    __tablename__ = 'leads_dtls'
    __table_args__ = {'comment': 'Lead details table'}

    lead_id = Column(Integer, primary_key=True, nullable=False, comment='Lead id generated automatically')
    first_name = Column(String(30), comment='First name of the lead')
    middle_name = Column(String(30), comment='Middle name of the lead')
    last_name = Column(String(30), comment='Last name of the lead')
    preferref_language = Column(String(10), comment='Preferred language of the lead')
    alt_first_name = Column(String(30), comment='First name of the lead in alternate language')
    alt_middle_name = Column(String(30), comment='Middle name of the lead in alternate language')
    alt_last_name = Column(String(30), comment='last name of the lead in alternate language')
    gender = Column(String(1), comment='Gender of the lead')
    salutation = Column(String(8), comment='Salutation Mr , Mrs. , Master , King , Prince , Queen ')
    lead_type = Column(CHAR(1), comment='C-Corporate, R- Retail')
    classification = Column(String(10), comment='Classification of the lead if exists')
    segment = Column(String(8), comment='Segment details of the customer')
    subsegment = Column(String(8), comment='sub-segment of the customer')
    rating = Column(String(8), comment='Rating / score given for the customer')
    ratingdate = Column(Date, comment='Date on which the rating has been given')
    nre_flg = Column(String(1), comment='flag determines if th customer is resident or non-resident')
    nre_since = Column(Date, comment='Attained NRE Status since')
    marital_status = Column(String(1), comment='Marital Status of the customer. U - Unmarried , M - Married , S-Single , D-Divorced')
    annual_salary = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='salary received by the customer')
    salary_currency = Column(String(3), comment='currency code in which salary is being received')
    income = Column(DECIMAL(20, 4), comment='Salary received by the customer')
    expense = Column(DECIMAL(20, 4), comment='Expense of the customer')
    employment_status = Column(CHAR(1), comment='E - Employed , U - Unemployed')
    company_category = Column(String(8), comment='Category to which the customers company belong to')
    company_name = Column(String(25), comment='Name of the company under which the customer is employed')
    num_of_dependants = Column(Integer, comment='Number of dependants ')
    num_of_child_dependants = Column(Integer, comment='Number of child dependants')
    primary_relationship_manager_id = Column(String(8), comment='Primary Relationship Manager id')
    secondary_relationship_manager_id = Column(String(8), comment='Secondary Relationship Manager id')
    lead_source = Column(String(25), comment='Source from where the lead came in WEB , IVR , CAMPAIGN , STALL , BRANCH ETC')
    campaign_name = Column(String(50), comment='Name of the campaign')
    lead_date = Column(Date, nullable=False, comment='date of the lead')
    referred_by = Column(String(25), comment='Name of the refereal')
    product_interested = Column(String(50), comment='Product the lead is interested on')
    product_proposed = Column(String(50), comment='Proposed product')
    status = Column(String(1), server_default=text("'O'"), comment='Status of lead')
    lead_to_cust = Column(String(1), server_default=text("'N'"), comment='Has the lead converted to customer')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Bankid which this record is created under')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(LeadsDtl, "before_update", before_update_log('leads_dtls', 'lead_id'))

class MailAuditDtl(Base):
    __tablename__ = 'mail_audit_dtls'
    __table_args__ = (
        Index('ix2_mail_audit_dtls', 'user_id', 'org_id'),
        Index('ix1_mail_audit_dtls', 'receiver_id', 'org_id'),
        {'comment': 'Email requests audit table'}
    )

    req_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True, comment='Id of the Request - incremented for each record')
    req_orig = Column(String(100), nullable=False, comment='Originator of the email')
    req_type = Column(String(1), nullable=False, comment='Type of the request (R - Password reset, A - New account activation)')
    req_code = Column(String(100), nullable=False, comment='Encryted code sent on the request')
    receiver_id = Column(String(100), nullable=False, comment='Email ID receiving the response')
    user_id = Column(Integer, nullable=False, comment='User ID receiving the email')
    api_name = Column(String(40), nullable=False, comment='Name of the API that is getting called')
    resp_type = Column(String(1), comment='Nature of Response - F- Failure, S-Success')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified, N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(MailAuditDtl, "before_update", before_update_log('mail_audit_dtls', 'req_id'))

class NetworkDir(Base):
    __tablename__ = 'network_dir'
    __table_args__ = {'comment': 'Network details TABLE'}

    ref_key = Column(String(30), primary_key=True, nullable=False, comment='Key of the Record')
    file_source = Column(String(30), primary_key=True, nullable=False, comment='Source of the data')
    file_type = Column(String(30), primary_key=True, nullable=False, comment='Type of the file')
    unq_bank_identifier = Column(String(30), primary_key=True, nullable=False, comment='Unique Swift code of the bank')
    primary_rec_flg = Column(String(30), comment='Reference')
    primary_ref = Column(String(30), comment='Reference')
    institute_name_1 = Column(String(50), comment='Address of the institution')
    institute_name_2 = Column(String(50), comment='Address of the institution')
    branch_info_1 = Column(String(30), comment='Address of the branch')
    address_1 = Column(String(50), comment='Address of the bank')
    address_2 = Column(String(50), comment='Address of the bank')
    location_name_1 = Column(String(50), comment='Name of the Location')
    country_name_1 = Column(String(50), comment='Name of the bank')
    country_code = Column(String(8), comment='Code of the country in which the bank is')
    delta_matching_key = Column(String(50), comment='Key to find if there are differences')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(NetworkDir, "before_update", before_update_log('network_dir', 'ref_key'))

class OrgBranch(Base):
    __tablename__ = 'org_branch'
    __table_args__ = (
        Index('ix1_org_branch', 'br_code', 'org_id'),
        {'comment': 'Branch Configuration details'}
    )

    br_id = Column(Integer, primary_key=True, nullable=False, comment='Unique id of a branch within a bank', autoincrement=True)
    br_desc = Column(String(30), comment='Internal Name of the branch')
    br_nature = Column(String(1), comment='Nature of the branch. V - Virtual , R - Real')
    br_type = Column(String(1), comment='Type of the branch, V - Virtual, M - Mall, R - Rural, U - Urban')
    br_code = Column(String(10), comment='External Name of the branch')
    br_name = Column(String(30), comment='External Name of the branch')
    br_desc_alt = Column(String(50), comment='Branchs name in alternate language')
    br_address1 = Column(String(80), comment='Address line1')
    br_address2 = Column(String(80), comment='Address line2')
    city_code = Column(String(30), comment='City code of the branch')
    state_code = Column(String(8), comment='State code of the branch')
    pin_code = Column(String(8), comment='Pin code of the branch')
    country_code = Column(String(8), comment='Country Code of the branch')
    wkly_off = Column(String(7), comment='Days which are weekly off SAT,SUN,MON')
    br_cls_date = Column(Date, comment='Date for which the branch is closed')
    br_bod_date = Column(Date, comment='Date on which the bank is operating')
    br_alias = Column(String(3), comment='Alias name of branch')
    home_crncy_code = Column(String(3), comment='Home currency code of the bank')
    week_begins_on = Column(String(3), comment='Week begins on SUN,MON,')
    time_zone = Column(String(10), comment='Time zone in which the bank operates')
    br_set = Column(String(15), comment='Branch set that this branch belongs to')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Bank id under which this record is added')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(OrgBranch, "before_update", before_update_log('org_branch', 'br_id'))

class OrgDtl(Base):
    __tablename__ = 'org_dtls'
    __table_args__ = {'comment': 'Organization Configuration details'}

    org_id = Column(String(50), primary_key=True, comment='Unique organization id defined')
    org_desc = Column(String(50), comment='organization name')
    org_logo = Column(String(50), comment='organization logo')
    org_icon = Column(String(50), comment='organization icon')
    org_desc_alt = Column(String(50), comment='organization name in alternate language')
    org_code = Column(String(6), comment='External organization code ')
    reg_no = Column(String(30), comment='Registration number of the organisation')
    pw_valid_period = Column(Integer, comment='Password is valid for days')
    max_clerk_view_id = Column(String(3), comment='People with view id lesser than this Id is considered clerks')
    home_cntry_code = Column(String(2), comment='Home country code of the organization')
    central_bank_code = Column(String(11), comment='Central bank code of the country')
    central_bank_name = Column(String(50), comment='Central bank name of the country')
    user_lim_crncy_code = Column(String(3), comment='User limit should be calculated in currency')
    minor_age = Column(Integer, comment='Age below which people are considered minor')
    org_alias = Column(String(2), comment='Alias of the organization Id')
    org_cls_date = Column(Date, comment='Date for which the organization is closed')
    org_bod_date = Column(Date, comment='Date on which the organization is operating')
    email_mand_onb = Column(String(1), server_default=text("'N'"),comment='email mandatory during onboarding, Y - Yes, N - No')
    multi_crncy = Column(String(1), comment='Enable multi currency, Y - Yes, N - No')
    home_crncy_code = Column(String(3), comment='Home currency code of the bank')
    week_begins_on = Column(String(3), comment='Week begins on SUN,MON,')
    ind_type = Column(String(2), comment='industry type : F - Banks, I - Insurance,  B - Brokerage, C- Cards, H-Human resources')
    org_status = Column(String(1), server_default=text("'A'"), comment='A - Active, I - Inactive')
    sub_status = Column(String(1), server_default=text("'A'"), comment='A - Active, I - Inactive E-Expired F-Free')
    sub_id = Column(String(10), comment='uniq id from subscription system')
    sub_plan = Column(String(2), server_default=text("'ST'"), comment='FR-Free, ST-Standard, CL-Classic, EN-Enterprise')
    face_match = Column(String(1), server_default=text("'V'"), comment='N- No, P - Photo , V - Video')
    enable_spoof = Column(CHAR(1), server_default=text("'Y'"), comment='Enable or disable video spoof engine -> Y - Yes, N - No')
    enable_otp = Column(CHAR(1), server_default=text("'Y'"), comment='Enable or disable video OTP engine -> Y - Yes, N - No')
    collect_doc = Column(String(1), server_default=text("'Y'"), comment='Y - Yes, N - No\\n')
    doc_val = Column(String(1), server_default=text("'N'"), comment='Y - Yes, N - No')
    form_auto_fill = Column(String(1), server_default=text("'D'"), comment='N - No, D -> Document  ( OCR ),  E ->  EKYC ( API ), O -> OKYC ( XML ), X -> From external systems')
    sign_mode = Column(String(1), server_default=text("'D'"), comment='N - No, U - Upload signature, D - device, A - aadhar, I -> Docu sign integration ')
    kyc = Column(String(1), server_default=text("'N'"), comment='N -> No, E ->  EKYC ( API ), O -> OKYC ( XML ), B - Both')
    step_order = Column(String(15), server_default=text("'A,U,F,K'"), comment='A - Account information, E- eKYC, U - Upload document, F - Form, K - KYC')
    land_on = Column(String(3), server_default=text("'PRD'"), comment='PRD - Product screen, CON - Sign up screen, API - Signup using API and land up directly to upload screen')
    scope = Column(CHAR(1), server_default=text("'O'"), comment='"O" - Organization level ,  "P" - Product level')
    face_match_thres = Column(Integer, server_default=text("'55'"), comment='Represents the minimun threshold value of face match')
    gesture_thres = Column(Integer, server_default=text("'90'"), comment='Represents the minimun threshold value of hand gesture')
    spoof_thres = Column(Integer, server_default=text("'90'"), comment='Represents the minimun threshold value of spoof detection')
    override_err = Column(CHAR(1), server_default=text("'N'"), comment='Threshold override permission Y - Yes, N - No')
    time_zone = Column(String(10), comment='Time zone in which the organization operates')
    org_website = Column(String(200), comment='Organisation website url')
    onb_ph_otp = Column(String(1), server_default=text("'N'"), comment='Enable onbording SMS  Y - Yes, N - No')
    gen_qrcode = Column(String(1), server_default=text("'N'"), comment='Enable Generate qrcode,  Y - Yes, N - No')
    rekyc_req = Column(String(1), server_default=text("'N'"), comment='Is rekyc required,  Y - Yes, N - No')
    api_user = Column(String(50), comment='Username of the integration system')
    api_key = Column(String(255), comment='API key of integration system')
    sup_email = Column(String(100), comment='Support email')
    cont_num = Column(String(15), comment='Contact number')
    priv_pol = Column(String(100), comment='Privacy policy url')
    tandc = Column(String(100), comment='Terms and conditions url')
    address_line1 = Column(Text, comment='Address line 1 of the organisation')
    address_line2 = Column(Text, comment='Address line 2 of the organisation')
    city = Column(String(100), comment='City where the organisation located')
    state = Column(String(30), comment='State where the organisation located')
    country = Column(String(30), comment='Country where the organisation located')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"))

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(OrgDtl, "before_update", before_update_log('org_dtls','org_id'))

class OrgInteg(Base):
    __tablename__ = 'org_integ'
    __table_args__ = (
        Index('uix_org_integ', 'org_id', 'sys_name', 'integ_url', 'trigger_step', 'trigger_action', 'prod_code', 'crncy_code', unique=True),
        {'comment': 'Org Integration Table'}
    )

    org_integ_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True, comment='Organization integration id to which this record belongs to')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')
    trigger_step = Column(CHAR(5), comment='The Step in which it is triggered')
    trigger_action = Column(CHAR(15), comment='The action of the trigger')
    trigger_seq = Column(Integer, comment='Triggering sequence')
    org_from = Column(String(10), comment='Orginate from, Applying portal - "ONB",Verifying portal - "END"')
    integ_type = Column(String(50), comment='Integration type')
    integ_name = Column(String(50), comment='Integration name')
    dep_on = Column(String(255), comment='Dependant on')
    is_api_revokable = Column(CHAR(1), comment='Is this api revokable Y - Yes, N - No')
    sys_name = Column(String(30), comment='Integration system name')
    integ_url = Column(String(255), comment='Integration Url')
    api_user = Column(String(50), comment='Username of the integration system')
    api_key = Column(String(255), comment='API key of integration system')
    int_type = Column(String(10), comment='UPSTR - Upstream, DOSTR - Downstream')
    prod_code = Column(String(8), comment='An unique code for the product')
    crncy_code = Column(String(10), comment='Currency code')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(OrgInteg, "before_update", before_update_log('org_integ', 'org_id'))

class OtpDtl(Base):
    __tablename__ = 'otp_dtls'
    __table_args__ = (
        Index('uix1_otp_dtls', 'user_id', 'device_id', 'org_id', unique=True),
        {'comment': 'OTP details table'}
    )

    otp_uniq_id = Column(Integer, primary_key=True, nullable=False, comment='Unique Id for the table')
    user_id = Column(Integer)
    device_type = Column(String(10), nullable=False, comment='Device type from which the user is logging in W - Web, M - Mobile, T-Tab')
    device_id = Column(String(16), nullable=False, comment='Device Id from which the user is accessing the application')
    device_token = Column(String(30), nullable=False, comment='Device token that is created as part of the session')
    otp_type = Column(String(5), nullable=False, comment='Type of OTP - LOGIN, SIGNUP, TRAN, FGTPSWD')
    otp_value = Column(String(5), nullable=False, comment='Value of OTP generated')
    otp_cre_time = Column(TIMESTAMP, comment='Creation time of OTP')
    otp_valid_till = Column(TIMESTAMP, comment='Validity of the OTP')
    logged_on_mode = Column(String(1), comment='This session created as part of batch or online')
    todays_date = Column(TIMESTAMP, comment='The date on which the organization is running')
    org_cls_date = Column(Date, comment='Date for which the organization is closed')
    org_bod_date = Column(Date, comment='Date on which the organization is operating')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(OtpDtl, "before_update", before_update_log('otp_dtls', 'user_id'))

class PassHist(Base):
    __tablename__ = 'pass_hist'
    __table_args__ = (
        Index('ix1_pass_hist', 'user_id', 'org_id'),
        {'comment': 'Password changes history table - This table captures all the password changes executed by the users'}
    )

    pw_hist_id = Column(Integer, primary_key=True, nullable=False,autoincrement=True, comment='Password history ID')
    user_id = Column(Integer, nullable=False, comment='User that the password pertains to')
    password = Column(String(255), nullable=False, comment='User password')
    pw_cre_date = Column(Date, nullable=False, comment='Date the password is created')
    pw_expiry_date = Column(Date, nullable=False, comment='Date on which the password has expired / will expire')
    curr_flag = Column(String(1), nullable=False, comment='Flag to indicate the current password record for the user')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(PassHist, "before_update", before_update_log('pass_hist', 'user_id'))

class PassPolicy(Base):
    __tablename__ = 'pass_policy'
    __table_args__ = {'comment': 'Password Policy Table - This table implements the creation and reset rules of user passwords for each organisation'}

    policy_id = Column(Integer, primary_key=True, nullable=False, comment='Policy ID defined for the organisation')
    min_pw_len = Column(TINYINT, nullable=False, comment='Minimum password length')
    max_pw_len = Column(TINYINT, nullable=False, server_default=text("'25'"), comment='Maximum password length')
    min_dgt_cnt = Column(TINYINT, nullable=False, comment='Minimum number of digits required in the password')
    min_splchar_cnt = Column(TINYINT, nullable=False, comment='Minimum number of special characters required in the password')
    min_uprcaseltr_cnt = Column(TINYINT, nullable=False, comment='Minimum number of upper case alphabets required in the password')
    pw_validity_days = Column(SmallInteger, nullable=False, comment='Validity of user passwords defined as number of days')
    invalid_pw_atmpts = Column(TINYINT, nullable=False, comment='Maximum number of invalid password attempts allowed after which the user status becomes locked')
    reset_freq = Column(TINYINT, nullable=False, comment='Maximum number of password resets allowed for certain time interval')
    reset_freq_duration = Column(TINYINT, nullable=False, comment='Number of days allowed for specific number of password resets')
    reuse_hist_cnt = Column(TINYINT, nullable=False, comment='Number of previous passwords from the history table that cannot be reused')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(PassPolicy, "before_update", before_update_log('pass_policy', 'org_id'))

class PreferenceDtl(Base):
    __tablename__ = 'preference_dtls'
    __table_args__ = {'comment': 'User Preference Details Table'}

    user_id = Column(Integer, primary_key=True, nullable=False)
    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Customer ID')
    pref_type = Column(String(1), primary_key=True, nullable=False, comment='Type of Preference. V - View , N - Notification , A - Access Control , W - Workflow , R - Role , O - Offers')
    pref_event_name = Column(String(50), primary_key=True, nullable=False, comment='SHW-INCM-DSHB ,EXP-PERD-DSHB,PAT-PERD-DSHB,GRP-ACT-DSHB,CAL-REM-DSHB,NOT-REM-DUE')
    pref_event_value = Column(String(25), nullable=False, comment='Values corresponding to the events')
    sys_tran_cat_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"), comment='Unique ID of the Transaction Category. Example If the module is N , sub module is U then it is BillPay or Instalment ')
    remind_par_cat_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"), comment='Parent Category ID')
    remind_bf_days = Column(Integer, server_default=text("'0'"), comment='Reminders to be given before how many days')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(PreferenceDtl, "before_update", before_update_log('preference_dtls', 'user_id'))

class Preference(Base):
    __tablename__ = 'preferences'
    __table_args__ = {'comment': 'User Preference Details Table'}

    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Customer ID')
    pref_type = Column(String(1), primary_key=True, nullable=False, comment='Type of Preference. V - View , N - Notification , A - Access Control , W - Workflow , R - Role , O - Offers')
    pref_event_name = Column(String(50), primary_key=True, nullable=False, comment='SHW-INCM-DSHB ,EXP-PERD-DSHB,PAT-PERD-DSHB,GRP-ACT-DSHB,CAL-REM-DSHB,NOT-REM-DUE')
    pref_event_value = Column(String(25), nullable=False, comment='Values corresponding to the events')
    rem_sys_cat_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"), comment='Unique ID of the Transaction Category. \\n       Example If the module is N , sub module is U then it is BillPay or Instalment ')
    rem_parent_cat_id = Column(Integer, primary_key=True, nullable=False, server_default=text("'0'"), comment='Parent Category ID')
    remind_bf_days = Column(Integer, server_default=text("'0'"), comment='Reminders to be given before how many days')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

event.listen(Preference, "before_update", before_update_log('preferences', 'cust_id'))

class PreprocDtl(Base):
    __tablename__ = 'preproc_dtls'
    __table_args__ = {'comment': 'Preprocessed table holds the details of the customers'}

    preproc_as_on = Column(Date, primary_key=True, nullable=False, comment='Preprocess executed as on date')
    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Id of th Customer')
    cust_type = Column(String(1), nullable=False, comment='Classification of the Customer')
    age_range = Column(String(255), server_default=text("'0'"), comment='Date of birth of the Customer')
    annual_sal_crncy = Column(String(3), comment='Currency of the annual income')
    annual_salary_range = Column(String(255), server_default=text("'0'"), comment='Annual income range of the customer')
    gender = Column(String(1), comment='Gender of the Customer')
    region = Column(String(8), nullable=False, comment='Region the customer belongs to')
    blacklist_flg = Column(String(1), nullable=False, comment='Blacklisted Flag')
    suspend_flg = Column(String(1), nullable=False, comment='Suspended Flag')
    resident_flg = Column(String(1), server_default=text("'N'"), comment='Customer Residential Status Flag')
    minor_flg = Column(String(1), server_default=text("'N'"), comment='Customer Minor Flag')
    staff_flg = Column(String(25), server_default=text("'N'"), comment='Customer Staff Flag')
    segment = Column(String(8), comment='Access owner segment')
    state = Column(String(8), comment='State of the customer')
    marital_status = Column(String(1), nullable=False, comment='Marital Status of the customer')
    employment_status = Column(CHAR(1))
    fin_quality = Column(String(8), comment='Financial quality of the customer')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(PreprocDtl, "before_update", before_update_log('preproc_dtls', 'cust_id'))

class PreprocHistDtl(Base):
    __tablename__ = 'preproc_hist_dtls'
    __table_args__ = {'comment': 'Preprocessed table holds the details of the customers'}

    preproc_as_on = Column(Date, primary_key=True, nullable=False, comment='Preprocess executed as on date')
    preproc_srl_num = Column(Integer, primary_key=True, nullable=False, comment='Preprocess record serial number')
    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Id of th Customer')
    cust_type = Column(String(1), nullable=False, comment='Classification of the Customer')
    age_range = Column(String(255), server_default=text("'0'"), comment='Date of birth of the Customer')
    gender = Column(String(1), comment='Gender of the Customer')
    region = Column(String(8), nullable=False, comment='Region the customer belongs to')
    blacklist_flg = Column(String(1), nullable=False, comment='Blacklisted Flag')
    suspend_flg = Column(String(1), nullable=False, comment='Suspended Flag')
    nre_flg = Column(String(1), server_default=text("'N'"), comment='Customer Residential Status Flag')
    minor_flg = Column(String(1), server_default=text("'N'"), comment='Customer Minor Flag')
    staff_flg = Column(String(25), server_default=text("'N'"), comment='Customer Staff Flag')
    segment = Column(String(8), comment='Access owner segment')
    state = Column(String(8), comment='State of the customer')
    marital_status = Column(String(1), nullable=False, comment='Marital Status of the customer')
    annual_sal_crncy = Column(String(3), comment='Currency of the annual income')
    annual_salary_range = Column(String(255), server_default=text("'0'"), comment='Annual income range of the customer')
    employment_status = Column(CHAR(1), server_default=text("'N'"), comment='Employment status of the customer')
    fin_quality = Column(String(8), comment='Financial quality of the customer')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(PreprocHistDtl, "before_update", before_update_log('preproc_hist_dtls', 'cust_id'))

class ProdStepsConfig(Base):
    __tablename__ = 'prod_steps_config'
    __table_args__ = (
        Index('ix3_prod_steps_config', 'prod_code', 'prod_crncy_code', 'org_id'),
        Index('ix2_prod_steps_config', 'finserv_id', 'org_id'),
        Index('ix1_prod_steps_config', 'prod_code', 'prod_nature', 'prod_type', 'prod_crncy_code', 'org_id')
    )

    prod_step_id = Column(Integer, primary_key=True, nullable=False, comment='Unique ID of the application step configuration table', autoincrement=True)
    finserv_id = Column(String(50), comment='Code of the Financial Services company')
    prod_code = Column(String(8), nullable=False, comment='An unique code for the product')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), nullable=False, comment='Type of Product for A (Account) - Deposits, Loans,Savings and for I ( Insurance)- Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan, Vehicle Loan')
    prod_crncy_code = Column(String(3), nullable=False, comment='Curreny code in which this product is allowed')
    step_num = Column(Integer, comment='Number of the process step of this product')
    step_code = Column(String(8), nullable=False, comment='An unique code for the step ')
    step_name = Column(String(30), comment='Name of the step - Document Verification, Legal Assessment, Income Assesment')
    mandatory = Column(CHAR(1), server_default=text("'N'"), comment='Tells whether this step is mandatory or optional  (Y - Yes, N - No)')
    auth_matrix_code = Column(String(25), comment='Autorization Matrix code for escalation matrix')
    matrix_id = Column(String(15), nullable=False, comment='Authorization matrix ID')
    entity_cre_flg = Column(CHAR(1), server_default=text("'Y'"), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), nullable=False, comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"),comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProdStepsConfig, "before_update", before_update_log('prod_steps_config', 'prod_code'))

class ProductAddon(Base):
    __tablename__ = 'product_addons'
    __table_args__ = {'comment': 'Document details of Product'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the product')
    crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Curreny code in which this product is allowed')
    add_on_code = Column(String(8), primary_key=True, nullable=False, comment='Add on Code of the product')
    add_on_name = Column(String(50), comment='Name of the add-ons chequebook , Debit card, Internet banking etc')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization which this record is created under')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProductAddon, "before_update", before_update_log('product_addons', 'prod_code'))

class ProductDocDtl(Base):
    __tablename__ = 'product_doc_dtls'
    __table_args__ = (
        Index('uix1_product_doc_dtls', 'prod_code', 'crncy_code', 'doc_type', 'doc_code', 'org_id'),
        Index('ix1_product_doc_dtls', 'prod_code', 'crncy_code', 'org_id'),
        {'comment': 'Document details of Product'}
    )

    prod_doc_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    finserv_id = Column(String(50), nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), nullable=False, comment='An unique code for the product')
    crncy_code = Column(String(3), nullable=False, comment='Curreny code in which this product is allowed')
    doc_type = Column(String(15), nullable=False, comment='Type of document that is needed as proof. ID , ADDRESS , INCOME , TAX etc')
    doc_code = Column(String(15), nullable=False, comment='Code of document that is needed as proof ID - PASSPORT , AADHAR , INCOME - SALARY , TAX -PAN')
    doc_src = Column(String(1), comment='Document Source - C => Customer, B => Back office')
    mandate = Column(String(1), server_default=text("'N'"), comment='Is this document mandatory')
    num_of_docs = Column(Integer, server_default=text("'1'"), comment='Number of docs allowed')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization which this record is created under')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProductDocDtl, "before_update", before_update_log('product_doc_dtls', 'prod_code'))

class ProductDtl(Base):
    __tablename__ = 'product_dtls'
    __table_args__ = (
        Index('ix2_product_dtls', 'prod_code', 'crncy_code', 'org_id'),
        Index('ix1_product_dtls', 'prod_code', 'org_id'),
        {'comment': 'Product details'}
    )

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the product')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    prod_name = Column(String(50), comment='Name of the product')
    crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Curreny code in which this product is allowed')
    alt_prod_name = Column(String(20), comment='Name of the product in alternate language')
    set_id = Column(String(8), comment='The branch set that can issue an account for this product')
    allowed_genders = Column(String(1), comment='M-Male or F-Female or B- Both  or S-Student or K-Kid or C-Children')
    staff_only_flg = Column(String(1), comment='Is this allowed only for staff')
    nre_only_flg = Column(String(1), comment='Is this allowed only for NRE')
    adult_age = Column(Integer, server_default=text("'0'"), comment='People below this age are considered as children')
    min_cust_age = Column(Integer, server_default=text("'0'"), comment='Product is allowed for customers who are of atleast this age')
    max_cust_age = Column(Integer, server_default=text("'0'"), comment='Product is allowed for customers who are of atleast this age')
    sec_unsec_flg = Column(String(1), comment='Does this product offers secured loans or unsecured loan')
    acct_opn_form_name = Column(String(8), comment='Form to be used for account opening')
    acct_cls_form_name = Column(String(8), comment='Form to be used for account close')
    allowed_int_freq = Column(String(50), comment='Interest pay/collection is allowed in these periods')
    minimum_bal_basis = Column(String(1), comment='Minmum balance is calcualted on D - Daily , W - Weeky , F - Fortnighly , \\n  M - Monthly , Q - Quarterly , H - Halfyearly , Y - Yearly')
    max_num_of_withdrawal = Column(Integer, server_default=text("'0'"), comment='Maximum withdrawal is calculated on what basis')
    withdrawal_basis_flg = Column(String(1), comment='M - Monthly, Q - Quarterly, H - Halfyearly, Y - yearly, W - Weekly, F - Fortnightly')
    int_on_bal = Column(String(1), comment='Int is on min balanace , Curr Balance , average balance')
    max_sanctioned_limit = Column(DECIMAL(20, 4), comment='Maximum sanctioned limit for this account')
    dr_bal_lim = Column(DECIMAL(20, 4), comment='How much maximum it can go in negative')
    interest_rate = Column(DECIMAL(20, 4), comment='Interest rate of the product')
    auto_renewal_allowed = Column(String(1), comment='Whether auto renewal is allowed')
    prod_allowed_cust = Column(String(1), comment='Corporate , Retail , Both')
    chq_allowed_flg = Column(String(1), comment='Is cheque book allowed for this product')
    sweep_alwd_flg = Column(String(1), comment='Is sweep faciility allowed for this product')
    sweep_in_min_bal = Column(DECIMAL(20, 4), comment='Minimum amount that need to be transferred inside this account')
    sweep_in_max_bal = Column(DECIMAL(20, 4), comment='Maximum amount that need to be transferred inside this account')
    sweep_out_min_bal = Column(DECIMAL(20, 4), comment='Minimum amount that need to be transferred from this account')
    sweep_out_max_bal = Column(DECIMAL(20, 4), comment='Maximum amount that need to be transferred from this account')
    product_img = Column(String(45), comment='Image path of the product where it is stored')
    response = Column(Text, comment='JSON Data of the product is stored')
    min_slab_amt = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Minimum capped slab for the product')
    max_slab_amt = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Maximum capped slab for the product')
    min_perd_mnths = Column(Integer, server_default=text("'0'"), comment='Minimum  period allowed months')
    min_perd_days = Column(Integer, server_default=text("'0'"), comment='Minimum  period allowed in days')
    max_perd_mnths = Column(Integer, server_default=text("'0'"), comment='Maximum  period allowed months')
    max_perd_days = Column(Integer, server_default=text("'0'"), comment='Maximum  period allowed in days')
    pre_closure_allowed = Column(String(1), server_default=text("'Y'"), comment='Whether pre closure allowed')
    part_closure_allowed = Column(String(1), server_default=text("'Y'"), comment='Whether part closure allowed')
    installment_type = Column(String(1), comment='Installment type M - Monthly , Q - Quarterly , H - Halfyearly , Y - Yearly , F - FortNightly , W - Weekly')
    installment_amt = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Installment amount')
    installment_coll_mthd = Column(String(1), comment='Installment collection method')
    minimum_bal = Column(DECIMAL(20, 4), comment='Minimum Balance amount')
    maturity_date = Column(Date, comment='Deposit maturity date')
    grace_days = Column(DECIMAL(10, 0), comment='Grace period in days')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProductDtl, "before_update", before_update_log('product_dtls', 'prod_code'))

class ProductFee(Base):
    __tablename__ = 'product_fees'
    __table_args__ = (
        Index('ix1_product_fees', 'prod_code', 'org_id', 'prod_crncy_code'),
        Index('ix2_product_fees', 'fee_code', 'org_id', 'fee_crncy_code'),
        {'comment': 'Fee details of products'}
    )

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Id of the financial services to which the entity is associated')
    prod_type = Column(String(20), primary_key=True, nullable=False, comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='Code of the product like , KIDSAVER , 30DAYDEPOSIT')
    prod_crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code in which this product operates')
    fee_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the fee')
    fee_crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code of the fee')
    fee_desc = Column(String(30), comment='Description of fee')
    fee_desc_alt = Column(String(30), comment='Description of fee in alternate language')
    fee_amt_ind = Column(CHAR(1), comment='Amount Indicator of fee - fixed , p - percentage')
    fee_amount = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Amount of fee if it is a fixed')
    fee_pcnt = Column(DECIMAL(4, 2), server_default=text("'0.00'"), comment='Percentage for the fee amount ')
    apply_tax = Column(String(1), comment='Is tax applied for this fee')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProductFee, "before_update", before_update_log('product_fees', 'prod_code'))

class ProductMaster(Base):
    __tablename__ = 'product_master'
    __table_args__ = {'comment': 'Product master details'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    app_cat = Column(String(30), comment='Applicant Category')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the product')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    prod_name = Column(String(50), comment='Name of the product')
    alt_prod_name = Column(String(20), comment='Name of the product in alternate language')
    prod_ad_content = Column(String(100), comment='Advertisement Content for product')
    prod_alt_ad_content = Column(String(100), comment='Advertisement Content for product in Alternate language')
    app_frm = Column(String(30), comment='Onboarding form')
    product_img = Column(String(45), comment='Image path of the product where it is stored')
    users = Column(CHAR(1), comment='showing specific product based on users column')
    response = Column(Text, comment='JSON Data of the product is stored')
    skip_steps = Column(String(1), comment='A - Account Config ,  U - Upload doc,  F - Form,  V - Video')
    auto_approve = Column(String(1), server_default=text("'N'"), comment='Auto Approve steps -> Y - Yes, N - No')
    face_match = Column(CHAR(1), server_default=text("'V'"), comment='N- No, P - Photo , V - Video')
    enable_spoof = Column(CHAR(1), server_default=text("'Y'"), comment='Enable or disable video spoof engine -> Y - Yes, N - No')
    enable_otp = Column(CHAR(1), server_default=text("'Y'"), comment='Enable or disable video OTP engine -> Y - Yes, N - No')
    collect_doc = Column(CHAR(1), server_default=text("'Y'"), comment='Y - Yes, N - No')
    capture_doc = Column(CHAR(1), server_default=text("'N'"), comment='Document to be captured in video call,Y - Yes, N - No')
    app_fill_form = Column(CHAR(1), server_default=text("'N'"), comment='should the applicant fill form ,Y - Yes, N - No')
    form_auto_fill = Column(CHAR(1), server_default=text("'D'"), comment='N - No, D -> Document  ( OCR ),  E ->  EKYC ( API ), O -> OKYC ( XML )')
    sign_mode = Column(CHAR(1), server_default=text("'D'"), comment='N - No, U - Upload signature, D - device, A - aadhar, I -> Docu sign integration ')
    kyc = Column(CHAR(1), server_default=text("'N'"), comment='N -> No, E ->  EKYC ( API ), O -> OKYC ( XML ), B - Both')
    step_order = Column(String(15), server_default=text("'A,U,F,S'"), comment='A - Account information, E- eKYC, U - Upload document, F - Form, K - KYC, S - Selfie Video')
    prod_status = Column(String(1), comment='Status of the product X - Deactivated, T - In Test mode, L - Live Mode, D - Setup Documents, V - Setup Verification')
    all_global_applnt = Column(String(1), comment='Allow Global Applicants, Y - Allowed, N - Not Allowed')
    rekyc_period = Column(Integer, comment='After how many months, the system should notify the customer to repeat the KYC again ')
    skip_rekyc_prd = Column(Integer, comment='Skip identity verification if this applicant’s KYC is approved within this period - months')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ProductMaster, "before_update", before_update_log('product_master', 'prod_code'))

class RecDtl(Base):
    __tablename__ = 'rec_dtls'
    __table_args__ = {'comment': 'Recommendation table'}

    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Id of th Customer')
    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the product')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    crncy_code = Column(String(3), nullable=False, comment='Currency Code in which this product operates')
    steer_coeff = Column(DECIMAL(4, 2), comment='Steer co-efficient score')
    entity_limit = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Recommended amount Range')
    owned_products = Column(String(255), comment='Currently owned products of the customer')
    reco_as_on = Column(Date, comment='Recommended on this date')
    reco_action_status = Column(String(1), comment='Recommendation Action Status Y - Yet to Propose , A - Accepted , R - Rejected , H - Hold ')
    reco_reject_reason = Column(String(1), comment='Recommendation rejected Reason')
    score = Column(DECIMAL(20, 4), comment='Score calculated by ML algorithms')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

class RecHistDtl(Base):
    __tablename__ = 'rec_hist_dtls'
    __table_args__ = {'comment': 'Recommendation History table'}

    reco_as_on = Column(Date, nullable=False, comment='Recommendation as on date')
    reco_srl_num = Column(Integer, nullable=False, comment='Recommendation serial number')
    cust_id = Column(String(15), primary_key=True, nullable=False, comment='Id of th Customer')
    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the product')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    crncy_code = Column(String(3), nullable=False, comment='Currency Code in which this product operates')
    steer_coeff = Column(DECIMAL(4, 2), comment='Steer co-efficient score')
    entity_limit = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Recommended amount Range')
    owned_products = Column(String(255), comment='Currently owned products of the customer')
    reco_action_status = Column(String(1), comment='Recommendation Action Status Y - Yet to Propose , A - Accepted , R - Rejected , H - Hold ')
    reco_reject_reason = Column(String(1), comment='Recommendation rejected Reason')
    score = Column(DECIMAL(20, 4), comment='Score calculated by ML algorithms')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified COMMENT COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

class RegTaxDtl(Base):
    __tablename__ = 'reg_tax_dtls'
    __table_args__ = {'comment': 'Regulatory tax applicable for the country'}

    tax_code = Column(String(8), primary_key=True, nullable=False, comment='Code for the Tax Setup')
    tax_name = Column(String(30), primary_key=True, nullable=False, comment='Name of the ax code')
    tax_type = Column(String(30), primary_key=True, nullable=False, comment='income, expense')
    tax_percentage = Column(DECIMAL(10, 2), comment='Percentage of the tax')
    tax_desc = Column(String(50), nullable=False, comment='Description or any notes for the tax code ')
    cust_id = Column(String(15), comment='Customer Id for whom the tax is applicable')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

class RoleActionAccess(Base):
    __tablename__ = 'role_action_access'
    __table_args__ = (
        Index('uix1_role_action_access', 'role_code', 'module', 'org_id', unique=True),
        {'comment': 'Role Action Access Table'}
    )

    action_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True,comment='Auto-Increment ID')
    role_code = Column(String(15), nullable=False, comment='Role code defined for the bank')
    module = Column(String(45), nullable=False, comment='Name of the module')
    entity_name = Column(String(45), nullable=False, comment='Name of the entiry')
    add_perm = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No Z-Not Applicable')
    modify_perm = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    view_perm = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    delete_perm = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    verify = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    refer = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    reject = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    approve = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    accept = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    upload = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    download = Column(String(1), server_default=text("'Z'"), comment=' Y - Yes, N - No  Z-Not Applicable')
    capture = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No  Z-Not Applicable')
    recollect = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No Z-Not Applicable')
    revoke = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No Z-Not Applicable')
    allocate = Column(String(1), server_default=text("'Z'"), comment='Y - Yes, N - No Z-Not Applicable')
    entity_cre_flg = Column(CHAR(4), nullable=False, server_default=text("'Y'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(CHAR(4), nullable=False, server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(45), comment='Record creation user id')
    rcre_time = Column(DateTime, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Org id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RoleActionAccess, "before_update", before_update_log('role_action_access', 'role_code'))

class RoleCrncyDtl(Base):
    __tablename__ = 'role_crncy_dtls'
    __table_args__ = (
        Index('ix1_role_crncy_dtls', 'role_code', 'org_id'),
        {'comment': 'Role and its access to various currency details'}
    )

    role_code = Column(String(15), primary_key=True, nullable=False, comment='Role id defined for the organization')
    crncy_code = Column(String(3), primary_key=True, nullable=False, comment='Currency Code that is defined for this role')
    cash_dr_lim = Column(DECIMAL(20, 4), comment='Debit Limit through cash mode')
    xfer_dr_lim = Column(DECIMAL(20, 4), comment='Debit Limit through transfer mode')
    clg_dr_lim = Column(DECIMAL(20, 4), comment='Debit Limit through clearing mode')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RoleCrncyDtl, "before_update", before_update_log('role_crncy_dtls', 'role_code'))

class RoleDtl(Base):
    __tablename__ = 'role_dtls'
    __table_args__ = (
        Index('uix1_role_dtls', 'role_code', 'org_id', unique=True),
        {'comment': 'Role Details Table'}
    )

    role_id = Column(Integer, primary_key=True, nullable=False, comment='Role Id defined for the bank', autoincrement=True)
    role_code = Column(String(15), nullable=False)
    limit_amount = Column(DECIMAL(20, 4), nullable=False, comment='Amount Limit in Home currency')
    role_desc = Column(String(50), comment='Description of the Role')
    is_super_admin = Column(String(1), server_default=text("'N'"), comment='Y - Yes, N - No ')
    hide_sensitive_data = Column(String(1), server_default=text("'N'"), comment='Y - Yes, N - No ')
    is_customer_assistant = Column(CHAR(1), server_default=text("'N'"), comment='identitifes wether this role can assist the user : Y - Yes, N - No')
    onb_agent = Column(CHAR(1), server_default=text("'N'"), comment='allow the user to login to onboard : Y - Yes, N - No')
    rest_data = Column(CHAR(1), comment='Restrict data, R - Based on role, U - Based on user, N - None')
    limit_scope = Column(CHAR(1), nullable=False, comment='Scope of the curreny on which the limit need to be checked H - Home Currency,I- Individual Currency')
    override_err = Column(CHAR(1), server_default=text("'N'"), comment='Threshold override permission Y - Yes, N - No')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record creation time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RoleDtl, "before_update", before_update_log('role_dtls', 'role_code'))

class RolePermissionDtl(Base):
    __tablename__ = 'role_permission_dtls'
    __table_args__ = (
        Index('ix1_role_permission_dtls', 'role_code', 'org_id'),
        Index('uix1_role_permission_dtls', 'role_code', 'module', 'org_id', unique=True)
    )

    perm_id = Column(Integer, primary_key=True, nullable=False, comment='Auto-Increment ID', autoincrement=True)
    role_code = Column(String(15), comment='Role Id defined for the bank')
    module = Column(String(45), comment='Name of the module')
    reader = Column(String(1), server_default=text("'N'"), comment='Module Reader permission Y - Yes, N - No')
    modifier = Column(String(1), server_default=text("'N'"), comment='Module Modifier permission Y - Yes, N - No')
    checker = Column(String(1), server_default=text("'N'"), comment='Module Checker permission Y - Yes, N - No')
    verifier = Column(String(1), server_default=text("'N'"), comment='Module Verifier permission Y - Yes, N - No')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RolePermissionDtl, "before_update", before_update_log('role_permission_dtls', 'role_code'))

class RoleProdAccess(Base):
    __tablename__ = 'role_prod_access'
    __table_args__ = (
        Index('uix1_role_prod_access', 'role_code', 'prod_code', 'crncy_code', 'prod_type', 'org_id', 'prod_nature'),
        Index('ix1_role_prod_access', 'role_code', 'org_id', 'prod_code', 'crncy_code'),
        Index('ix2_role_prod_access', 'role_code', 'org_id'),
        {'comment': 'Product master details'}
    )

    role_prod_id = Column(Integer, primary_key=True,autoincrement=True,nullable=False)
    role_code = Column(String(15), nullable=False, comment='role code')
    finserv_id = Column(String(50), nullable=False, comment='Code of the Financial Services company')
    prod_code = Column(String(8), nullable=False, comment='An unique code for the product')
    crncy_code = Column(String(3), nullable=False, comment='Curreny code in which this product is allowed')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), nullable=False, comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RoleProdAccess, "before_update", before_update_log('role_prod_access', 'role_code'))

class RoleWorkflowAccess(Base):
    __tablename__ = 'role_workflow_access'
    __table_args__ = (
        Index('ix1_role_workflow_access', 'role_code', 'prod_code', 'crncy_code', 'org_id', 'prod_nature', 'prod_type'),
        Index('uix1_role_workflow_access', 'role_code', 'step_code', 'crncy_code', 'prod_nature', 'prod_type', 'prod_code', 'org_id'),
        Index('ix2_role_workflow_access', 'role_code', 'crncy_code', 'org_id', 'prod_code'),
        {'comment': 'role  workflow details'}
    )

    role_wf_id = Column(Integer, primary_key=True, nullable=False,autoincrement=True)
    role_code = Column(String(15), nullable=False, comment='role code')
    finserv_id = Column(String(50), nullable=False, comment='Code of the Financial Services company')
    step_code = Column(String(8), nullable=False, comment='An unique code for the step ')
    prod_code = Column(String(8), nullable=False, comment='An unique code for the product')
    crncy_code = Column(String(3), nullable=False, comment='Curreny code in which this product is allowed')
    prod_nature = Column(String(15), nullable=False, comment='Nature of Entity A - Account , I - Insurance , C - Cards')
    prod_type = Column(String(20), nullable=False, comment='Type of Product for A - Deposits, Loans ,Savings and for I - Term , Health etc ')
    prod_sub_type = Column(String(20), comment='Nature of the product like Home Loan , Vehicle Loan , ')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RoleWorkflowAccess, "before_update", before_update_log('role_workflow_access', 'role_code'))

class SessionDtl(Base):
    __tablename__ = 'session_dtls'
    __table_args__ = (
        Index('session_UQ_1', 'session_id', 'org_id', unique=True),
        Index('ix1_session_dtls', 'user_id', 'org_id'),
        {'comment': 'Session details table'}
    )

    sess_uniq_id = Column(Integer, primary_key=True, nullable=False, comment='Unique Id for the table', autoincrement=True)
    session_id = Column(String(15), nullable=False, comment='Session id created uniquely for each user from each device')
    user_id = Column(Integer, comment='User id for which this session is created')
    device_type = Column(String(10), nullable=False, comment='Device type from which the user is logging in W - Web, M - Mobile, T-Tab')
    device_id = Column(String(16), nullable=False, comment='Device Id from which the user is accessing the application')
    device_token = Column(String(30), nullable=False, comment='Device token that is created as part of the session')
    view_access_id = Column(String(255), comment='Access code to view a certain screen')
    temp_view_access_id = Column(String(255), comment='Temporary Access code allocated to the user')
    temp_view_valid_till = Column(Date, comment='Temporary access valid till')
    calling_prog_id = Column(String(10), comment='Program that has created this session')
    exe_name = Column(String(25), comment='Batch Executable that has created this session')
    logged_on_mode = Column(String(1), comment='This session created as part of batch or online')
    back_fore_flg = Column(String(1), comment='This program or Batch executable is running in F - foreground, B - Background')
    todays_date = Column(TIMESTAMP, comment='The date on which the organization is running')
    org_cls_date = Column(Date, comment='Date for which the organization is closed')
    org_bod_date = Column(Date, comment='Date on which the organization is operating')
    node_id = Column(String(10), comment='Node id from which the session has been created')
    node_type = Column(String(1), comment='Type of the server node from which session has been created')
    node_name = Column(String(25), comment='node name which the session has been created')
    home_crncy = Column(String(3), comment='Home currency of the user for whom this session has been created')
    preferred_language = Column(String(45), comment='Preferred Language of the user')
    parent_session_id = Column(String(15), comment='If the forked child process has created this session, then what is the parent session id')
    proc_id = Column(BigInteger, comment='Process Id that is running as part of this session')
    role_code = Column(String(15), comment='Role id of the user for whom the session is created ')
    session_time_zone = Column(String(3), comment='Time zone of the session')
    module_id = Column(String(6), comment='Accessible modules of the user as part of the session')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(SessionDtl, "before_update", before_update_log('session_dtls', 'session_id'))

class ReportDetail(Base):
    __tablename__ = 'report_details'
    __table_args__ = (
        Index('ix1_report_details', 'rpt_cat', 'rpt_code', 'org_id'),
        Index('uix1_report_details', 'rpt_cat', 'rpt_code', 'org_id', unique=True)
    )

    rpt_id = Column(Integer, primary_key=True, nullable=False)
    rpt_cat = Column(String(5), nullable=False, comment='Report category code')
    rpt_cat_desc = Column(String(30), nullable=False, comment='Report category description')
    rpt_code = Column(String(15), nullable=False, comment='Report code')
    rpt_name = Column(String(30), comment='Report code description')
    rpt_desc = Column(String(100), comment='Report Description')
    rpt_off = Column(CHAR(1), comment='P - Product , C - Cusomization')
    rpt_type = Column(CHAR(1), comment='O - Online, B - Batch, E - Extract')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, comment='Last modified time')
    ts_cnt = Column(Integer)
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(ReportDetail, "before_update", before_update_log('report_details', 'org_id'))

class RptPerm(Base):
    __tablename__ = 'rpt_perm'
    __table_args__ = (
        Index('ix1_rpt_perm', 'role_code', 'org_id', 'rpt_cat', 'rpt_code'),
        Index('ix2_rpt_perm', 'role_code', 'org_id'),
        {'comment': 'Report Permission Table'}
    )

    rpt_perm_id = Column(Integer, primary_key=True, autoincrement=True,nullable=False, comment='Report permission ID')
    role_code = Column(String(15), nullable=False, comment='Role code')
    rpt_cat = Column(String(15), comment='Report category')
    rpt_code = Column(String(15), comment='Report code')
    rpt_view = Column(String(1), nullable=False, server_default=text("'N'"), comment='Report view')
    rpt_dwnld = Column(String(1), nullable=False, server_default=text("'N'"), comment='Report download')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified, N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(15), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(RptPerm, "before_update", before_update_log('rpt_perm', 'org_id'))

class SubDtl(Base):
    __tablename__ = 'sub_dtls'
    __table_args__ = (
        Index('idx1_subscription_dtls', 'plan_name', 'org_id'),
    )

    plan_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    plan_name = Column(String(30), nullable=False)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    status = Column(String(1), server_default=text("'N'"))
    details = Column(String(45), comment='U  -> Upgrade\\nE  -> Expiry warning \\nN ->  None ')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"))
    del_flg = Column(CHAR(1), server_default=text("'N'"))
    rcre_user_id = Column(String(15))
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    lchg_user_id = Column(String(15))
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(SubDtl, "before_update", before_update_log('sub_dtls', 'org_id'))

class TaxDtl(Base):
    __tablename__ = 'tax_dtls'
    __table_args__ = {'comment': 'Tax details of Fees'}

    finserv_id = Column(String(50), primary_key=True, nullable=False, comment='Code of the Financial Services company')
    tax_code = Column(String(8), primary_key=True, nullable=False, server_default=text("'NOTAPPLY'"), comment='Id of the Tax that is applicable for this fee')
    tax_crncy_code = Column(String(3), comment='Currency Code of the fee')
    fee_code = Column(String(8), primary_key=True, nullable=False, comment='An unique code for the fee')
    tax_desc = Column(String(8), server_default=text("'NOTAPPLY'"), comment='Name of the Tax that is applicable for this fee')
    tax_desc_alt = Column(String(8), server_default=text("'NOTAPPLY'"), comment='Name of the Tax that is applicable for this fee')
    tax_amt_ind = Column(CHAR(1), comment='Amount Indicator of tax - fixed , p - percentage')
    tax_amount = Column(DECIMAL(20, 4), server_default=text("'0.0000'"), comment='Amount of tax if it is a fixed')
    tax_pcnt = Column(DECIMAL(4, 2), server_default=text("'0.00'"), comment='Percentage for the tax amount ')
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer,server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(TaxDtl, "before_update", before_update_log('tax_dtls', 'tax_code'))

class TblAuditDtl(Base):
    __tablename__ = 'tbl_audit_dtl'

    log_id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
    table_name = Column(String(30), nullable=False)
    table_key = Column(String(45), nullable=False)
    audit_srl_num = Column(String(45))
    operation = Column(String(10), nullable=False, comment='Operation -> insert, update, delete')
    event = Column(String(15), nullable=False, comment='Events -> before_update, after_update')
    modified_fields = Column(Text, nullable=False)
    entity_cre_flg = Column(String(45), server_default=text("'Y'"))
    del_flg = Column(String(45), server_default=text("'N'"))
    rcre_user_id = Column(String(45))
    rcre_time = Column(String(45), nullable=False, server_default=text("'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'"))
    lchg_user_id = Column(String(45))
    lchg_time = Column(String(45), nullable=False, server_default=text("'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'"))
    ts_cnt = Column(String(45), server_default=text("'0'"))
    org_id = Column(String(50))

class UserContact(Base):
    __tablename__ = 'user_contact'
    __table_args__ = {'comment': 'Users Contact Details Table'}

    user_id = Column(Integer, primary_key=True, nullable=False, comment='Customer ID')
    contact_type = Column(String(10), primary_key=True, nullable=False, comment='Type of Contact. PHONE , EMAIL , ADDRESS ')
    contact_sub_type = Column(String(25), primary_key=True, nullable=False, comment='Sub Type of the contanct. HOME , PERSONAL , OFFICE ')
    address_format = Column(String(1), comment='Format of the address. F - FreeText , S - Structured')
    address_line1 = Column(Text, comment='Address Line 1 of the customer')
    address_line2 = Column(Text, comment='Address Line 2 of the customer')
    address_line3 = Column(Text, comment='Address Line 3 of the customer')
    city = Column(String(30), comment='City of the customer')
    state = Column(String(8), comment='State of the customer')
    country = Column(String(30), comment='Country of the customer')
    region = Column(String(8), comment='Region of the customer')
    pin = Column(String(8), comment='Pin code of the customer')
    phone_no = Column(String(10), comment='Phone number of the customer')
    phoneno_localcode = Column(String(2), comment='Local code of the customer')
    phoneno_countrycode = Column(String(2), comment='Country code of the customer')
    email = Column(String(50), comment='Email id of the customer')
    building_num = Column(Integer, server_default=text("'0'"), comment='House Number or Door No')
    Plot_num = Column(Integer, server_default=text("'0'"), comment='Plot Number ')
    premise_name = Column(String(20), comment='Building Name , community name')
    floor_no = Column(Integer, comment='Floor Number ')
    street_no = Column(Integer, comment='Street Number')
    street_name = Column(String(20), comment='Name of the street')
    locality = Column(String(20), comment='Locality of the customer')
    domicle = Column(String(20), comment='Domicle of the customer')
    entity_cre_flg = Column(CHAR(1), comment='Has the entity been created. Y means verified  COMMENT  COMMENT , N means created')
    del_flg = Column(CHAR(1), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP)
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP)
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(UserContact, "before_update", before_update_log('user_contact', 'user_id'))

class UserDtl(Base):
    __tablename__ = 'user_dtls'
    __table_args__ = (
        Index('ix1_user_dtls', 'user_email', 'org_id'),
        Index('ix2_user_dtls', 'user_phone', 'org_id'),
        Index('uix1_user_dtls', 'user_email', 'user_phone', 'org_id', unique=True),
        {'comment': 'User Details Table'}
    )

    user_id = Column(Integer, primary_key=True, comment='Auto Generated user id')
    user_email = Column(String(100), nullable=False, comment='Email id of the customer')
    user_phone = Column(String(15), nullable=False, comment='Phone number of the customer')
    user_type = Column(String(1), nullable=False, comment='C - Customer, B - Bank Officers, A - Independant Financial Advisor, D - Direct Sourcing Associates')
    user_nature = Column(String(1), nullable=False, comment='For Customer or Lead. C - Customer , L - Lead ')
    user_cust_type = Column(String(1), nullable=False, comment='Customer type R - Retail , C - Corporate')
    user_currency = Column(String(3))
    role_code = Column(String(15), nullable=False, comment='Role code mapped for the user')
    preferred_language = Column(String(45), comment='Preferred Language of the user')
    user_phone_cntry = Column(String(2), nullable=False, comment='Country code of the customer')
    user_status = Column(String(1), server_default=text("'A'"), comment=' A- Active, I-Inactive, D-Disabled')
    user_expiry_date = Column(Date, comment='Expiry date of the user account')
    ## HEMA - Check for multiple attempts on OTP
    disabled_from_date = Column(TIMESTAMP, comment='User is disabled from this datetime')
    disabled_to_date = Column(TIMESTAMP, comment='User is disabled until this datetime')
    password = Column(String(255), comment='User Password')
    passw_expiry_date = Column(Date, comment='Expiry date of the user password')
    inv_pw_attmpts = Column(TINYINT(2), nullable=False, server_default=text("'0'"), comment='Current number of invalid password attempts for the user')
    employee_id = Column(String(10), comment='If the logged in user id belongs to an Employee, then the employee id of the user')
    br_id = Column(String(10), comment='Branch code of the user')
    view_access_id = Column(String(255), comment='Access code to view a certain screen')
    temp_view_access_id = Column(String(255), comment='Temporary Access code allocated to the user')
    temp_view_valid_till = Column(Date, comment='Temporary access valid till')
    logged_on_flg = Column(CHAR(1), comment='Is user logged on')
    login_window_enabled = Column(CHAR(1), server_default=text("'N'"), comment='Is a login window within which the user has to login')
    last_login = Column(TIMESTAMP)
    mobile_otp = Column(String(4), comment='One Time Password')
    mobile_otp_count = Column(TINYINT(1), comment='Recent count of OTP sent to user mobile')
    email_otp = Column(String(4), comment='One Time Password sent to user email')
    email_otp_count = Column(TINYINT(1), comment='Recent count of OTP sent to user email')
    entity_cre_flg = Column(String(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified , N means created')
    del_flg = Column(String(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), nullable=False, comment='Organization id to which this record belongs to')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

    if PII_ENCRYPT == "YES":
        first_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        middle_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        last_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        preferred_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_first_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_middle_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_last_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
        alt_preferred_name = Column(EncryptedType(Unicode, PII_KEY,AesEngine,'pkcs5'))
    else:
        first_name = Column(String(30), nullable=False, comment='First name of the user')
        middle_name = Column(String(30), comment='Middle name of the user')
        last_name = Column(String(30), nullable=False, comment='Last name of the user')
        preferred_name = Column(String(30), comment='Preferred name of the user')
        alt_first_name = Column(String(30), comment='First name of the user in alternat language')
        alt_middle_name = Column(String(30), comment='Middle name of the user in alternat language')
        alt_last_name = Column(String(30), comment='Last name of the user in alternat language')
        alt_preferred_name = Column(String(30), comment='Preferred Language of the user in alternat language')

    @property
    def is_authenticated(self):
        return True

    @property
    def logged_in(self):
        print(self._sa_instance_state.__dict__)
        return self.logged_on_flg

    @property
    def is_anonymous(self):
        return False

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def set_password(self, password):
        # if not self.salt:
        #     self.salt = random_characters(10)
        self.password = make_password(password,salt=self.salt)

event.listen(UserDtl, "before_update", before_update_log('user_dtls', 'user_id'))

class YodleeProvider(Base):
    __tablename__ = 'yodlee_provider'
    __table_args__ = {'comment': 'Account Aggregator details'}

    providerId = Column(Integer, primary_key=True, nullable=False, comment='Yodlee providerId')
    providerAccountId = Column(String(30), primary_key=True, nullable=False, comment='Provider Account Id')
    yodlee_status = Column(String(30), comment='LOGIN_IN_PROGRESS, IN_PROGRESS, SUCCESS, Partial SUCCESS, FAILED')
    requestId = Column(String(30), comment='Yodlee account request id')
    aggregationSource = Column(String(30))
    entity_cre_flg = Column(CHAR(1))
    del_flg = Column(CHAR(1))
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50))

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(YodleeProvider, "before_update", before_update_log('yodlee_provider','providerId'))

class AppDocVal(Base):
    __tablename__ = 'app_doc_val'
    __table_args__ = (
        Index('ix3_app_doc_val', 'doc_id', 'org_id'),
        Index('ix2_app_doc_val', 'app_id', 'org_id'),
        Index('ix1_app_doc_val', 'app_id', 'doc_type', 'doc_code', 'org_id'),
        {'comment': 'Uploaded documents format validation details'}
    )

    doc_val_id = Column(Integer, primary_key=True, nullable=False, comment='Auto increment ID', autoincrement=True)
    doc_id = Column(ForeignKey('app_doc_dtls.doc_id'), nullable=False, index=True, comment='Document ID from app_doc_dtls.doc_id')
    app_id = Column(ForeignKey('application_dtls.application_id'), nullable=False, comment='application_dtls.app_id')
    cust_id = Column(String(15), nullable=False, comment='Customer ID')
    doc_type = Column(String(15), nullable=False, comment='Type of document that is needed as proof. ID , ADDRESS , INCOME , TAX etc')
    doc_code = Column(String(15), nullable=False, comment='Code of document that is uploaded')
    side = Column(CHAR(1), comment='Represents the document side')
    doc_val = Column(String(30), nullable=False, comment='Format, Header, Emblem, Hologram, Photo, Colored, Blur, Glare, QR, BAR')
    missing = Column(CHAR(1), server_default=text("'N'"), comment='Data missing or not Y - Missing, N - Not Missing')
    remarks = Column(String(50), comment='Remarks by User')
    sys_status = Column(CHAR(8), server_default=text("'N'"), comment='Validation result by the system P - Pass, F - Fail, N - None')
    user_status = Column(CHAR(1), server_default=text("'N'"), comment='Validation acceptance by the user C - Accept, U - Recollect')
    entity_cre_flg = Column(CHAR(1), server_default=text("'N'"), comment='Has the entity been created. Y means verified, N means just created')
    del_flg = Column(CHAR(1), server_default=text("'N'"), comment='Delete flag. Describes if this record is active or logical deleted')
    rcre_user_id = Column(String(15), comment='Record creation user id')
    rcre_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Record created time')
    lchg_user_id = Column(String(15), comment='Last changed user id')
    lchg_time = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"), comment='Last modified time')
    ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
    org_id = Column(String(50), primary_key=True, nullable=False)

    app = relationship('ApplicationDtl')
    doc = relationship('AppDocDtl')

    __mapper_args__ = {
        "version_id_col": ts_cnt
    }

event.listen(AppDocVal, "before_update", before_update_log('app_doc_val', 'doc_id'))

# class ProdQuesDtl(Base):
#     __tablename__ = 'prod_ques_dtls'
#     __table_args__ = {'schema': 'mydatabase', 'comment': 'Product question details'}

#     prod_ques_id = Column(Integer, primary_key=True, autoincrement=True,nullable=False)
#     prod_code = Column(String(8), comment='prouct code')
#     crncy_code = Column(String(3), comment='currency code')
#     question = Column(String(255), comment='question')
#     ans_field_type = Column(String(15), comment='Answer field type')
#     field_idfr = Column(String(30), comment='field identifier')
#     conf_ans = Column(String(1), comment='Confirm answer if Yes-show match,mismatch and NO-get answer from customer')
#     mandate = Column(String(1), comment='The question is mandatory or not')
#     entity_cre_flg = Column(CHAR(1))
#     del_flg = Column(CHAR(1))
#     rcre_user_id = Column(String(15), comment='Record creation user id')
#     rcre_time = Column(TIMESTAMP, comment='Record created time')
#     lchg_user_id = Column(String(15), comment='Last changed user id')
#     lchg_time = Column(TIMESTAMP, comment='Last modified time')
#     ts_cnt = Column(Integer, server_default=text("'0'"), comment='Count for concurrency')
#     org_id = Column(String(15), primary_key=True, nullable=False)

#     __mapper_args__ = {
#         "version_id_col": ts_cnt
#     }

# event.listen(ProdQuesDtl, "before_update", before_update_log)
# class ProdCapDtl(Base):
#     __tablename__ = 'prod_cap_dtls'
#     __table_args__ = {'schema': 'mydatabase', 'comment': 'Product capture details'}

#     prod_cap_id = Column(Integer, primary_key=True, autoincrement=True,nullable=False, )
#     prod_code = Column(String(8), comment='prouct code')
#     crncy_code = Column(String(3), comment='currency code')
#     doc_type = Column(String(15), comment='Document category')
#     doc_code = Column(String(15), comment='Document sub category')
#     mandate = Column(String(1), comment='The question is mandatory or not')
#     conf_ans = Column(String(1), comment='confirm answer')
#     doc_compare = Column(String(1), comment='compare with document')
#     comp_doc_type = Column(String(15), comment='comparing document type')
#     comp_doc_code= Column(String(15), comment='comparing document type')
#     entity_cre_flg = Column(CHAR(1))
#     del_flg = Column(CHAR(1))
#     rcre_user_id = Column(String(15), comment='Record creation user id')
#     rcre_time = Column(TIMESTAMP, comment='Record created time')
#     lchg_user_id = Column(String(15), comment='Last changed user id')
#     lchg_time = Column(TIMESTAMP, comment='Last modified time')
#     ts_cnt = Column(Integer, server_default=text("'0'"))
#     org_id = Column(String(15), primary_key=True, nullable=False)

#     __mapper_args__ = {
#         "version_id_col": ts_cnt
#     }

# event.listen(ProdCapDtl, "before_update", before_update_log)
class AuditlogLogentry(Base):
    __tablename__ = 'auditlog_logentry'

    id = Column(Integer, primary_key=True)
    object_pk = Column(String(255), nullable=False, index=True)
    object_id = Column(BigInteger, index=True)
    object_repr = Column(LONGTEXT, nullable=False)
    action = Column(SMALLINT, nullable=False)
    changes = Column(LONGTEXT, nullable=False)
    timestamp = Column(DATETIME(fsp=6), nullable=False)
    actor_id = Column(ForeignKey('auth_user.id'), index=True)
    content_type_id = Column(ForeignKey('django_content_type.id'), nullable=False, index=True)
    remote_addr = Column(CHAR(39))
    additional_data = Column(LONGTEXT)

    actor = relationship('AuthUser')
    content_type = relationship('DjangoContentType')


class Auditor(Base):
    __tablename__ = 'auditor'

    id = Column(Integer, primary_key=True)
    field = Column(String(255), nullable=False)
    action = Column(String(6), nullable=False)
    old_value = Column(LONGTEXT)
    new_value = Column(LONGTEXT)
    stamp = Column(DATETIME(fsp=6), nullable=False)
    user = Column(String(255), nullable=False)
    object_id = Column(INTEGER, nullable=False)
    content_object = Column(LONGTEXT, nullable=False)
    content_type_id = Column(ForeignKey('django_content_type.id'), nullable=False, index=True)

    content_type = relationship('DjangoContentType')


class AuthPermission(Base):
    __tablename__ = 'auth_permission'
    __table_args__ = (
        Index('auth_permission_content_type_id_codename_01ab375a_uniq', 'content_type_id', 'codename', unique=True),
    )

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    content_type_id = Column(ForeignKey('django_content_type.id'), nullable=False)
    codename = Column(String(100), nullable=False)

    content_type = relationship('DjangoContentType')


class AuthUserGroup(Base):
    __tablename__ = 'auth_user_groups'
    __table_args__ = (
        Index('auth_user_groups_user_id_group_id_94350c0c_uniq', 'user_id', 'group_id', unique=True),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(ForeignKey('auth_user.id'), nullable=False)
    group_id = Column(ForeignKey('auth_group.id'), nullable=False, index=True)

    group = relationship('AuthGroup')
    user = relationship('AuthUser')


class AuthtokenToken(Base):
    __tablename__ = 'authtoken_token'

    key = Column(String(40), primary_key=True)
    created = Column(DATETIME(fsp=6), nullable=False)
    user_id = Column(ForeignKey('auth_user.id'), nullable=False, unique=True)

    user = relationship('AuthUser')


class DjangoAdminLog(Base):
    __tablename__ = 'django_admin_log'

    id = Column(Integer, primary_key=True)
    action_time = Column(DATETIME(fsp=6), nullable=False)
    object_id = Column(LONGTEXT)
    object_repr = Column(String(200), nullable=False)
    action_flag = Column(SMALLINT, nullable=False)
    change_message = Column(LONGTEXT, nullable=False)
    content_type_id = Column(ForeignKey('django_content_type.id'), index=True)
    user_id = Column(ForeignKey('auth_user.id'), nullable=False, index=True)

    content_type = relationship('DjangoContentType')
    user = relationship('AuthUser')


class AuthGroupPermission(Base):
    __tablename__ = 'auth_group_permissions'
    __table_args__ = (
        Index('auth_group_permissions_group_id_permission_id_0cd325b0_uniq', 'group_id', 'permission_id', unique=True),
    )

    id = Column(Integer, primary_key=True)
    group_id = Column(ForeignKey('auth_group.id'), nullable=False)
    permission_id = Column(ForeignKey('auth_permission.id'), nullable=False, index=True)

    group = relationship('AuthGroup')
    permission = relationship('AuthPermission')


class AuthUserUserPermission(Base):
    __tablename__ = 'auth_user_user_permissions'
    __table_args__ = (
        Index('auth_user_user_permissions_user_id_permission_id_14a6b632_uniq', 'user_id', 'permission_id', unique=True),
    )

    id = Column(Integer, primary_key=True)
    user_id = Column(ForeignKey('auth_user.id'), nullable=False)
    permission_id = Column(ForeignKey('auth_permission.id'), nullable=False, index=True)

    permission = relationship('AuthPermission')
    user = relationship('AuthUser')