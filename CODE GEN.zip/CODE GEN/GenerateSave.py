import modelnew
from sqlalchemy.ext.declarative.api import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.sql.elements import TextClause

def get_func(classname,column,primary_keys_list):
    try:
        print("primary_keys_list -> ",primary_keys_list)
        if 'org_id' in primary_keys_list:
            primary_keys_list.remove('org_id')
        print("2 primary_keys_list -> ",primary_keys_list)
        pk = ""
        for col in primary_keys_list:
            if "org_id" != col:
                pk += f"{col}= {col},"

        if column in primary_keys_list:
            return ""

    
        if column in ['org_id','ts_cnt','entity_cre_flg','del_flg']:
            # return f"def skip_{column}():\n\tpass "
            return ""
        if 'rcre' in column or 'lchg' in column:
            # return f"def skip_{column}():\n\tpass "
            return ""
        print("pkl -> ",primary_keys_list,len(primary_keys_list))
        print("column -> ",column)

        string = '''\n
    def get_{column}(self,session,{pkl},{column}):
        try:
            return session.query({classname}).filter( {classname}.org_id == org_id, {classname}.entity_cre_flg == 'Y', {classname}.del_flg == 'N').all()
            return ['status' : "SUCCESS"]
        except Exception as e:
            print(" [*] update_{column} Error :",str(e))
            return ['status' : "ERROR"]\n'''.format(pk=pk,pkl=','.join(primary_keys_list),column=column,classname=classname).replace("[","{").replace("]","}")
        return string
    except Exception as e:
        print("hello ->",e)


def update_func(classname,column,primary_keys_list):
    try:
        print("primary_keys_list -> ",primary_keys_list)
        if 'org_id' in primary_keys_list:
            primary_keys_list.remove('org_id')
        print("2 primary_keys_list -> ",primary_keys_list)
        pk = ""
        for col in primary_keys_list:
            if "org_id" != col:
                pk += f"{col}= {col},"

        if column in primary_keys_list:
            return ""

    
        if column in ['org_id','ts_cnt','entity_cre_flg','del_flg']:
            # return f"def skip_{column}():\n\tpass "
            return ""
        if 'rcre' in column or 'lchg' in column:
            # return f"def skip_{column}():\n\tpass "
            return ""
        print("pkl -> ",primary_keys_list,len(primary_keys_list))
        print("column -> ",column)

        string = '''\n
    def update_{column}(self,session,{pkl},{column}):
        try:
            session.query({classname}).filter_by(
                org_id=self.org_id,
                {pk}
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict({column}={column}))
            return ['status' : "SUCCESS"]
        except Exception as e:
            print(" [*] update_{column} Error :",str(e))
            return ['status' : "ERROR"]\n'''.format(pk=pk,pkl=','.join(primary_keys_list),column=column,classname=classname).replace("[","{").replace("]","}")
        return string
    except Exception as e:
        print("hello ->",e)

def save_function(class_name,table_name,colum_list):
    # try:
    # rc = ["del_flg","entity_cre_flg","lchg_time","lchg_user_id"]
    # params = [colum_list.remove(item) for item in rc if item in colum_list] 
    # print(params)
    cl = ""
    for col in colum_list:
        if col == "del_flg":
            pass
        if col == "entity_cre_flg":
            pass
        if col == "lchg_time":
            pass
        if col == "lchg_user_id":
            pass
        if col == "rcre_time":
            pass
        if col == "rcre_user_id":
            pass
        if col == "ts_cnt":
            pass
        if col == "org_id":
            pass

        cl += f"\t\tobj.{col} = {col}\n"

    string = """
def save_{table_name}(session,{params}=None):\n\ttry:\n\t\tobj = {class_name}()
{cl}
\t\tsession.add(obj)
\t\treturn ['status' : "SUCCESS"]
\texcept Exception as e:
\t\tprint(" [*] save_{table_name} Error :",str(e))
\t\treturn ['status' : "ERROR"]""".format(class_name=class_name,table_name=table_name,cl=cl,params="=None,".join(colum_list)).replace("[","{").replace("]","}")
    return string
    # except Exception as e:
    #     print(e)

print("from modelnew import *")
for i in dir(modelnew):
    try:
        class_output = ""
        classname = getattr(modelnew, i)
        if type(classname)==DeclarativeMeta:
            class_output += f"from modelnew import *\n"
            class_output += f"class ClsUp{i}:"
            class_output += f"\n\tdef __init__(self,org_id):"
            # class_output += f"\n\t\tpass"
            class_output += f"\n\t\tself.org_id=org_id"
            class_output += f"\n\t\tself.entity_cre_flg='Y'"
            class_output += f"\n\t\tself.del_flg='N'"
            # class_output +="\n"
            column_list = []
            primary_keys_list = []
            for column in dir(classname):
                col_name = getattr(classname, column)
                try:
                    if col_name.primary_key == True:
                        print("col_name.primary_key :",column,col_name.primary_key)
                        primary_keys_list.append(column)
                    # if col_name.nullable == True:
                    #     print("col_name.nullable :",column,col_name.nullable)
                    if col_name.server_default != None:
                        print("col_name.server_default :",column,col_name.server_default)
                except:
                    pass
                # print(type(column,getattr(classname, column)))
            for column in dir(classname):
                col_name = getattr(classname, column)
                if (type(col_name)==InstrumentedAttribute):
                    column_list.append(column)
                    # print("Column Name : ",col_name)

                    
                    
                    outstring = update_func(i,column,primary_keys_list)
                    class_output += outstring
                    # print(outstring)
                    # print("\n\n")
            print("\n")
            # print(save_function(i,classname.__table__,column_list))
            # print(class_output)

            f = open(f"CRUD/get{i}.py", "w")
            f.write(class_output)
            f.close()

                    
    except:
        pass