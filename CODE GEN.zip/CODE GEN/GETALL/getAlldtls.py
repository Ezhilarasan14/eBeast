from modelnew import *
import SqlAlchemyModelEncoder

class ClsAllColumnDtls:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

	def get_app_data_comp(self,session,comp_id=None,return_type='J'):
		try:
			query = session.query(AppDataComp).filter(
			AppDataComp.org_id == self.org_id,
			AppDataComp.entity_cre_flg == self.entity_cre_flg,
			AppDataComp.del_flg == self.del_flg)
			if comp_id != None:
				query = query.filter(AppDataComp.comp_id == comp_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_data_compare(self,session,app_step_id=None,doc_code=None,doc_type=None,id=None,info_key=None,return_type='J'):
		try:
			query = session.query(AppDataCompare).filter(
			AppDataCompare.org_id == self.org_id,
			AppDataCompare.entity_cre_flg == self.entity_cre_flg,
			AppDataCompare.del_flg == self.del_flg)
			if app_step_id != None:
				query = query.filter(AppDataCompare.app_step_id == app_step_id)
			if doc_code != None:
				query = query.filter(AppDataCompare.doc_code == doc_code)
			if doc_type != None:
				query = query.filter(AppDataCompare.doc_type == doc_type)
			if id != None:
				query = query.filter(AppDataCompare.id == id)
			if info_key != None:
				query = query.filter(AppDataCompare.info_key == info_key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_remarks Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_data_val(self,session,data_val_id=None,return_type='J'):
		try:
			query = session.query(AppDataVal).filter(
			AppDataVal.org_id == self.org_id,
			AppDataVal.entity_cre_flg == self.entity_cre_flg,
			AppDataVal.del_flg == self.del_flg)
			if data_val_id != None:
				query = query.filter(AppDataVal.data_val_id == data_val_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_doc_dtls(self,session,doc_id=None,return_type='J'):
		try:
			query = session.query(AppDocDtl).filter(
			AppDocDtl.org_id == self.org_id,
			AppDocDtl.entity_cre_flg == self.entity_cre_flg,
			AppDocDtl.del_flg == self.del_flg)
			if doc_id != None:
				query = query.filter(AppDocDtl.doc_id == doc_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_doc_val(self,session,doc_val_id=None,return_type='J'):
		try:
			query = session.query(AppDocVal).filter(
			AppDocVal.org_id == self.org_id,
			AppDocVal.entity_cre_flg == self.entity_cre_flg,
			AppDocVal.del_flg == self.del_flg)
			if doc_val_id != None:
				query = query.filter(AppDocVal.doc_val_id == doc_val_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_emp_dtls(self,session,employer_id=None,return_type='J'):
		try:
			query = session.query(AppEmpDtl).filter(
			AppEmpDtl.org_id == self.org_id,
			AppEmpDtl.entity_cre_flg == self.entity_cre_flg,
			AppEmpDtl.del_flg == self.del_flg)
			if employer_id != None:
				query = query.filter(AppEmpDtl.employer_id == employer_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_years_of_exp Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_id_ver(self,session,id_ver_no=None,return_type='J'):
		try:
			query = session.query(AppIdVer).filter(
			AppIdVer.org_id == self.org_id,
			AppIdVer.entity_cre_flg == self.entity_cre_flg,
			AppIdVer.del_flg == self.del_flg)
			if id_ver_no != None:
				query = query.filter(AppIdVer.id_ver_no == id_ver_no)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_integ(self,session,app_integ_id=None,return_type='J'):
		try:
			query = session.query(AppInteg).filter(
			AppInteg.org_id == self.org_id,
			AppInteg.entity_cre_flg == self.entity_cre_flg,
			AppInteg.del_flg == self.del_flg)
			if app_integ_id != None:
				query = query.filter(AppInteg.app_integ_id == app_integ_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_location(self,session,loc_id=None,return_type='J'):
		try:
			query = session.query(AppLocation).filter(
			AppLocation.org_id == self.org_id,
			AppLocation.entity_cre_flg == self.entity_cre_flg,
			AppLocation.del_flg == self.del_flg)
			if loc_id != None:
				query = query.filter(AppLocation.loc_id == loc_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_other_fields(self,session,id=None,return_type='J'):
		try:
			query = session.query(AppOtherField).filter(
			AppOtherField.org_id == self.org_id,
			AppOtherField.entity_cre_flg == self.entity_cre_flg,
			AppOtherField.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AppOtherField.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_app_steps(self,session,app_step_id=None,return_type='J'):
		try:
			query = session.query(AppStep).filter(
			AppStep.org_id == self.org_id,
			AppStep.entity_cre_flg == self.entity_cre_flg,
			AppStep.del_flg == self.del_flg)
			if app_step_id != None:
				query = query.filter(AppStep.app_step_id == app_step_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_verified_doc_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_application_dtls(self,session,application_id=None,return_type='J'):
		try:
			query = session.query(ApplicationDtl).filter(
			ApplicationDtl.org_id == self.org_id,
			ApplicationDtl.entity_cre_flg == self.entity_cre_flg,
			ApplicationDtl.del_flg == self.del_flg)
			if application_id != None:
				query = query.filter(ApplicationDtl.application_id == application_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_video_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_appointment_dtls(self,session,appointment_id=None,return_type='J'):
		try:
			query = session.query(AppointmentDtl).filter(
			AppointmentDtl.org_id == self.org_id,
			AppointmentDtl.entity_cre_flg == self.entity_cre_flg,
			AppointmentDtl.del_flg == self.del_flg)
			if appointment_id != None:
				query = query.filter(AppointmentDtl.appointment_id == appointment_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_venue Error :",str(e))
			return {'status' : "ERROR"}


	def get_audit_dtls(self,session,req_id=None,return_type='J'):
		try:
			query = session.query(AuditDtl).filter(
			AuditDtl.org_id == self.org_id,
			AuditDtl.entity_cre_flg == self.entity_cre_flg,
			AuditDtl.del_flg == self.del_flg)
			if req_id != None:
				query = query.filter(AuditDtl.req_id == req_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_auditlog_logentry(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuditlogLogentry).filter(
			AuditlogLogentry.org_id == self.org_id,
			AuditlogLogentry.entity_cre_flg == self.entity_cre_flg,
			AuditlogLogentry.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuditlogLogentry.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_timestamp Error :",str(e))
			return {'status' : "ERROR"}


	def get_auditor(self,session,id=None,return_type='J'):
		try:
			query = session.query(Auditor).filter(
			Auditor.org_id == self.org_id,
			Auditor.entity_cre_flg == self.entity_cre_flg,
			Auditor.del_flg == self.del_flg)
			if id != None:
				query = query.filter(Auditor.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_group(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthGroup).filter(
			AuthGroup.org_id == self.org_id,
			AuthGroup.entity_cre_flg == self.entity_cre_flg,
			AuthGroup.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthGroup.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_name Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_group_permissions(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthGroupPermission).filter(
			AuthGroupPermission.org_id == self.org_id,
			AuthGroupPermission.entity_cre_flg == self.entity_cre_flg,
			AuthGroupPermission.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthGroupPermission.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_permission_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_matrix_config(self,session,auth_matrix_id=None,return_type='J'):
		try:
			query = session.query(AuthMatrixConfig).filter(
			AuthMatrixConfig.org_id == self.org_id,
			AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg,
			AuthMatrixConfig.del_flg == self.del_flg)
			if auth_matrix_id != None:
				query = query.filter(AuthMatrixConfig.auth_matrix_id == auth_matrix_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_permission(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthPermission).filter(
			AuthPermission.org_id == self.org_id,
			AuthPermission.entity_cre_flg == self.entity_cre_flg,
			AuthPermission.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthPermission.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_name Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_token(self,session,key=None,return_type='J'):
		try:
			query = session.query(AuthToken).filter(
			AuthToken.org_id == self.org_id,
			AuthToken.entity_cre_flg == self.entity_cre_flg,
			AuthToken.del_flg == self.del_flg)
			if key != None:
				query = query.filter(AuthToken.key == key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_user(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthUser).filter(
			AuthUser.org_id == self.org_id,
			AuthUser.entity_cre_flg == self.entity_cre_flg,
			AuthUser.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthUser.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_username Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_user_groups(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthUserGroup).filter(
			AuthUserGroup.org_id == self.org_id,
			AuthUserGroup.entity_cre_flg == self.entity_cre_flg,
			AuthUserGroup.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthUserGroup.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_auth_user_user_permissions(self,session,id=None,return_type='J'):
		try:
			query = session.query(AuthUserUserPermission).filter(
			AuthUserUserPermission.org_id == self.org_id,
			AuthUserUserPermission.entity_cre_flg == self.entity_cre_flg,
			AuthUserUserPermission.del_flg == self.del_flg)
			if id != None:
				query = query.filter(AuthUserUserPermission.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_authtoken_token(self,session,key=None,return_type='J'):
		try:
			query = session.query(AuthtokenToken).filter(
			AuthtokenToken.org_id == self.org_id,
			AuthtokenToken.entity_cre_flg == self.entity_cre_flg,
			AuthtokenToken.del_flg == self.del_flg)
			if key != None:
				query = query.filter(AuthtokenToken.key == key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_calendar_dtls(self,session,mmyyyy=None,return_type='J'):
		try:
			query = session.query(CalendarDtl).filter(
			CalendarDtl.org_id == self.org_id,
			CalendarDtl.entity_cre_flg == self.entity_cre_flg,
			CalendarDtl.del_flg == self.del_flg)
			if mmyyyy != None:
				query = query.filter(CalendarDtl.mmyyyy == mmyyyy)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_call_requests(self,session,req_id=None,return_type='J'):
		try:
			query = session.query(CallRequest).filter(
			CallRequest.org_id == self.org_id,
			CallRequest.entity_cre_flg == self.entity_cre_flg,
			CallRequest.del_flg == self.del_flg)
			if req_id != None:
				query = query.filter(CallRequest.req_id == req_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_category_dtls(self,session,cat_id=None,return_type='J'):
		try:
			query = session.query(CategoryDtl).filter(
			CategoryDtl.org_id == self.org_id,
			CategoryDtl.entity_cre_flg == self.entity_cre_flg,
			CategoryDtl.del_flg == self.del_flg)
			if cat_id != None:
				query = query.filter(CategoryDtl.cat_id == cat_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_cities(self,session,id=None,return_type='J'):
		try:
			query = session.query(City).filter(
			City.org_id == self.org_id,
			City.entity_cre_flg == self.entity_cre_flg,
			City.del_flg == self.del_flg)
			if id != None:
				query = query.filter(City.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_wikiDataId Error :",str(e))
			return {'status' : "ERROR"}


	def get_co_applicants(self,session,co_applicant_id=None,return_type='J'):
		try:
			query = session.query(CoApplicant).filter(
			CoApplicant.org_id == self.org_id,
			CoApplicant.entity_cre_flg == self.entity_cre_flg,
			CoApplicant.del_flg == self.del_flg)
			if co_applicant_id != None:
				query = query.filter(CoApplicant.co_applicant_id == co_applicant_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_coa_dtls(self,session,coa_id=None,return_type='J'):
		try:
			query = session.query(CoaDtl).filter(
			CoaDtl.org_id == self.org_id,
			CoaDtl.entity_cre_flg == self.entity_cre_flg,
			CoaDtl.del_flg == self.del_flg)
			if coa_id != None:
				query = query.filter(CoaDtl.coa_id == coa_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_countries(self,session,id=None,return_type='J'):
		try:
			query = session.query(Country).filter(
			Country.org_id == self.org_id,
			Country.entity_cre_flg == self.entity_cre_flg,
			Country.del_flg == self.del_flg)
			if id != None:
				query = query.filter(Country.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_wikiDataId Error :",str(e))
			return {'status' : "ERROR"}


	def get_country_dtls(self,session,cntry_code=None,crncy_code=None,return_type='J'):
		try:
			query = session.query(CountryDtl).filter(
			CountryDtl.org_id == self.org_id,
			CountryDtl.entity_cre_flg == self.entity_cre_flg,
			CountryDtl.del_flg == self.del_flg)
			if cntry_code != None:
				query = query.filter(CountryDtl.cntry_code == cntry_code)
			if crncy_code != None:
				query = query.filter(CountryDtl.crncy_code == crncy_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_currency_dtls(self,session,crncy_code=None,return_type='J'):
		try:
			query = session.query(CurrencyDtl).filter(
			CurrencyDtl.org_id == self.org_id,
			CurrencyDtl.entity_cre_flg == self.entity_cre_flg,
			CurrencyDtl.del_flg == self.del_flg)
			if crncy_code != None:
				query = query.filter(CurrencyDtl.crncy_code == crncy_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_cust_bank_dtls(self,session,cust_id=None,return_type='J'):
		try:
			query = session.query(CustBankDtl).filter(
			CustBankDtl.org_id == self.org_id,
			CustBankDtl.entity_cre_flg == self.entity_cre_flg,
			CustBankDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(CustBankDtl.cust_id == cust_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_cust_category(self,session,cust_id=None,sys_cat_id=None,tran_date=None,tran_id=None,user_cat_id=None,return_type='J'):
		try:
			query = session.query(CustCategory).filter(
			CustCategory.org_id == self.org_id,
			CustCategory.entity_cre_flg == self.entity_cre_flg,
			CustCategory.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(CustCategory.cust_id == cust_id)
			if sys_cat_id != None:
				query = query.filter(CustCategory.sys_cat_id == sys_cat_id)
			if tran_date != None:
				query = query.filter(CustCategory.tran_date == tran_date)
			if tran_id != None:
				query = query.filter(CustCategory.tran_id == tran_id)
			if user_cat_id != None:
				query = query.filter(CustCategory.user_cat_id == user_cat_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_parent_cat_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_cust_contact(self,session,cont_id=None,return_type='J'):
		try:
			query = session.query(CustContact).filter(
			CustContact.org_id == self.org_id,
			CustContact.entity_cre_flg == self.entity_cre_flg,
			CustContact.del_flg == self.del_flg)
			if cont_id != None:
				query = query.filter(CustContact.cont_id == cont_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_customer_dtls(self,session,cust_id=None,return_type='J'):
		try:
			query = session.query(CustomerDtl).filter(
			CustomerDtl.org_id == self.org_id,
			CustomerDtl.entity_cre_flg == self.entity_cre_flg,
			CustomerDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(CustomerDtl.cust_id == cust_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_view_access_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_daily_tran_dtls(self,session,int_tran_id=None,return_type='J'):
		try:
			query = session.query(DailyTranDtl).filter(
			DailyTranDtl.org_id == self.org_id,
			DailyTranDtl.entity_cre_flg == self.entity_cre_flg,
			DailyTranDtl.del_flg == self.del_flg)
			if int_tran_id != None:
				query = query.filter(DailyTranDtl.int_tran_id == int_tran_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_value_date Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_admin_log(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoAdminLog).filter(
			DjangoAdminLog.org_id == self.org_id,
			DjangoAdminLog.entity_cre_flg == self.entity_cre_flg,
			DjangoAdminLog.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoAdminLog.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_celery_pending_list(self,session,cache_key=None,return_type='J'):
		try:
			query = session.query(DjangoCeleryPendingList).filter(
			DjangoCeleryPendingList.org_id == self.org_id,
			DjangoCeleryPendingList.entity_cre_flg == self.entity_cre_flg,
			DjangoCeleryPendingList.del_flg == self.del_flg)
			if cache_key != None:
				query = query.filter(DjangoCeleryPendingList.cache_key == cache_key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_value Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_celery_results_chordcounter(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoCeleryResultsChordcounter).filter(
			DjangoCeleryResultsChordcounter.org_id == self.org_id,
			DjangoCeleryResultsChordcounter.entity_cre_flg == self.entity_cre_flg,
			DjangoCeleryResultsChordcounter.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoCeleryResultsChordcounter.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_sub_tasks Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_celery_results_groupresult(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoCeleryResultsGroupresult).filter(
			DjangoCeleryResultsGroupresult.org_id == self.org_id,
			DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg,
			DjangoCeleryResultsGroupresult.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoCeleryResultsGroupresult.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_result Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_celery_results_taskresult(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoCeleryResultsTaskresult).filter(
			DjangoCeleryResultsTaskresult.org_id == self.org_id,
			DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg,
			DjangoCeleryResultsTaskresult.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoCeleryResultsTaskresult.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_worker Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_content_type(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoContentType).filter(
			DjangoContentType.org_id == self.org_id,
			DjangoContentType.entity_cre_flg == self.entity_cre_flg,
			DjangoContentType.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoContentType.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_model Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_migrations(self,session,id=None,return_type='J'):
		try:
			query = session.query(DjangoMigration).filter(
			DjangoMigration.org_id == self.org_id,
			DjangoMigration.entity_cre_flg == self.entity_cre_flg,
			DjangoMigration.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DjangoMigration.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_name Error :",str(e))
			return {'status' : "ERROR"}


	def get_django_session(self,session,session_key=None,return_type='J'):
		try:
			query = session.query(DjangoSession).filter(
			DjangoSession.org_id == self.org_id,
			DjangoSession.entity_cre_flg == self.entity_cre_flg,
			DjangoSession.del_flg == self.del_flg)
			if session_key != None:
				query = query.filter(DjangoSession.session_key == session_key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_session_key Error :",str(e))
			return {'status' : "ERROR"}


	def get_drf_api_logs(self,session,id=None,return_type='J'):
		try:
			query = session.query(DrfApiLog).filter(
			DrfApiLog.org_id == self.org_id,
			DrfApiLog.entity_cre_flg == self.entity_cre_flg,
			DrfApiLog.del_flg == self.del_flg)
			if id != None:
				query = query.filter(DrfApiLog.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_status_code Error :",str(e))
			return {'status' : "ERROR"}


	def get_entity_access(self,session,entity_int_id=None,finserv_id=None,return_type='J'):
		try:
			query = session.query(EntityAcces).filter(
			EntityAcces.org_id == self.org_id,
			EntityAcces.entity_cre_flg == self.entity_cre_flg,
			EntityAcces.del_flg == self.del_flg)
			if entity_int_id != None:
				query = query.filter(EntityAcces.entity_int_id == entity_int_id)
			if finserv_id != None:
				query = query.filter(EntityAcces.finserv_id == finserv_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_entity_dtls(self,session,bank_id=None,entity_id=None,entity_int_id=None,return_type='J'):
		try:
			query = session.query(EntityDtl).filter(
			EntityDtl.org_id == self.org_id,
			EntityDtl.entity_cre_flg == self.entity_cre_flg,
			EntityDtl.del_flg == self.del_flg)
			if bank_id != None:
				query = query.filter(EntityDtl.bank_id == bank_id)
			if entity_id != None:
				query = query.filter(EntityDtl.entity_id == entity_id)
			if entity_int_id != None:
				query = query.filter(EntityDtl.entity_int_id == entity_int_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_yodlee_status Error :",str(e))
			return {'status' : "ERROR"}


	def get_fees_dtls(self,session,fee_code=None,fee_crncy_code=None,finserv_id=None,return_type='J'):
		try:
			query = session.query(FeesDtl).filter(
			FeesDtl.org_id == self.org_id,
			FeesDtl.entity_cre_flg == self.entity_cre_flg,
			FeesDtl.del_flg == self.del_flg)
			if fee_code != None:
				query = query.filter(FeesDtl.fee_code == fee_code)
			if fee_crncy_code != None:
				query = query.filter(FeesDtl.fee_crncy_code == fee_crncy_code)
			if finserv_id != None:
				query = query.filter(FeesDtl.finserv_id == finserv_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_finserv_branch(self,session,br_id=None,finserv_id=None,return_type='J'):
		try:
			query = session.query(FinservBranch).filter(
			FinservBranch.org_id == self.org_id,
			FinservBranch.entity_cre_flg == self.entity_cre_flg,
			FinservBranch.del_flg == self.del_flg)
			if br_id != None:
				query = query.filter(FinservBranch.br_id == br_id)
			if finserv_id != None:
				query = query.filter(FinservBranch.finserv_id == finserv_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_wkly_off Error :",str(e))
			return {'status' : "ERROR"}


	def get_finserv_contact(self,session,contact_sub_type=None,contact_type=None,finserv_id=None,return_type='J'):
		try:
			query = session.query(FinservContact).filter(
			FinservContact.org_id == self.org_id,
			FinservContact.entity_cre_flg == self.entity_cre_flg,
			FinservContact.del_flg == self.del_flg)
			if contact_sub_type != None:
				query = query.filter(FinservContact.contact_sub_type == contact_sub_type)
			if contact_type != None:
				query = query.filter(FinservContact.contact_type == contact_type)
			if finserv_id != None:
				query = query.filter(FinservContact.finserv_id == finserv_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_finserv_dtls(self,session,finserv_id=None,return_type='J'):
		try:
			query = session.query(FinservDtl).filter(
			FinservDtl.org_id == self.org_id,
			FinservDtl.entity_cre_flg == self.entity_cre_flg,
			FinservDtl.del_flg == self.del_flg)
			if finserv_id != None:
				query = query.filter(FinservDtl.finserv_id == finserv_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_form_details(self,session,field_id=None,form_id=None,id=None,section_id=None,return_type='J'):
		try:
			query = session.query(FormDetail).filter(
			FormDetail.org_id == self.org_id,
			FormDetail.entity_cre_flg == self.entity_cre_flg,
			FormDetail.del_flg == self.del_flg)
			if field_id != None:
				query = query.filter(FormDetail.field_id == field_id)
			if form_id != None:
				query = query.filter(FormDetail.form_id == form_id)
			if id != None:
				query = query.filter(FormDetail.id == id)
			if section_id != None:
				query = query.filter(FormDetail.section_id == section_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_form_section(self,session,field_id=None,id=None,section_id=None,return_type='J'):
		try:
			query = session.query(FormSection).filter(
			FormSection.org_id == self.org_id,
			FormSection.entity_cre_flg == self.entity_cre_flg,
			FormSection.del_flg == self.del_flg)
			if field_id != None:
				query = query.filter(FormSection.field_id == field_id)
			if id != None:
				query = query.filter(FormSection.id == id)
			if section_id != None:
				query = query.filter(FormSection.section_id == section_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_general_code(self,session,gen_id=None,return_type='J'):
		try:
			query = session.query(GeneralCode).filter(
			GeneralCode.org_id == self.org_id,
			GeneralCode.entity_cre_flg == self.entity_cre_flg,
			GeneralCode.del_flg == self.del_flg)
			if gen_id != None:
				query = query.filter(GeneralCode.gen_id == gen_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_goal_dtls(self,session,cust_id=None,goal_name=None,return_type='J'):
		try:
			query = session.query(GoalDtl).filter(
			GoalDtl.org_id == self.org_id,
			GoalDtl.entity_cre_flg == self.entity_cre_flg,
			GoalDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(GoalDtl.cust_id == cust_id)
			if goal_name != None:
				query = query.filter(GoalDtl.goal_name == goal_name)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_interview_dtls(self,session,application_id=None,call_id=None,ques_no=None,return_type='J'):
		try:
			query = session.query(InterviewDtl).filter(
			InterviewDtl.org_id == self.org_id,
			InterviewDtl.entity_cre_flg == self.entity_cre_flg,
			InterviewDtl.del_flg == self.del_flg)
			if application_id != None:
				query = query.filter(InterviewDtl.application_id == application_id)
			if call_id != None:
				query = query.filter(InterviewDtl.call_id == call_id)
			if ques_no != None:
				query = query.filter(InterviewDtl.ques_no == ques_no)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_lead_contact(self,session,contact_sub_type=None,contact_type=None,lead_id=None,return_type='J'):
		try:
			query = session.query(LeadContact).filter(
			LeadContact.org_id == self.org_id,
			LeadContact.entity_cre_flg == self.entity_cre_flg,
			LeadContact.del_flg == self.del_flg)
			if contact_sub_type != None:
				query = query.filter(LeadContact.contact_sub_type == contact_sub_type)
			if contact_type != None:
				query = query.filter(LeadContact.contact_type == contact_type)
			if lead_id != None:
				query = query.filter(LeadContact.lead_id == lead_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_leads_dtls(self,session,lead_id=None,return_type='J'):
		try:
			query = session.query(LeadsDtl).filter(
			LeadsDtl.org_id == self.org_id,
			LeadsDtl.entity_cre_flg == self.entity_cre_flg,
			LeadsDtl.del_flg == self.del_flg)
			if lead_id != None:
				query = query.filter(LeadsDtl.lead_id == lead_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_mail_audit_dtls(self,session,req_id=None,return_type='J'):
		try:
			query = session.query(MailAuditDtl).filter(
			MailAuditDtl.org_id == self.org_id,
			MailAuditDtl.entity_cre_flg == self.entity_cre_flg,
			MailAuditDtl.del_flg == self.del_flg)
			if req_id != None:
				query = query.filter(MailAuditDtl.req_id == req_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_my_cache_table(self,session,cache_key=None,return_type='J'):
		try:
			query = session.query(MyCacheTable).filter(
			MyCacheTable.org_id == self.org_id,
			MyCacheTable.entity_cre_flg == self.entity_cre_flg,
			MyCacheTable.del_flg == self.del_flg)
			if cache_key != None:
				query = query.filter(MyCacheTable.cache_key == cache_key)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_value Error :",str(e))
			return {'status' : "ERROR"}


	def get_network_dir(self,session,file_source=None,file_type=None,ref_key=None,unq_bank_identifier=None,return_type='J'):
		try:
			query = session.query(NetworkDir).filter(
			NetworkDir.org_id == self.org_id,
			NetworkDir.entity_cre_flg == self.entity_cre_flg,
			NetworkDir.del_flg == self.del_flg)
			if file_source != None:
				query = query.filter(NetworkDir.file_source == file_source)
			if file_type != None:
				query = query.filter(NetworkDir.file_type == file_type)
			if ref_key != None:
				query = query.filter(NetworkDir.ref_key == ref_key)
			if unq_bank_identifier != None:
				query = query.filter(NetworkDir.unq_bank_identifier == unq_bank_identifier)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_unq_bank_identifier Error :",str(e))
			return {'status' : "ERROR"}


	def get_ntfn_conf(self,session,notif_code=None,return_type='J'):
		try:
			query = session.query(NtfnConf).filter(
			NtfnConf.org_id == self.org_id,
			NtfnConf.entity_cre_flg == self.entity_cre_flg,
			NtfnConf.del_flg == self.del_flg)
			if notif_code != None:
				query = query.filter(NtfnConf.notif_code == notif_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_org_branch(self,session,br_id=None,return_type='J'):
		try:
			query = session.query(OrgBranch).filter(
			OrgBranch.org_id == self.org_id,
			OrgBranch.entity_cre_flg == self.entity_cre_flg,
			OrgBranch.del_flg == self.del_flg)
			if br_id != None:
				query = query.filter(OrgBranch.br_id == br_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_wkly_off Error :",str(e))
			return {'status' : "ERROR"}


	def get_org_dtls(self,session,=None,return_type='J'):
		try:
			query = session.query(OrgDtl).filter(
			OrgDtl.org_id == self.org_id,
			OrgDtl.entity_cre_flg == self.entity_cre_flg,
			OrgDtl.del_flg == self.del_flg)

			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_week_begins_on Error :",str(e))
			return {'status' : "ERROR"}


	def get_org_integ(self,session,org_integ_id=None,return_type='J'):
		try:
			query = session.query(OrgInteg).filter(
			OrgInteg.org_id == self.org_id,
			OrgInteg.entity_cre_flg == self.entity_cre_flg,
			OrgInteg.del_flg == self.del_flg)
			if org_integ_id != None:
				query = query.filter(OrgInteg.org_integ_id == org_integ_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_otp_dtls(self,session,otp_uniq_id=None,return_type='J'):
		try:
			query = session.query(OtpDtl).filter(
			OtpDtl.org_id == self.org_id,
			OtpDtl.entity_cre_flg == self.entity_cre_flg,
			OtpDtl.del_flg == self.del_flg)
			if otp_uniq_id != None:
				query = query.filter(OtpDtl.otp_uniq_id == otp_uniq_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_pass_hist(self,session,pw_hist_id=None,return_type='J'):
		try:
			query = session.query(PassHist).filter(
			PassHist.org_id == self.org_id,
			PassHist.entity_cre_flg == self.entity_cre_flg,
			PassHist.del_flg == self.del_flg)
			if pw_hist_id != None:
				query = query.filter(PassHist.pw_hist_id == pw_hist_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_pass_policy(self,session,policy_id=None,return_type='J'):
		try:
			query = session.query(PassPolicy).filter(
			PassPolicy.org_id == self.org_id,
			PassPolicy.entity_cre_flg == self.entity_cre_flg,
			PassPolicy.del_flg == self.del_flg)
			if policy_id != None:
				query = query.filter(PassPolicy.policy_id == policy_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_preferences(self,session,cust_id=None,pref_event_name=None,pref_type=None,rem_parent_cat_id=None,rem_sys_cat_id=None,return_type='J'):
		try:
			query = session.query(Preference).filter(
			Preference.org_id == self.org_id,
			Preference.entity_cre_flg == self.entity_cre_flg,
			Preference.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(Preference.cust_id == cust_id)
			if pref_event_name != None:
				query = query.filter(Preference.pref_event_name == pref_event_name)
			if pref_type != None:
				query = query.filter(Preference.pref_type == pref_type)
			if rem_parent_cat_id != None:
				query = query.filter(Preference.rem_parent_cat_id == rem_parent_cat_id)
			if rem_sys_cat_id != None:
				query = query.filter(Preference.rem_sys_cat_id == rem_sys_cat_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_preference_dtls(self,session,cust_id=None,pref_event_name=None,pref_type=None,remind_par_cat_id=None,sys_tran_cat_id=None,user_id=None,return_type='J'):
		try:
			query = session.query(PreferenceDtl).filter(
			PreferenceDtl.org_id == self.org_id,
			PreferenceDtl.entity_cre_flg == self.entity_cre_flg,
			PreferenceDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(PreferenceDtl.cust_id == cust_id)
			if pref_event_name != None:
				query = query.filter(PreferenceDtl.pref_event_name == pref_event_name)
			if pref_type != None:
				query = query.filter(PreferenceDtl.pref_type == pref_type)
			if remind_par_cat_id != None:
				query = query.filter(PreferenceDtl.remind_par_cat_id == remind_par_cat_id)
			if sys_tran_cat_id != None:
				query = query.filter(PreferenceDtl.sys_tran_cat_id == sys_tran_cat_id)
			if user_id != None:
				query = query.filter(PreferenceDtl.user_id == user_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_preproc_dtls(self,session,cust_id=None,preproc_as_on=None,return_type='J'):
		try:
			query = session.query(PreprocDtl).filter(
			PreprocDtl.org_id == self.org_id,
			PreprocDtl.entity_cre_flg == self.entity_cre_flg,
			PreprocDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(PreprocDtl.cust_id == cust_id)
			if preproc_as_on != None:
				query = query.filter(PreprocDtl.preproc_as_on == preproc_as_on)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_preproc_hist_dtls(self,session,cust_id=None,preproc_as_on=None,preproc_srl_num=None,return_type='J'):
		try:
			query = session.query(PreprocHistDtl).filter(
			PreprocHistDtl.org_id == self.org_id,
			PreprocHistDtl.entity_cre_flg == self.entity_cre_flg,
			PreprocHistDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(PreprocHistDtl.cust_id == cust_id)
			if preproc_as_on != None:
				query = query.filter(PreprocHistDtl.preproc_as_on == preproc_as_on)
			if preproc_srl_num != None:
				query = query.filter(PreprocHistDtl.preproc_srl_num == preproc_srl_num)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_prod_steps_config(self,session,prod_step_id=None,return_type='J'):
		try:
			query = session.query(ProdStepsConfig).filter(
			ProdStepsConfig.org_id == self.org_id,
			ProdStepsConfig.entity_cre_flg == self.entity_cre_flg,
			ProdStepsConfig.del_flg == self.del_flg)
			if prod_step_id != None:
				query = query.filter(ProdStepsConfig.prod_step_id == prod_step_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_product_addons(self,session,add_on_code=None,crncy_code=None,finserv_id=None,prod_code=None,return_type='J'):
		try:
			query = session.query(ProductAddon).filter(
			ProductAddon.org_id == self.org_id,
			ProductAddon.entity_cre_flg == self.entity_cre_flg,
			ProductAddon.del_flg == self.del_flg)
			if add_on_code != None:
				query = query.filter(ProductAddon.add_on_code == add_on_code)
			if crncy_code != None:
				query = query.filter(ProductAddon.crncy_code == crncy_code)
			if finserv_id != None:
				query = query.filter(ProductAddon.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(ProductAddon.prod_code == prod_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_product_doc_dtls(self,session,prod_doc_id=None,return_type='J'):
		try:
			query = session.query(ProductDocDtl).filter(
			ProductDocDtl.org_id == self.org_id,
			ProductDocDtl.entity_cre_flg == self.entity_cre_flg,
			ProductDocDtl.del_flg == self.del_flg)
			if prod_doc_id != None:
				query = query.filter(ProductDocDtl.prod_doc_id == prod_doc_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_product_dtls(self,session,crncy_code=None,finserv_id=None,prod_code=None,return_type='J'):
		try:
			query = session.query(ProductDtl).filter(
			ProductDtl.org_id == self.org_id,
			ProductDtl.entity_cre_flg == self.entity_cre_flg,
			ProductDtl.del_flg == self.del_flg)
			if crncy_code != None:
				query = query.filter(ProductDtl.crncy_code == crncy_code)
			if finserv_id != None:
				query = query.filter(ProductDtl.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(ProductDtl.prod_code == prod_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_withdrawal_basis_flg Error :",str(e))
			return {'status' : "ERROR"}


	def get_product_fees(self,session,fee_code=None,fee_crncy_code=None,finserv_id=None,prod_code=None,prod_crncy_code=None,prod_type=None,return_type='J'):
		try:
			query = session.query(ProductFee).filter(
			ProductFee.org_id == self.org_id,
			ProductFee.entity_cre_flg == self.entity_cre_flg,
			ProductFee.del_flg == self.del_flg)
			if fee_code != None:
				query = query.filter(ProductFee.fee_code == fee_code)
			if fee_crncy_code != None:
				query = query.filter(ProductFee.fee_crncy_code == fee_crncy_code)
			if finserv_id != None:
				query = query.filter(ProductFee.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(ProductFee.prod_code == prod_code)
			if prod_crncy_code != None:
				query = query.filter(ProductFee.prod_crncy_code == prod_crncy_code)
			if prod_type != None:
				query = query.filter(ProductFee.prod_type == prod_type)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_product_master(self,session,finserv_id=None,prod_code=None,return_type='J'):
		try:
			query = session.query(ProductMaster).filter(
			ProductMaster.org_id == self.org_id,
			ProductMaster.entity_cre_flg == self.entity_cre_flg,
			ProductMaster.del_flg == self.del_flg)
			if finserv_id != None:
				query = query.filter(ProductMaster.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(ProductMaster.prod_code == prod_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_users Error :",str(e))
			return {'status' : "ERROR"}


	def get_rec_dtls(self,session,cust_id=None,finserv_id=None,prod_code=None,return_type='J'):
		try:
			query = session.query(RecDtl).filter(
			RecDtl.org_id == self.org_id,
			RecDtl.entity_cre_flg == self.entity_cre_flg,
			RecDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(RecDtl.cust_id == cust_id)
			if finserv_id != None:
				query = query.filter(RecDtl.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(RecDtl.prod_code == prod_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_rec_hist_dtls(self,session,cust_id=None,finserv_id=None,prod_code=None,return_type='J'):
		try:
			query = session.query(RecHistDtl).filter(
			RecHistDtl.org_id == self.org_id,
			RecHistDtl.entity_cre_flg == self.entity_cre_flg,
			RecHistDtl.del_flg == self.del_flg)
			if cust_id != None:
				query = query.filter(RecHistDtl.cust_id == cust_id)
			if finserv_id != None:
				query = query.filter(RecHistDtl.finserv_id == finserv_id)
			if prod_code != None:
				query = query.filter(RecHistDtl.prod_code == prod_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_reg_tax_dtls(self,session,tax_code=None,tax_name=None,tax_type=None,return_type='J'):
		try:
			query = session.query(RegTaxDtl).filter(
			RegTaxDtl.org_id == self.org_id,
			RegTaxDtl.entity_cre_flg == self.entity_cre_flg,
			RegTaxDtl.del_flg == self.del_flg)
			if tax_code != None:
				query = query.filter(RegTaxDtl.tax_code == tax_code)
			if tax_name != None:
				query = query.filter(RegTaxDtl.tax_name == tax_name)
			if tax_type != None:
				query = query.filter(RegTaxDtl.tax_type == tax_type)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_action_access(self,session,action_id=None,return_type='J'):
		try:
			query = session.query(RoleActionAcces).filter(
			RoleActionAcces.org_id == self.org_id,
			RoleActionAcces.entity_cre_flg == self.entity_cre_flg,
			RoleActionAcces.del_flg == self.del_flg)
			if action_id != None:
				query = query.filter(RoleActionAcces.action_id == action_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_view_perm Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_crncy_dtls(self,session,crncy_code=None,role_code=None,return_type='J'):
		try:
			query = session.query(RoleCrncyDtl).filter(
			RoleCrncyDtl.org_id == self.org_id,
			RoleCrncyDtl.entity_cre_flg == self.entity_cre_flg,
			RoleCrncyDtl.del_flg == self.del_flg)
			if crncy_code != None:
				query = query.filter(RoleCrncyDtl.crncy_code == crncy_code)
			if role_code != None:
				query = query.filter(RoleCrncyDtl.role_code == role_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_xfer_dr_lim Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_dtls(self,session,role_id=None,return_type='J'):
		try:
			query = session.query(RoleDtl).filter(
			RoleDtl.org_id == self.org_id,
			RoleDtl.entity_cre_flg == self.entity_cre_flg,
			RoleDtl.del_flg == self.del_flg)
			if role_id != None:
				query = query.filter(RoleDtl.role_id == role_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_permission_dtls(self,session,perm_id=None,return_type='J'):
		try:
			query = session.query(RolePermissionDtl).filter(
			RolePermissionDtl.org_id == self.org_id,
			RolePermissionDtl.entity_cre_flg == self.entity_cre_flg,
			RolePermissionDtl.del_flg == self.del_flg)
			if perm_id != None:
				query = query.filter(RolePermissionDtl.perm_id == perm_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_verifier Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_prod_access(self,session,role_prod_id=None,return_type='J'):
		try:
			query = session.query(RoleProdAcces).filter(
			RoleProdAcces.org_id == self.org_id,
			RoleProdAcces.entity_cre_flg == self.entity_cre_flg,
			RoleProdAcces.del_flg == self.del_flg)
			if role_prod_id != None:
				query = query.filter(RoleProdAcces.role_prod_id == role_prod_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_role_workflow_access(self,session,role_wf_id=None,return_type='J'):
		try:
			query = session.query(RoleWorkflowAcces).filter(
			RoleWorkflowAcces.org_id == self.org_id,
			RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg,
			RoleWorkflowAcces.del_flg == self.del_flg)
			if role_wf_id != None:
				query = query.filter(RoleWorkflowAcces.role_wf_id == role_wf_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_rpt_perm(self,session,rpt_perm_id=None,return_type='J'):
		try:
			query = session.query(RptPerm).filter(
			RptPerm.org_id == self.org_id,
			RptPerm.entity_cre_flg == self.entity_cre_flg,
			RptPerm.del_flg == self.del_flg)
			if rpt_perm_id != None:
				query = query.filter(RptPerm.rpt_perm_id == rpt_perm_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_session_dtls(self,session,sess_uniq_id=None,return_type='J'):
		try:
			query = session.query(SessionDtl).filter(
			SessionDtl.org_id == self.org_id,
			SessionDtl.entity_cre_flg == self.entity_cre_flg,
			SessionDtl.del_flg == self.del_flg)
			if sess_uniq_id != None:
				query = query.filter(SessionDtl.sess_uniq_id == sess_uniq_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_view_access_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_silk_profile(self,session,id=None,return_type='J'):
		try:
			query = session.query(SilkProfile).filter(
			SilkProfile.org_id == self.org_id,
			SilkProfile.entity_cre_flg == self.entity_cre_flg,
			SilkProfile.del_flg == self.del_flg)
			if id != None:
				query = query.filter(SilkProfile.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_time_taken Error :",str(e))
			return {'status' : "ERROR"}


	def get_silk_profile_queries(self,session,id=None,return_type='J'):
		try:
			query = session.query(SilkProfileQuery).filter(
			SilkProfileQuery.org_id == self.org_id,
			SilkProfileQuery.entity_cre_flg == self.entity_cre_flg,
			SilkProfileQuery.del_flg == self.del_flg)
			if id != None:
				query = query.filter(SilkProfileQuery.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_sqlquery_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_silk_request(self,session,id=None,return_type='J'):
		try:
			query = session.query(SilkRequest).filter(
			SilkRequest.org_id == self.org_id,
			SilkRequest.entity_cre_flg == self.entity_cre_flg,
			SilkRequest.del_flg == self.del_flg)
			if id != None:
				query = query.filter(SilkRequest.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_view_name Error :",str(e))
			return {'status' : "ERROR"}


	def get_silk_response(self,session,id=None,return_type='J'):
		try:
			query = session.query(SilkResponse).filter(
			SilkResponse.org_id == self.org_id,
			SilkResponse.entity_cre_flg == self.entity_cre_flg,
			SilkResponse.del_flg == self.del_flg)
			if id != None:
				query = query.filter(SilkResponse.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_status_code Error :",str(e))
			return {'status' : "ERROR"}


	def get_silk_sqlquery(self,session,id=None,return_type='J'):
		try:
			query = session.query(SilkSqlquery).filter(
			SilkSqlquery.org_id == self.org_id,
			SilkSqlquery.entity_cre_flg == self.entity_cre_flg,
			SilkSqlquery.del_flg == self.del_flg)
			if id != None:
				query = query.filter(SilkSqlquery.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_traceback Error :",str(e))
			return {'status' : "ERROR"}


	def get_states(self,session,id=None,return_type='J'):
		try:
			query = session.query(State).filter(
			State.org_id == self.org_id,
			State.entity_cre_flg == self.entity_cre_flg,
			State.del_flg == self.del_flg)
			if id != None:
				query = query.filter(State.id == id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_wikiDataId Error :",str(e))
			return {'status' : "ERROR"}


	def get_sub_dtls(self,session,plan_id=None,return_type='J'):
		try:
			query = session.query(SubDtl).filter(
			SubDtl.org_id == self.org_id,
			SubDtl.entity_cre_flg == self.entity_cre_flg,
			SubDtl.del_flg == self.del_flg)
			if plan_id != None:
				query = query.filter(SubDtl.plan_id == plan_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_tax_dtls(self,session,fee_code=None,finserv_id=None,tax_code=None,return_type='J'):
		try:
			query = session.query(TaxDtl).filter(
			TaxDtl.org_id == self.org_id,
			TaxDtl.entity_cre_flg == self.entity_cre_flg,
			TaxDtl.del_flg == self.del_flg)
			if fee_code != None:
				query = query.filter(TaxDtl.fee_code == fee_code)
			if finserv_id != None:
				query = query.filter(TaxDtl.finserv_id == finserv_id)
			if tax_code != None:
				query = query.filter(TaxDtl.tax_code == tax_code)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_tbl_audit_dtl(self,session,log_id=None,return_type='J'):
		try:
			query = session.query(TblAuditDtl).filter(
			TblAuditDtl.org_id == self.org_id,
			TblAuditDtl.entity_cre_flg == self.entity_cre_flg,
			TblAuditDtl.del_flg == self.del_flg)
			if log_id != None:
				query = query.filter(TblAuditDtl.log_id == log_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_ts_cnt Error :",str(e))
			return {'status' : "ERROR"}


	def get_user_contact(self,session,contact_sub_type=None,contact_type=None,user_id=None,return_type='J'):
		try:
			query = session.query(UserContact).filter(
			UserContact.org_id == self.org_id,
			UserContact.entity_cre_flg == self.entity_cre_flg,
			UserContact.del_flg == self.del_flg)
			if contact_sub_type != None:
				query = query.filter(UserContact.contact_sub_type == contact_sub_type)
			if contact_type != None:
				query = query.filter(UserContact.contact_type == contact_type)
			if user_id != None:
				query = query.filter(UserContact.user_id == user_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_user_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_user_dtls(self,session,user_id=None,return_type='J'):
		try:
			query = session.query(UserDtl).filter(
			UserDtl.org_id == self.org_id,
			UserDtl.entity_cre_flg == self.entity_cre_flg,
			UserDtl.del_flg == self.del_flg)
			if user_id != None:
				query = query.filter(UserDtl.user_id == user_id)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_view_access_id Error :",str(e))
			return {'status' : "ERROR"}


	def get_yodlee_provider(self,session,providerAccountId=None,providerId=None,return_type='J'):
		try:
			query = session.query(YodleeProvider).filter(
			YodleeProvider.org_id == self.org_id,
			YodleeProvider.entity_cre_flg == self.entity_cre_flg,
			YodleeProvider.del_flg == self.del_flg)
			if providerAccountId != None:
				query = query.filter(YodleeProvider.providerAccountId == providerAccountId)
			if providerId != None:
				query = query.filter(YodleeProvider.providerId == providerId)
			query = query.all()
			if return_type == 'O':
				return query
			return SqlAlchemyModelEncoder(query,return_type)
		except Exception as e:
			print(" {*} get_yodlee_status Error :",str(e))
			return {'status' : "ERROR"}
