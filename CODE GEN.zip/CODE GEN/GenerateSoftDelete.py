import modelnew
from sqlalchemy.ext.declarative.api import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.sql.elements import TextClause

def get_func(classname,primary_keys_list):
    try:
        print("primary_keys_list -> ",primary_keys_list)
        if 'org_id' in primary_keys_list:
            primary_keys_list.remove('org_id')
        print("2 primary_keys_list -> ",primary_keys_list)
        pk = ""
        pk_len = len(primary_keys_list)-1
        for id,col in enumerate(primary_keys_list):
            if "org_id" != col:
                print("test ->",pk_len," > ",id)
                pk += "\t\t\t"
                pk += f"if {col}:\n\t\t\t\t"
                if pk_len > id:
                    pk += f"query = query.filter({classname}.{col}== {col})\n"
                else:
                    pk += f"query = query.filter({classname}.{col}== {col})"


        string = '''\n
    def delete_{classname}(self,session,user_id,{pkl}):
        try:
            query = session.query({classname}).filter_by(
                org_id=self.org_id,
                entity_cre_flg=self.entity_cre_flg,
                del_flg=self.del_flg)\n{pk}
            query = query.update(
                dict(lchg_user_id=user_id,lchg_time=datetime.now(),entity_cre_flg='N',del_flg='Y'))
            return True
        except Exception as e:
            print(" [*] get_{column} Error :",str(e))
            return ['status' : "ERROR"]\n'''.format(pk=pk,pkl=','.join(primary_keys_list),column=column,classname=classname).replace("[","{").replace("]","}")
        return string
    except Exception as e:
        print("hello ->",e)

class_output = ""
class_output += f"from modelnew import *\n\n"
class_output += f"class ClsRowSoftDelete:"
class_output += f"\n\tdef __init__(self,org_id):"
# class_output += f"\n\t\tpass"
class_output += f"\n\t\tself.org_id=org_id"
class_output += f"\n\t\tself.entity_cre_flg='Y'"
class_output += f"\n\t\tself.del_flg='N'"

for i in dir(modelnew):
    try:
        classname = getattr(modelnew, i)
        if type(classname)==DeclarativeMeta:
            
            # class_output +="\n"
            column_list = []
            primary_keys_list = []
            for column in dir(classname):
                col_name = getattr(classname, column)
                try:
                    if col_name.primary_key == True:
                        print("col_name.primary_key :",column,col_name.primary_key)
                        primary_keys_list.append(column)
                    # if col_name.nullable == True:
                    #     print("col_name.nullable :",column,col_name.nullable)
                    if col_name.server_default != None:
                        print("col_name.server_default :",column,col_name.server_default)
                except:
                    pass
                # print(type(column,getattr(classname, column)))
            outstring = get_func(classname.__table__,primary_keys_list)
            class_output += outstring
                    
    except:
        pass
f = open(f"DELETE/deleteRowdtls.py", "w")
f.write(class_output)
f.close()