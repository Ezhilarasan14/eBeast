from modelnew import *
class ClsUpRoleActionAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_accept(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_accept Error :",str(e))
            return {'status' : "ERROR"}


    def get_add_perm(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_add_perm Error :",str(e))
            return {'status' : "ERROR"}


    def get_allocate(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_allocate Error :",str(e))
            return {'status' : "ERROR"}


    def get_approve(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_approve Error :",str(e))
            return {'status' : "ERROR"}


    def get_capture(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_capture Error :",str(e))
            return {'status' : "ERROR"}


    def get_delete_perm(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_delete_perm Error :",str(e))
            return {'status' : "ERROR"}


    def get_download(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_download Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_name(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_modify_perm(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_modify_perm Error :",str(e))
            return {'status' : "ERROR"}


    def get_module(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_module Error :",str(e))
            return {'status' : "ERROR"}


    def get_recollect(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_recollect Error :",str(e))
            return {'status' : "ERROR"}


    def get_refer(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_refer Error :",str(e))
            return {'status' : "ERROR"}


    def get_reject(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reject Error :",str(e))
            return {'status' : "ERROR"}


    def get_revoke(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_revoke Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_upload(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_upload Error :",str(e))
            return {'status' : "ERROR"}


    def get_verify(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_verify Error :",str(e))
            return {'status' : "ERROR"}


    def get_view_perm(self,session,action_id):
        try:
            return session.query(RoleActionAcces).filter(
                RoleActionAcces.action_id== action_id,
                RoleActionAcces.org_id == self.org_id, 
                RoleActionAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleActionAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_view_perm Error :",str(e))
            return {'status' : "ERROR"}
