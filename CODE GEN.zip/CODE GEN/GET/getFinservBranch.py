from modelnew import *
class ClsUpFinservBranch:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_br_address1(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_address1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_address2(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_address2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_alias(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_alias Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_bod_date(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_cls_date(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_desc(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_desc_alt(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_name(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_nature(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_type(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_city_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_city_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_country_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_home_crncy_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_home_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_pin_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pin_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_state_code(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_zone(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def get_week_begins_on(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_week_begins_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_wkly_off(self,session,br_id,finserv_id):
        try:
            return session.query(FinservBranch).filter(
                FinservBranch.br_id== br_id,FinservBranch.finserv_id== finserv_id,
                FinservBranch.org_id == self.org_id, 
                FinservBranch.entity_cre_flg == self.entity_cre_flg, 
                FinservBranch.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_wkly_off Error :",str(e))
            return {'status' : "ERROR"}
