from modelnew import *
class ClsUpLeadsDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_alt_first_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_last_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_middle_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_annual_salary(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_annual_salary Error :",str(e))
            return {'status' : "ERROR"}


    def get_campaign_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_campaign_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_classification(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_classification Error :",str(e))
            return {'status' : "ERROR"}


    def get_company_category(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_company_category Error :",str(e))
            return {'status' : "ERROR"}


    def get_company_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_company_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_employment_status(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employment_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_expense(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expense Error :",str(e))
            return {'status' : "ERROR"}


    def get_first_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_gender(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gender Error :",str(e))
            return {'status' : "ERROR"}


    def get_income(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_income Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_lead_date(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_lead_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_lead_source(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_lead_source Error :",str(e))
            return {'status' : "ERROR"}


    def get_lead_to_cust(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_lead_to_cust Error :",str(e))
            return {'status' : "ERROR"}


    def get_lead_type(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_lead_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_marital_status(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_middle_name(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_nre_flg(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_nre_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_nre_since(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_nre_since Error :",str(e))
            return {'status' : "ERROR"}


    def get_num_of_child_dependants(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_num_of_child_dependants Error :",str(e))
            return {'status' : "ERROR"}


    def get_num_of_dependants(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_num_of_dependants Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferref_language(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferref_language Error :",str(e))
            return {'status' : "ERROR"}


    def get_primary_relationship_manager_id(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_primary_relationship_manager_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_interested(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_interested Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_proposed(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_proposed Error :",str(e))
            return {'status' : "ERROR"}


    def get_rating(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rating Error :",str(e))
            return {'status' : "ERROR"}


    def get_ratingdate(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ratingdate Error :",str(e))
            return {'status' : "ERROR"}


    def get_referred_by(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_referred_by Error :",str(e))
            return {'status' : "ERROR"}


    def get_salary_currency(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_salary_currency Error :",str(e))
            return {'status' : "ERROR"}


    def get_salutation(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_salutation Error :",str(e))
            return {'status' : "ERROR"}


    def get_secondary_relationship_manager_id(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_secondary_relationship_manager_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_segment(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_segment Error :",str(e))
            return {'status' : "ERROR"}


    def get_status(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_subsegment(self,session,lead_id):
        try:
            return session.query(LeadsDtl).filter(
                LeadsDtl.lead_id== lead_id,
                LeadsDtl.org_id == self.org_id, 
                LeadsDtl.entity_cre_flg == self.entity_cre_flg, 
                LeadsDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_subsegment Error :",str(e))
            return {'status' : "ERROR"}
