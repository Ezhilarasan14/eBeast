from modelnew import *
class ClsUpGeneralCode:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_alt_ref_desc(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_ref_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_level(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_nature(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_ref_code(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_ref_type(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_code(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_desc(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_type(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_type_desc(self,session,gen_id):
        try:
            return session.query(GeneralCode).filter(
                GeneralCode.gen_id== gen_id,
                GeneralCode.org_id == self.org_id, 
                GeneralCode.entity_cre_flg == self.entity_cre_flg, 
                GeneralCode.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_type_desc Error :",str(e))
            return {'status' : "ERROR"}
