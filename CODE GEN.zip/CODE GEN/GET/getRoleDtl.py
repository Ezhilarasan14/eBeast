from modelnew import *
class ClsUpRoleDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_do_ref_code(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_do_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_do_ref_type(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_do_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_hide_sensitive_data(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_hide_sensitive_data Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_customer_assistant(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_customer_assistant Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_super_admin(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_super_admin Error :",str(e))
            return {'status' : "ERROR"}


    def get_limit_amount(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_limit_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_limit_scope(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_limit_scope Error :",str(e))
            return {'status' : "ERROR"}


    def get_onb_agent(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_onb_agent Error :",str(e))
            return {'status' : "ERROR"}


    def get_override_err(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_override_err Error :",str(e))
            return {'status' : "ERROR"}


    def get_rest_data(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rest_data Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_desc(self,session,role_id):
        try:
            return session.query(RoleDtl).filter(
                RoleDtl.role_id== role_id,
                RoleDtl.org_id == self.org_id, 
                RoleDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_desc Error :",str(e))
            return {'status' : "ERROR"}
