from modelnew import *
class ClsUpNetworkDir:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_address_1(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_2(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_branch_info_1(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_branch_info_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_country_code(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_country_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_delta_matching_key(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_delta_matching_key Error :",str(e))
            return {'status' : "ERROR"}


    def get_institute_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_institute_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_institute_name_2(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_institute_name_2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_location_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_location_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_primary_rec_flg(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_primary_rec_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_primary_ref(self,session,file_source,file_type,ref_key,unq_bank_identifier):
        try:
            return session.query(NetworkDir).filter(
                NetworkDir.file_source== file_source,NetworkDir.file_type== file_type,NetworkDir.ref_key== ref_key,NetworkDir.unq_bank_identifier== unq_bank_identifier,
                NetworkDir.org_id == self.org_id, 
                NetworkDir.entity_cre_flg == self.entity_cre_flg, 
                NetworkDir.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_primary_ref Error :",str(e))
            return {'status' : "ERROR"}
