from modelnew import *
class ClsUpAuthMatrixConfig:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_Idle_measure_unit(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Idle_measure_unit Error :",str(e))
            return {'status' : "ERROR"}


    def get_Idle_measure_value(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Idle_measure_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_auth_level(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auth_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_auth_matrix_code(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_auth_nature(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auth_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_scope(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_scope Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_set_id(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_set_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,auth_matrix_id):
        try:
            return session.query(AuthMatrixConfig).filter(
                AuthMatrixConfig.auth_matrix_id== auth_matrix_id,
                AuthMatrixConfig.org_id == self.org_id, 
                AuthMatrixConfig.entity_cre_flg == self.entity_cre_flg, 
                AuthMatrixConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}
