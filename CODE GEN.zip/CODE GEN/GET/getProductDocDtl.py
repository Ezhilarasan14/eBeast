from modelnew import *
class ClsUpProductDocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_crncy_code(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_code(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_src(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_src Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_type(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_id(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_mandate(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mandate Error :",str(e))
            return {'status' : "ERROR"}


    def get_num_of_docs(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_num_of_docs Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_code(self,session,prod_doc_id):
        try:
            return session.query(ProductDocDtl).filter(
                ProductDocDtl.prod_doc_id== prod_doc_id,
                ProductDocDtl.org_id == self.org_id, 
                ProductDocDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_code Error :",str(e))
            return {'status' : "ERROR"}
