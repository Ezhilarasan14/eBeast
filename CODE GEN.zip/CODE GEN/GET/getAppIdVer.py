from modelnew import *
class ClsUpAppIdVer:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_applnt_status(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applnt_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_applnt_status_remarks(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applnt_status_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_capt_path(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_capt_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_dist(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_dist Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_score(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_score Error :",str(e))
            return {'status' : "ERROR"}


    def get_frame_rate(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_frame_rate Error :",str(e))
            return {'status' : "ERROR"}


    def get_img_status(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_img_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_det(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_det Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_gen(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_gen Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_status(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_ph_cap_path(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ph_cap_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_ph_doc_code(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ph_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_ph_doc_path(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ph_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_ph_vid_fig(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ph_vid_fig Error :",str(e))
            return {'status' : "ERROR"}


    def get_proc_path(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_proc_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_spoof_score(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_spoof_score Error :",str(e))
            return {'status' : "ERROR"}


    def get_spoof_status(self,session,id_ver_no):
        try:
            return session.query(AppIdVer).filter(
                AppIdVer.id_ver_no== id_ver_no,
                AppIdVer.org_id == self.org_id, 
                AppIdVer.entity_cre_flg == self.entity_cre_flg, 
                AppIdVer.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_spoof_status Error :",str(e))
            return {'status' : "ERROR"}
