from modelnew import *
class ClsUpCustContact:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_Plot_num(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Plot_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_format(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_format Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line1(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line2(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line3(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line3 Error :",str(e))
            return {'status' : "ERROR"}


    def get_building_num(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_building_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_city(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_city Error :",str(e))
            return {'status' : "ERROR"}


    def get_contact_sub_type(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_contact_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_contact_type(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_contact_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_country(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_domicle(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_domicle Error :",str(e))
            return {'status' : "ERROR"}


    def get_email(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_floor_no(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_floor_no Error :",str(e))
            return {'status' : "ERROR"}


    def get_locality(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_locality Error :",str(e))
            return {'status' : "ERROR"}


    def get_phone_no(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phone_no Error :",str(e))
            return {'status' : "ERROR"}


    def get_phoneno_countrycode(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phoneno_countrycode Error :",str(e))
            return {'status' : "ERROR"}


    def get_phoneno_localcode(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phoneno_localcode Error :",str(e))
            return {'status' : "ERROR"}


    def get_pin(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pin Error :",str(e))
            return {'status' : "ERROR"}


    def get_premise_name(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_premise_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_region(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_region Error :",str(e))
            return {'status' : "ERROR"}


    def get_state(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_street_name(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_street_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_street_no(self,session,cont_id):
        try:
            return session.query(CustContact).filter(
                CustContact.cont_id== cont_id,
                CustContact.org_id == self.org_id, 
                CustContact.entity_cre_flg == self.entity_cre_flg, 
                CustContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_street_no Error :",str(e))
            return {'status' : "ERROR"}
