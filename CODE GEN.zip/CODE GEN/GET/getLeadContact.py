from modelnew import *
class ClsUpLeadContact:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_Plot_num(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Plot_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_format(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_format Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line1(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line2(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line3(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line3 Error :",str(e))
            return {'status' : "ERROR"}


    def get_building_num(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_building_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_city(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_city Error :",str(e))
            return {'status' : "ERROR"}


    def get_country(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country Error :",str(e))
            return {'status' : "ERROR"}


    def get_domicle(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_domicle Error :",str(e))
            return {'status' : "ERROR"}


    def get_email(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_floor_no(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_floor_no Error :",str(e))
            return {'status' : "ERROR"}


    def get_locality(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_locality Error :",str(e))
            return {'status' : "ERROR"}


    def get_phone_no(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phone_no Error :",str(e))
            return {'status' : "ERROR"}


    def get_phoneno_countrycode(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phoneno_countrycode Error :",str(e))
            return {'status' : "ERROR"}


    def get_phoneno_localcode(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phoneno_localcode Error :",str(e))
            return {'status' : "ERROR"}


    def get_pin(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pin Error :",str(e))
            return {'status' : "ERROR"}


    def get_premise_name(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_premise_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_region(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_region Error :",str(e))
            return {'status' : "ERROR"}


    def get_state(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_street_name(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_street_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_street_no(self,session,contact_sub_type,contact_type,lead_id):
        try:
            return session.query(LeadContact).filter(
                LeadContact.contact_sub_type== contact_sub_type,LeadContact.contact_type== contact_type,LeadContact.lead_id== lead_id,
                LeadContact.org_id == self.org_id, 
                LeadContact.entity_cre_flg == self.entity_cre_flg, 
                LeadContact.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_street_no Error :",str(e))
            return {'status' : "ERROR"}
