from modelnew import *
class ClsUpCustCategory:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_entity_int_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_int_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_global_change(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_global_change Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_level(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_name(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_type(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_head(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_head Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_parent_cat_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cat_level(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cat_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cat_name(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cat_type(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_head(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_head Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_parent_cat_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id):
        try:
            return session.query(CustCategory).filter(
                CustCategory.cust_id== cust_id,CustCategory.sys_cat_id== sys_cat_id,CustCategory.tran_date== tran_date,CustCategory.tran_id== tran_id,CustCategory.user_cat_id== user_cat_id,
                CustCategory.org_id == self.org_id, 
                CustCategory.entity_cre_flg == self.entity_cre_flg, 
                CustCategory.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}
