from modelnew import *
class ClsUpSilkProfileQuery:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_profile(self,session,id):
        try:
            return session.query(SilkProfileQuery).filter(
                SilkProfileQuery.id== id,
                SilkProfileQuery.org_id == self.org_id, 
                SilkProfileQuery.entity_cre_flg == self.entity_cre_flg, 
                SilkProfileQuery.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_profile Error :",str(e))
            return {'status' : "ERROR"}


    def get_profile_id(self,session,id):
        try:
            return session.query(SilkProfileQuery).filter(
                SilkProfileQuery.id== id,
                SilkProfileQuery.org_id == self.org_id, 
                SilkProfileQuery.entity_cre_flg == self.entity_cre_flg, 
                SilkProfileQuery.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_profile_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sqlquery(self,session,id):
        try:
            return session.query(SilkProfileQuery).filter(
                SilkProfileQuery.id== id,
                SilkProfileQuery.org_id == self.org_id, 
                SilkProfileQuery.entity_cre_flg == self.entity_cre_flg, 
                SilkProfileQuery.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sqlquery Error :",str(e))
            return {'status' : "ERROR"}


    def get_sqlquery_id(self,session,id):
        try:
            return session.query(SilkProfileQuery).filter(
                SilkProfileQuery.id== id,
                SilkProfileQuery.org_id == self.org_id, 
                SilkProfileQuery.entity_cre_flg == self.entity_cre_flg, 
                SilkProfileQuery.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sqlquery_id Error :",str(e))
            return {'status' : "ERROR"}
