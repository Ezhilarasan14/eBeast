from modelnew import *
class ClsUpRptPerm:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_role_code(self,session,rpt_perm_id):
        try:
            return session.query(RptPerm).filter(
                RptPerm.rpt_perm_id== rpt_perm_id,
                RptPerm.org_id == self.org_id, 
                RptPerm.entity_cre_flg == self.entity_cre_flg, 
                RptPerm.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_rpt_cat(self,session,rpt_perm_id):
        try:
            return session.query(RptPerm).filter(
                RptPerm.rpt_perm_id== rpt_perm_id,
                RptPerm.org_id == self.org_id, 
                RptPerm.entity_cre_flg == self.entity_cre_flg, 
                RptPerm.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rpt_cat Error :",str(e))
            return {'status' : "ERROR"}


    def get_rpt_code(self,session,rpt_perm_id):
        try:
            return session.query(RptPerm).filter(
                RptPerm.rpt_perm_id== rpt_perm_id,
                RptPerm.org_id == self.org_id, 
                RptPerm.entity_cre_flg == self.entity_cre_flg, 
                RptPerm.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rpt_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_rpt_dwnld(self,session,rpt_perm_id):
        try:
            return session.query(RptPerm).filter(
                RptPerm.rpt_perm_id== rpt_perm_id,
                RptPerm.org_id == self.org_id, 
                RptPerm.entity_cre_flg == self.entity_cre_flg, 
                RptPerm.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rpt_dwnld Error :",str(e))
            return {'status' : "ERROR"}


    def get_rpt_view(self,session,rpt_perm_id):
        try:
            return session.query(RptPerm).filter(
                RptPerm.rpt_perm_id== rpt_perm_id,
                RptPerm.org_id == self.org_id, 
                RptPerm.entity_cre_flg == self.entity_cre_flg, 
                RptPerm.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rpt_view Error :",str(e))
            return {'status' : "ERROR"}
