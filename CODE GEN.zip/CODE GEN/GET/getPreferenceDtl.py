from modelnew import *
class ClsUpPreferenceDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_pref_event_value(self,session,cust_id,pref_event_name,pref_type,remind_par_cat_id,sys_tran_cat_id,user_id):
        try:
            return session.query(PreferenceDtl).filter(
                PreferenceDtl.cust_id== cust_id,PreferenceDtl.pref_event_name== pref_event_name,PreferenceDtl.pref_type== pref_type,PreferenceDtl.remind_par_cat_id== remind_par_cat_id,PreferenceDtl.sys_tran_cat_id== sys_tran_cat_id,PreferenceDtl.user_id== user_id,
                PreferenceDtl.org_id == self.org_id, 
                PreferenceDtl.entity_cre_flg == self.entity_cre_flg, 
                PreferenceDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pref_event_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_remind_bf_days(self,session,cust_id,pref_event_name,pref_type,remind_par_cat_id,sys_tran_cat_id,user_id):
        try:
            return session.query(PreferenceDtl).filter(
                PreferenceDtl.cust_id== cust_id,PreferenceDtl.pref_event_name== pref_event_name,PreferenceDtl.pref_type== pref_type,PreferenceDtl.remind_par_cat_id== remind_par_cat_id,PreferenceDtl.sys_tran_cat_id== sys_tran_cat_id,PreferenceDtl.user_id== user_id,
                PreferenceDtl.org_id == self.org_id, 
                PreferenceDtl.entity_cre_flg == self.entity_cre_flg, 
                PreferenceDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remind_bf_days Error :",str(e))
            return {'status' : "ERROR"}
