from modelnew import *
class ClsUpCalendarDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_End_time(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_End_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_Start_time(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_id(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_set(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_set Error :",str(e))
            return {'status' : "ERROR"}


    def get_call_duration(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_call_duration Error :",str(e))
            return {'status' : "ERROR"}


    def get_holiday(self,session,mmyyyy):
        try:
            return session.query(CalendarDtl).filter(
                CalendarDtl.mmyyyy== mmyyyy,
                CalendarDtl.org_id == self.org_id, 
                CalendarDtl.entity_cre_flg == self.entity_cre_flg, 
                CalendarDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_holiday Error :",str(e))
            return {'status' : "ERROR"}
