from modelnew import *
class ClsUpCustBankDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_acct_number(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_acct_number Error :",str(e))
            return {'status' : "ERROR"}


    def get_bank_code(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_bank_name(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_branch_code(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_iban_number(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iban_number Error :",str(e))
            return {'status' : "ERROR"}


    def get_image_path(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_payment_integration(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_payment_integration Error :",str(e))
            return {'status' : "ERROR"}


    def get_sector(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sector Error :",str(e))
            return {'status' : "ERROR"}


    def get_swift_code(self,session,cust_id):
        try:
            return session.query(CustBankDtl).filter(
                CustBankDtl.cust_id== cust_id,
                CustBankDtl.org_id == self.org_id, 
                CustBankDtl.entity_cre_flg == self.entity_cre_flg, 
                CustBankDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_swift_code Error :",str(e))
            return {'status' : "ERROR"}
