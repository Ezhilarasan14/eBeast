from modelnew import *
class ClsUpRolePermissionDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_checker(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_checker Error :",str(e))
            return {'status' : "ERROR"}


    def get_modifier(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_modifier Error :",str(e))
            return {'status' : "ERROR"}


    def get_module(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_module Error :",str(e))
            return {'status' : "ERROR"}


    def get_reader(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reader Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_verifier(self,session,perm_id):
        try:
            return session.query(RolePermissionDtl).filter(
                RolePermissionDtl.perm_id== perm_id,
                RolePermissionDtl.org_id == self.org_id, 
                RolePermissionDtl.entity_cre_flg == self.entity_cre_flg, 
                RolePermissionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_verifier Error :",str(e))
            return {'status' : "ERROR"}
