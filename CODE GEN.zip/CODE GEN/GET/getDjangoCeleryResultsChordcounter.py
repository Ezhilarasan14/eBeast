from modelnew import *
class ClsUpDjangoCeleryResultsChordcounter:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_count(self,session,id):
        try:
            return session.query(DjangoCeleryResultsChordcounter).filter(
                DjangoCeleryResultsChordcounter.id== id,
                DjangoCeleryResultsChordcounter.org_id == self.org_id, 
                DjangoCeleryResultsChordcounter.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsChordcounter.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_count Error :",str(e))
            return {'status' : "ERROR"}


    def get_group_id(self,session,id):
        try:
            return session.query(DjangoCeleryResultsChordcounter).filter(
                DjangoCeleryResultsChordcounter.id== id,
                DjangoCeleryResultsChordcounter.org_id == self.org_id, 
                DjangoCeleryResultsChordcounter.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsChordcounter.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sub_tasks(self,session,id):
        try:
            return session.query(DjangoCeleryResultsChordcounter).filter(
                DjangoCeleryResultsChordcounter.id== id,
                DjangoCeleryResultsChordcounter.org_id == self.org_id, 
                DjangoCeleryResultsChordcounter.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsChordcounter.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sub_tasks Error :",str(e))
            return {'status' : "ERROR"}
