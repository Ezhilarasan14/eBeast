from modelnew import *
class ClsUpAppOtherField:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_id(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_type(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_value(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_form_id(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_form_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_type(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_section_id(self,session,id):
        try:
            return session.query(AppOtherField).filter(
                AppOtherField.id== id,
                AppOtherField.org_id == self.org_id, 
                AppOtherField.entity_cre_flg == self.entity_cre_flg, 
                AppOtherField.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_section_id Error :",str(e))
            return {'status' : "ERROR"}
