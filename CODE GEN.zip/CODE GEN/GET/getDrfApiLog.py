from modelnew import *
class ClsUpDrfApiLog:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_added_on(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_added_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_api(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api Error :",str(e))
            return {'status' : "ERROR"}


    def get_body(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_body Error :",str(e))
            return {'status' : "ERROR"}


    def get_client_ip_address(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_client_ip_address Error :",str(e))
            return {'status' : "ERROR"}


    def get_execution_time(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_execution_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_headers(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_headers Error :",str(e))
            return {'status' : "ERROR"}


    def get_method(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_method Error :",str(e))
            return {'status' : "ERROR"}


    def get_response(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_response Error :",str(e))
            return {'status' : "ERROR"}


    def get_status_code(self,session,id):
        try:
            return session.query(DrfApiLog).filter(
                DrfApiLog.id== id,
                DrfApiLog.org_id == self.org_id, 
                DrfApiLog.entity_cre_flg == self.entity_cre_flg, 
                DrfApiLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status_code Error :",str(e))
            return {'status' : "ERROR"}
