from modelnew import *
class ClsUpDjangoCeleryResultsTaskresult:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_content_encoding(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_encoding Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_date_created(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_date_created Error :",str(e))
            return {'status' : "ERROR"}


    def get_date_done(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_date_done Error :",str(e))
            return {'status' : "ERROR"}


    def get_meta(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_meta Error :",str(e))
            return {'status' : "ERROR"}


    def get_periodic_task_name(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_periodic_task_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_result(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_result Error :",str(e))
            return {'status' : "ERROR"}


    def get_status(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_task_args(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_task_args Error :",str(e))
            return {'status' : "ERROR"}


    def get_task_id(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_task_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_task_kwargs(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_task_kwargs Error :",str(e))
            return {'status' : "ERROR"}


    def get_task_name(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_task_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_traceback(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_traceback Error :",str(e))
            return {'status' : "ERROR"}


    def get_worker(self,session,id):
        try:
            return session.query(DjangoCeleryResultsTaskresult).filter(
                DjangoCeleryResultsTaskresult.id== id,
                DjangoCeleryResultsTaskresult.org_id == self.org_id, 
                DjangoCeleryResultsTaskresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsTaskresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_worker Error :",str(e))
            return {'status' : "ERROR"}
