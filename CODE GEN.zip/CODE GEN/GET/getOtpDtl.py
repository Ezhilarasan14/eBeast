from modelnew import *
class ClsUpOtpDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_device_id(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_device_token(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_token Error :",str(e))
            return {'status' : "ERROR"}


    def get_device_type(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_logged_on_mode(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_logged_on_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_bod_date(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_cls_date(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_cre_time(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_cre_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_type(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_valid_till(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_value(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_todays_date(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_todays_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,otp_uniq_id):
        try:
            return session.query(OtpDtl).filter(
                OtpDtl.otp_uniq_id== otp_uniq_id,
                OtpDtl.org_id == self.org_id, 
                OtpDtl.entity_cre_flg == self.entity_cre_flg, 
                OtpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
