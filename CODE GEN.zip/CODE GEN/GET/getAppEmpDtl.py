from modelnew import *
class ClsUpAppEmpDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_address(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_address Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_city(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_city Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_country(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_country Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_name(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_pin(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_pin Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_state(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_employer_type(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employer_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_from_yr(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_from_yr Error :",str(e))
            return {'status' : "ERROR"}


    def get_gross_salary(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gross_salary Error :",str(e))
            return {'status' : "ERROR"}


    def get_image_path(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_role(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role Error :",str(e))
            return {'status' : "ERROR"}


    def get_salary_currency(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_salary_currency Error :",str(e))
            return {'status' : "ERROR"}


    def get_sector(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sector Error :",str(e))
            return {'status' : "ERROR"}


    def get_to_yr(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_to_yr Error :",str(e))
            return {'status' : "ERROR"}


    def get_years_of_exp(self,session,employer_id):
        try:
            return session.query(AppEmpDtl).filter(
                AppEmpDtl.employer_id== employer_id,
                AppEmpDtl.org_id == self.org_id, 
                AppEmpDtl.entity_cre_flg == self.entity_cre_flg, 
                AppEmpDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_years_of_exp Error :",str(e))
            return {'status' : "ERROR"}
