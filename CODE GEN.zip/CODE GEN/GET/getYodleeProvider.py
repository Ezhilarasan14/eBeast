from modelnew import *
class ClsUpYodleeProvider:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_aggregationSource(self,session,providerAccountId,providerId):
        try:
            return session.query(YodleeProvider).filter(
                YodleeProvider.providerAccountId== providerAccountId,YodleeProvider.providerId== providerId,
                YodleeProvider.org_id == self.org_id, 
                YodleeProvider.entity_cre_flg == self.entity_cre_flg, 
                YodleeProvider.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_aggregationSource Error :",str(e))
            return {'status' : "ERROR"}


    def get_requestId(self,session,providerAccountId,providerId):
        try:
            return session.query(YodleeProvider).filter(
                YodleeProvider.providerAccountId== providerAccountId,YodleeProvider.providerId== providerId,
                YodleeProvider.org_id == self.org_id, 
                YodleeProvider.entity_cre_flg == self.entity_cre_flg, 
                YodleeProvider.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_requestId Error :",str(e))
            return {'status' : "ERROR"}


    def get_yodlee_status(self,session,providerAccountId,providerId):
        try:
            return session.query(YodleeProvider).filter(
                YodleeProvider.providerAccountId== providerAccountId,YodleeProvider.providerId== providerId,
                YodleeProvider.org_id == self.org_id, 
                YodleeProvider.entity_cre_flg == self.entity_cre_flg, 
                YodleeProvider.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}
