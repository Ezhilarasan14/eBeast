from modelnew import *
class ClsUpCountryDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_cntry_code_alpha3(self,session,cntry_code,crncy_code):
        try:
            return session.query(CountryDtl).filter(
                CountryDtl.cntry_code== cntry_code,CountryDtl.crncy_code== crncy_code,
                CountryDtl.org_id == self.org_id, 
                CountryDtl.entity_cre_flg == self.entity_cre_flg, 
                CountryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cntry_code_alpha3 Error :",str(e))
            return {'status' : "ERROR"}


    def get_cntry_name(self,session,cntry_code,crncy_code):
        try:
            return session.query(CountryDtl).filter(
                CountryDtl.cntry_code== cntry_code,CountryDtl.crncy_code== crncy_code,
                CountryDtl.org_id == self.org_id, 
                CountryDtl.entity_cre_flg == self.entity_cre_flg, 
                CountryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cntry_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_iso_cntry_num(self,session,cntry_code,crncy_code):
        try:
            return session.query(CountryDtl).filter(
                CountryDtl.cntry_code== cntry_code,CountryDtl.crncy_code== crncy_code,
                CountryDtl.org_id == self.org_id, 
                CountryDtl.entity_cre_flg == self.entity_cre_flg, 
                CountryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iso_cntry_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_status(self,session,cntry_code,crncy_code):
        try:
            return session.query(CountryDtl).filter(
                CountryDtl.cntry_code== cntry_code,CountryDtl.crncy_code== crncy_code,
                CountryDtl.org_id == self.org_id, 
                CountryDtl.entity_cre_flg == self.entity_cre_flg, 
                CountryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status Error :",str(e))
            return {'status' : "ERROR"}
