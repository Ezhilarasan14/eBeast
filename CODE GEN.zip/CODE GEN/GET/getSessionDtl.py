from modelnew import *
class ClsUpSessionDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_back_fore_flg(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_fore_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_calling_prog_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_calling_prog_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_device_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_device_token(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_token Error :",str(e))
            return {'status' : "ERROR"}


    def get_device_type(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_device_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_exe_name(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_exe_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_home_crncy(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_home_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def get_logged_on_mode(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_logged_on_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_module_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_module_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_node_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_node_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_node_name(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_node_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_node_type(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_node_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_bod_date(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_cls_date(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_session_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_session_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferred_language(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def get_proc_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_proc_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_session_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_session_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_session_time_zone(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_session_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_access_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_valid_till(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def get_todays_date(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_todays_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_view_access_id(self,session,sess_uniq_id):
        try:
            return session.query(SessionDtl).filter(
                SessionDtl.sess_uniq_id== sess_uniq_id,
                SessionDtl.org_id == self.org_id, 
                SessionDtl.entity_cre_flg == self.entity_cre_flg, 
                SessionDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
