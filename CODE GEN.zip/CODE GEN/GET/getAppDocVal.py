from modelnew import *
class ClsUpAppDocVal:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_app(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_id(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_code(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_id(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_type(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_val(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_val Error :",str(e))
            return {'status' : "ERROR"}


    def get_missing(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_missing Error :",str(e))
            return {'status' : "ERROR"}


    def get_remarks(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_side(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_side Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_status(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_status(self,session,doc_val_id):
        try:
            return session.query(AppDocVal).filter(
                AppDocVal.doc_val_id== doc_val_id,
                AppDocVal.org_id == self.org_id, 
                AppDocVal.entity_cre_flg == self.entity_cre_flg, 
                AppDocVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}
