from modelnew import *
class ClsUpAuthPermission:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_codename(self,session,id):
        try:
            return session.query(AuthPermission).filter(
                AuthPermission.id== id,
                AuthPermission.org_id == self.org_id, 
                AuthPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_codename Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(AuthPermission).filter(
                AuthPermission.id== id,
                AuthPermission.org_id == self.org_id, 
                AuthPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type_id(self,session,id):
        try:
            return session.query(AuthPermission).filter(
                AuthPermission.id== id,
                AuthPermission.org_id == self.org_id, 
                AuthPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_name(self,session,id):
        try:
            return session.query(AuthPermission).filter(
                AuthPermission.id== id,
                AuthPermission.org_id == self.org_id, 
                AuthPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}
