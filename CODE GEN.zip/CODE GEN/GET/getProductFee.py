from modelnew import *
class ClsUpProductFee:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_apply_tax(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_apply_tax Error :",str(e))
            return {'status' : "ERROR"}


    def get_fee_amount(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fee_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_fee_amt_ind(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fee_amt_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_fee_desc(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fee_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_fee_desc_alt(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fee_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def get_fee_pcnt(self,session,fee_code,fee_crncy_code,finserv_id,prod_code,prod_crncy_code,prod_type):
        try:
            return session.query(ProductFee).filter(
                ProductFee.fee_code== fee_code,ProductFee.fee_crncy_code== fee_crncy_code,ProductFee.finserv_id== finserv_id,ProductFee.prod_code== prod_code,ProductFee.prod_crncy_code== prod_crncy_code,ProductFee.prod_type== prod_type,
                ProductFee.org_id == self.org_id, 
                ProductFee.entity_cre_flg == self.entity_cre_flg, 
                ProductFee.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fee_pcnt Error :",str(e))
            return {'status' : "ERROR"}
