from modelnew import *
class ClsUpAuthGroup:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_name(self,session,id):
        try:
            return session.query(AuthGroup).filter(
                AuthGroup.id== id,
                AuthGroup.org_id == self.org_id, 
                AuthGroup.entity_cre_flg == self.entity_cre_flg, 
                AuthGroup.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}
