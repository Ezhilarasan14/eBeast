from modelnew import *
class ClsUpDjangoCeleryResultsGroupresult:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_content_encoding(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_encoding Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_date_created(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_date_created Error :",str(e))
            return {'status' : "ERROR"}


    def get_date_done(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_date_done Error :",str(e))
            return {'status' : "ERROR"}


    def get_group_id(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_result(self,session,id):
        try:
            return session.query(DjangoCeleryResultsGroupresult).filter(
                DjangoCeleryResultsGroupresult.id== id,
                DjangoCeleryResultsGroupresult.org_id == self.org_id, 
                DjangoCeleryResultsGroupresult.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryResultsGroupresult.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_result Error :",str(e))
            return {'status' : "ERROR"}
