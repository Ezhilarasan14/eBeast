from modelnew import *
class ClsUpCategoryDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_cat_cust_type(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cat_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_cat_name(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_cat_owner(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cat_owner Error :",str(e))
            return {'status' : "ERROR"}


    def get_cat_type(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_category_color(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_category_color Error :",str(e))
            return {'status' : "ERROR"}


    def get_category_img(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_category_img Error :",str(e))
            return {'status' : "ERROR"}


    def get_coa_head(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coa_head Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_level(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_cat_id(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_recurring(self,session,cat_id):
        try:
            return session.query(CategoryDtl).filter(
                CategoryDtl.cat_id== cat_id,
                CategoryDtl.org_id == self.org_id, 
                CategoryDtl.entity_cre_flg == self.entity_cre_flg, 
                CategoryDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_recurring Error :",str(e))
            return {'status' : "ERROR"}
