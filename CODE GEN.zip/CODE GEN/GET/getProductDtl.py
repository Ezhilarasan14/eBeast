from modelnew import *
class ClsUpProductDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_acct_cls_form_name(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_acct_cls_form_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_acct_opn_form_name(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_acct_opn_form_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_adult_age(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_adult_age Error :",str(e))
            return {'status' : "ERROR"}


    def get_allowed_genders(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_allowed_genders Error :",str(e))
            return {'status' : "ERROR"}


    def get_allowed_int_freq(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_allowed_int_freq Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_prod_name(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_auto_renewal_allowed(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auto_renewal_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def get_chq_allowed_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_chq_allowed_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_dr_bal_lim(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dr_bal_lim Error :",str(e))
            return {'status' : "ERROR"}


    def get_grace_days(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_grace_days Error :",str(e))
            return {'status' : "ERROR"}


    def get_installment_amt(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_installment_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_installment_coll_mthd(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_installment_coll_mthd Error :",str(e))
            return {'status' : "ERROR"}


    def get_installment_type(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_installment_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_int_on_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_int_on_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_interest_rate(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_interest_rate Error :",str(e))
            return {'status' : "ERROR"}


    def get_maturity_date(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_maturity_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_cust_age(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_cust_age Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_num_of_withdrawal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_num_of_withdrawal Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_perd_days(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_perd_days Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_perd_mnths(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_perd_mnths Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_sanctioned_limit(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_sanctioned_limit Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_slab_amt(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_slab_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_cust_age(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_cust_age Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_perd_days(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_perd_days Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_perd_mnths(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_perd_mnths Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_slab_amt(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_slab_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_minimum_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_minimum_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_minimum_bal_basis(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_minimum_bal_basis Error :",str(e))
            return {'status' : "ERROR"}


    def get_nre_only_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_nre_only_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_part_closure_allowed(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_part_closure_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def get_pre_closure_allowed(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pre_closure_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_allowed_cust(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_allowed_cust Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_name(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_nature(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_sub_type(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_type(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_img(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_img Error :",str(e))
            return {'status' : "ERROR"}


    def get_response(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_response Error :",str(e))
            return {'status' : "ERROR"}


    def get_sec_unsec_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sec_unsec_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_set_id(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_set_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_staff_only_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_staff_only_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_alwd_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_alwd_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_in_max_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_in_max_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_in_min_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_in_min_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_out_max_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_out_max_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_out_min_bal(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_out_min_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_withdrawal_basis_flg(self,session,crncy_code,finserv_id,prod_code):
        try:
            return session.query(ProductDtl).filter(
                ProductDtl.crncy_code== crncy_code,ProductDtl.finserv_id== finserv_id,ProductDtl.prod_code== prod_code,
                ProductDtl.org_id == self.org_id, 
                ProductDtl.entity_cre_flg == self.entity_cre_flg, 
                ProductDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_withdrawal_basis_flg Error :",str(e))
            return {'status' : "ERROR"}
