from modelnew import *
class ClsUpDjangoSession:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_expire_date(self,session,session_key):
        try:
            return session.query(DjangoSession).filter(
                DjangoSession.session_key== session_key,
                DjangoSession.org_id == self.org_id, 
                DjangoSession.entity_cre_flg == self.entity_cre_flg, 
                DjangoSession.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expire_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_session_data(self,session,session_key):
        try:
            return session.query(DjangoSession).filter(
                DjangoSession.session_key== session_key,
                DjangoSession.org_id == self.org_id, 
                DjangoSession.entity_cre_flg == self.entity_cre_flg, 
                DjangoSession.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_session_data Error :",str(e))
            return {'status' : "ERROR"}
