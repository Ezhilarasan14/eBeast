from modelnew import *
class ClsUpAppDataComp:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_values(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_values Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_name(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_status(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_remarks(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_status(self,session,comp_id):
        try:
            return session.query(AppDataComp).filter(
                AppDataComp.comp_id== comp_id,
                AppDataComp.org_id == self.org_id, 
                AppDataComp.entity_cre_flg == self.entity_cre_flg, 
                AppDataComp.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}
