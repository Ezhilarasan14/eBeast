from modelnew import *
class ClsUpAppDataVal:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_app(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_id(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_data_field(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_data_field Error :",str(e))
            return {'status' : "ERROR"}


    def get_data_val(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_data_val Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_code(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_id(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_type(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_duplicated(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_duplicated Error :",str(e))
            return {'status' : "ERROR"}


    def get_expired(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expired Error :",str(e))
            return {'status' : "ERROR"}


    def get_minor(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_minor Error :",str(e))
            return {'status' : "ERROR"}


    def get_missing(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_missing Error :",str(e))
            return {'status' : "ERROR"}


    def get_remarks(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_status(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_status(self,session,data_val_id):
        try:
            return session.query(AppDataVal).filter(
                AppDataVal.data_val_id== data_val_id,
                AppDataVal.org_id == self.org_id, 
                AppDataVal.entity_cre_flg == self.entity_cre_flg, 
                AppDataVal.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}
