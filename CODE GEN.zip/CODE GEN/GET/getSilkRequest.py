from modelnew import *
class ClsUpSilkRequest:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_body(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_body Error :",str(e))
            return {'status' : "ERROR"}


    def get_encoded_headers(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_encoded_headers Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_time(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_meta_num_queries(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_meta_num_queries Error :",str(e))
            return {'status' : "ERROR"}


    def get_meta_time(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_meta_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_meta_time_spent_queries(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_meta_time_spent_queries Error :",str(e))
            return {'status' : "ERROR"}


    def get_method(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_method Error :",str(e))
            return {'status' : "ERROR"}


    def get_num_sql_queries(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_num_sql_queries Error :",str(e))
            return {'status' : "ERROR"}


    def get_path(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_prof_file(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prof_file Error :",str(e))
            return {'status' : "ERROR"}


    def get_pyprofile(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pyprofile Error :",str(e))
            return {'status' : "ERROR"}


    def get_query_params(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_query_params Error :",str(e))
            return {'status' : "ERROR"}


    def get_raw_body(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_raw_body Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_time(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_taken(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_taken Error :",str(e))
            return {'status' : "ERROR"}


    def get_view_name(self,session,id):
        try:
            return session.query(SilkRequest).filter(
                SilkRequest.id== id,
                SilkRequest.org_id == self.org_id, 
                SilkRequest.entity_cre_flg == self.entity_cre_flg, 
                SilkRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_view_name Error :",str(e))
            return {'status' : "ERROR"}
