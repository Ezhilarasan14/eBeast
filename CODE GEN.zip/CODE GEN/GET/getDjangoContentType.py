from modelnew import *
class ClsUpDjangoContentType:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_app_label(self,session,id):
        try:
            return session.query(DjangoContentType).filter(
                DjangoContentType.id== id,
                DjangoContentType.org_id == self.org_id, 
                DjangoContentType.entity_cre_flg == self.entity_cre_flg, 
                DjangoContentType.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_label Error :",str(e))
            return {'status' : "ERROR"}


    def get_model(self,session,id):
        try:
            return session.query(DjangoContentType).filter(
                DjangoContentType.id== id,
                DjangoContentType.org_id == self.org_id, 
                DjangoContentType.entity_cre_flg == self.entity_cre_flg, 
                DjangoContentType.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_model Error :",str(e))
            return {'status' : "ERROR"}
