from modelnew import *
class ClsUpRoleCrncyDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_cash_dr_lim(self,session,crncy_code,role_code):
        try:
            return session.query(RoleCrncyDtl).filter(
                RoleCrncyDtl.crncy_code== crncy_code,RoleCrncyDtl.role_code== role_code,
                RoleCrncyDtl.org_id == self.org_id, 
                RoleCrncyDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleCrncyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cash_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def get_clg_dr_lim(self,session,crncy_code,role_code):
        try:
            return session.query(RoleCrncyDtl).filter(
                RoleCrncyDtl.crncy_code== crncy_code,RoleCrncyDtl.role_code== role_code,
                RoleCrncyDtl.org_id == self.org_id, 
                RoleCrncyDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleCrncyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_clg_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def get_xfer_dr_lim(self,session,crncy_code,role_code):
        try:
            return session.query(RoleCrncyDtl).filter(
                RoleCrncyDtl.crncy_code== crncy_code,RoleCrncyDtl.role_code== role_code,
                RoleCrncyDtl.org_id == self.org_id, 
                RoleCrncyDtl.entity_cre_flg == self.entity_cre_flg, 
                RoleCrncyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_xfer_dr_lim Error :",str(e))
            return {'status' : "ERROR"}
