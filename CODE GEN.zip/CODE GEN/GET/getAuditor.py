from modelnew import *
class ClsUpAuditor:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_action(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_action Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_object(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_object Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type_id(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_field(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field Error :",str(e))
            return {'status' : "ERROR"}


    def get_new_value(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_new_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_id(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_old_value(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_old_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_stamp(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_stamp Error :",str(e))
            return {'status' : "ERROR"}


    def get_user(self,session,id):
        try:
            return session.query(Auditor).filter(
                Auditor.id== id,
                Auditor.org_id == self.org_id, 
                Auditor.entity_cre_flg == self.entity_cre_flg, 
                Auditor.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}
