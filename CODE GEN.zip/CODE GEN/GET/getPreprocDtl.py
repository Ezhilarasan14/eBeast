from modelnew import *
class ClsUpPreprocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_age_range(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_age_range Error :",str(e))
            return {'status' : "ERROR"}


    def get_annual_sal_crncy(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_annual_sal_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def get_annual_salary_range(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_annual_salary_range Error :",str(e))
            return {'status' : "ERROR"}


    def get_blacklist_flg(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_blacklist_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_type(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_employment_status(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employment_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_fin_quality(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_fin_quality Error :",str(e))
            return {'status' : "ERROR"}


    def get_gender(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gender Error :",str(e))
            return {'status' : "ERROR"}


    def get_marital_status(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_minor_flg(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_minor_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_region(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_region Error :",str(e))
            return {'status' : "ERROR"}


    def get_resident_flg(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_resident_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_segment(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_segment Error :",str(e))
            return {'status' : "ERROR"}


    def get_staff_flg(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_staff_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_state(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_suspend_flg(self,session,cust_id,preproc_as_on):
        try:
            return session.query(PreprocDtl).filter(
                PreprocDtl.cust_id== cust_id,PreprocDtl.preproc_as_on== preproc_as_on,
                PreprocDtl.org_id == self.org_id, 
                PreprocDtl.entity_cre_flg == self.entity_cre_flg, 
                PreprocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_suspend_flg Error :",str(e))
            return {'status' : "ERROR"}
