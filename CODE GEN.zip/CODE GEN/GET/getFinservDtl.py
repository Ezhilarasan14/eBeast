from modelnew import *
class ClsUpFinservDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_cntry_code(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cntry_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_name(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_type(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_image_path(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_ocr_enabled(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ocr_enabled Error :",str(e))
            return {'status' : "ERROR"}


    def get_pymt_intgn(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pymt_intgn Error :",str(e))
            return {'status' : "ERROR"}


    def get_sector(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sector Error :",str(e))
            return {'status' : "ERROR"}


    def get_swift_code(self,session,finserv_id):
        try:
            return session.query(FinservDtl).filter(
                FinservDtl.finserv_id== finserv_id,
                FinservDtl.org_id == self.org_id, 
                FinservDtl.entity_cre_flg == self.entity_cre_flg, 
                FinservDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_swift_code Error :",str(e))
            return {'status' : "ERROR"}
