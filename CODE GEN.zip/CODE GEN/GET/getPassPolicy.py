from modelnew import *
class ClsUpPassPolicy:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_invalid_pw_atmpts(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_invalid_pw_atmpts Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_pw_len(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_pw_len Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_dgt_cnt(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_dgt_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_pw_len(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_pw_len Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_splchar_cnt(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_splchar_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_min_uprcaseltr_cnt(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_min_uprcaseltr_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_pw_validity_days(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pw_validity_days Error :",str(e))
            return {'status' : "ERROR"}


    def get_reset_freq(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reset_freq Error :",str(e))
            return {'status' : "ERROR"}


    def get_reset_freq_duration(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reset_freq_duration Error :",str(e))
            return {'status' : "ERROR"}


    def get_reuse_hist_cnt(self,session,policy_id):
        try:
            return session.query(PassPolicy).filter(
                PassPolicy.policy_id== policy_id,
                PassPolicy.org_id == self.org_id, 
                PassPolicy.entity_cre_flg == self.entity_cre_flg, 
                PassPolicy.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reuse_hist_cnt Error :",str(e))
            return {'status' : "ERROR"}
