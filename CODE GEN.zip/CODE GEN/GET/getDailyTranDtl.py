from modelnew import *
class ClsUpDailyTranDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_Orig_bank_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Orig_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_Orig_branch_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Orig_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_Orig_ifsc_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_Orig_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_bank_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_bank_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_ben_acct_num(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ben_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_ben_bank_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ben_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_ben_branch_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ben_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_ben_ifsc_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ben_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_int_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_int_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_instr_num(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_instr_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_instr_type(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_instr_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_merchant_cat_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_merchant_cat_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_sys_cat_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_user_cat_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_user_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_part_tran_srl_num(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_part_tran_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_part_tran_type(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_part_tran_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_pstd_flg(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pstd_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_rate(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rate Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_amt(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_ref_crncy_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ref_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_si_exec_date(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_si_exec_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_si_num(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_si_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_name(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_amt(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_crncy_code(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_date(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_particular_1(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_particular_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_particular_2(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_particular_2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_rmks_1(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_rmks_1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_rmks_2(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_rmks_2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_sub_type(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_tran_type(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tran_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cat_id(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cat_name(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_value_date(self,session,int_tran_id):
        try:
            return session.query(DailyTranDtl).filter(
                DailyTranDtl.int_tran_id== int_tran_id,
                DailyTranDtl.org_id == self.org_id, 
                DailyTranDtl.entity_cre_flg == self.entity_cre_flg, 
                DailyTranDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_value_date Error :",str(e))
            return {'status' : "ERROR"}
