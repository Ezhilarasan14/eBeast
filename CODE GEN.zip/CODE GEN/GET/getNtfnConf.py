from modelnew import *
class ClsUpNtfnConf:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_email(self,session,notif_code):
        try:
            return session.query(NtfnConf).filter(
                NtfnConf.notif_code== notif_code,
                NtfnConf.org_id == self.org_id, 
                NtfnConf.entity_cre_flg == self.entity_cre_flg, 
                NtfnConf.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_mobile(self,session,notif_code):
        try:
            return session.query(NtfnConf).filter(
                NtfnConf.notif_code== notif_code,
                NtfnConf.org_id == self.org_id, 
                NtfnConf.entity_cre_flg == self.entity_cre_flg, 
                NtfnConf.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mobile Error :",str(e))
            return {'status' : "ERROR"}


    def get_notif_desc(self,session,notif_code):
        try:
            return session.query(NtfnConf).filter(
                NtfnConf.notif_code== notif_code,
                NtfnConf.org_id == self.org_id, 
                NtfnConf.entity_cre_flg == self.entity_cre_flg, 
                NtfnConf.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_notif_desc Error :",str(e))
            return {'status' : "ERROR"}
