from modelnew import *
class ClsUpDjangoAdminLog:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_action_flag(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_action_flag Error :",str(e))
            return {'status' : "ERROR"}


    def get_action_time(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_action_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_change_message(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_change_message Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type_id(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_id(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_repr(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_repr Error :",str(e))
            return {'status' : "ERROR"}


    def get_user(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,id):
        try:
            return session.query(DjangoAdminLog).filter(
                DjangoAdminLog.id== id,
                DjangoAdminLog.org_id == self.org_id, 
                DjangoAdminLog.entity_cre_flg == self.entity_cre_flg, 
                DjangoAdminLog.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
