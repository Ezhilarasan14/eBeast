from modelnew import *
class ClsUpOrgInteg:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_api_key(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_key Error :",str(e))
            return {'status' : "ERROR"}


    def get_api_user(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_crncy_code(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_dep_on(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dep_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_int_type(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_int_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_integ_name(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_integ_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_integ_type(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_integ_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_integ_url(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_integ_url Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_after_before(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_after_before Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_api_revokable(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_api_revokable Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_from(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_from Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_code(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_name(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_action(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_action Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_event(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_event Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_seq(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_seq Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_step(self,session,org_integ_id):
        try:
            return session.query(OrgInteg).filter(
                OrgInteg.org_integ_id== org_integ_id,
                OrgInteg.org_id == self.org_id, 
                OrgInteg.entity_cre_flg == self.entity_cre_flg, 
                OrgInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_step Error :",str(e))
            return {'status' : "ERROR"}
