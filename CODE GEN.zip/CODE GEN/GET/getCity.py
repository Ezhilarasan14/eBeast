from modelnew import *
class ClsUpCity:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_country(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country Error :",str(e))
            return {'status' : "ERROR"}


    def get_country_code(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_country_id(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_created_at(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_created_at Error :",str(e))
            return {'status' : "ERROR"}


    def get_flag(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_flag Error :",str(e))
            return {'status' : "ERROR"}


    def get_latitude(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_longitude(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_name(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_state(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_state_code(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_state_id(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_updated_at(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_updated_at Error :",str(e))
            return {'status' : "ERROR"}


    def get_wikiDataId(self,session,id):
        try:
            return session.query(City).filter(
                City.id== id,
                City.org_id == self.org_id, 
                City.entity_cre_flg == self.entity_cre_flg, 
                City.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}
