from modelnew import *
class ClsUpAppointmentDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_agent_person_id(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_agent_person_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_comments(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_comments Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_date(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_day(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_day Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_owner(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_owner Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_status(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_appointment_type(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_appointment_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_time(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_time(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_target_person_id(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_target_person_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_target_person_type(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_target_person_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_zone(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def get_topic(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_topic Error :",str(e))
            return {'status' : "ERROR"}


    def get_venue(self,session,appointment_id):
        try:
            return session.query(AppointmentDtl).filter(
                AppointmentDtl.appointment_id== appointment_id,
                AppointmentDtl.org_id == self.org_id, 
                AppointmentDtl.entity_cre_flg == self.entity_cre_flg, 
                AppointmentDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_venue Error :",str(e))
            return {'status' : "ERROR"}
