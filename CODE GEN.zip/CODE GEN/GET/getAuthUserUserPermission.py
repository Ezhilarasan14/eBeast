from modelnew import *
class ClsUpAuthUserUserPermission:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_permission(self,session,id):
        try:
            return session.query(AuthUserUserPermission).filter(
                AuthUserUserPermission.id== id,
                AuthUserUserPermission.org_id == self.org_id, 
                AuthUserUserPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthUserUserPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_permission Error :",str(e))
            return {'status' : "ERROR"}


    def get_permission_id(self,session,id):
        try:
            return session.query(AuthUserUserPermission).filter(
                AuthUserUserPermission.id== id,
                AuthUserUserPermission.org_id == self.org_id, 
                AuthUserUserPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthUserUserPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_permission_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user(self,session,id):
        try:
            return session.query(AuthUserUserPermission).filter(
                AuthUserUserPermission.id== id,
                AuthUserUserPermission.org_id == self.org_id, 
                AuthUserUserPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthUserUserPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,id):
        try:
            return session.query(AuthUserUserPermission).filter(
                AuthUserUserPermission.id== id,
                AuthUserUserPermission.org_id == self.org_id, 
                AuthUserUserPermission.entity_cre_flg == self.entity_cre_flg, 
                AuthUserUserPermission.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
