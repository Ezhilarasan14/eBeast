from modelnew import *
class ClsUpRecHistDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_crncy_code(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_limit(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_limit Error :",str(e))
            return {'status' : "ERROR"}


    def get_owned_products(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_owned_products Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_nature(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_sub_type(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_type(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_reco_action_status(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reco_action_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_reco_as_on(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reco_as_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_reco_reject_reason(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reco_reject_reason Error :",str(e))
            return {'status' : "ERROR"}


    def get_reco_srl_num(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reco_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_score(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_score Error :",str(e))
            return {'status' : "ERROR"}


    def get_steer_coeff(self,session,cust_id,finserv_id,prod_code):
        try:
            return session.query(RecHistDtl).filter(
                RecHistDtl.cust_id== cust_id,RecHistDtl.finserv_id== finserv_id,RecHistDtl.prod_code== prod_code,
                RecHistDtl.org_id == self.org_id, 
                RecHistDtl.entity_cre_flg == self.entity_cre_flg, 
                RecHistDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_steer_coeff Error :",str(e))
            return {'status' : "ERROR"}
