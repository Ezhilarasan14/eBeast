from modelnew import *
class ClsUpPassHist:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_curr_flag(self,session,pw_hist_id):
        try:
            return session.query(PassHist).filter(
                PassHist.pw_hist_id== pw_hist_id,
                PassHist.org_id == self.org_id, 
                PassHist.entity_cre_flg == self.entity_cre_flg, 
                PassHist.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_curr_flag Error :",str(e))
            return {'status' : "ERROR"}


    def get_password(self,session,pw_hist_id):
        try:
            return session.query(PassHist).filter(
                PassHist.pw_hist_id== pw_hist_id,
                PassHist.org_id == self.org_id, 
                PassHist.entity_cre_flg == self.entity_cre_flg, 
                PassHist.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_password Error :",str(e))
            return {'status' : "ERROR"}


    def get_pw_cre_date(self,session,pw_hist_id):
        try:
            return session.query(PassHist).filter(
                PassHist.pw_hist_id== pw_hist_id,
                PassHist.org_id == self.org_id, 
                PassHist.entity_cre_flg == self.entity_cre_flg, 
                PassHist.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pw_cre_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_pw_expiry_date(self,session,pw_hist_id):
        try:
            return session.query(PassHist).filter(
                PassHist.pw_hist_id== pw_hist_id,
                PassHist.org_id == self.org_id, 
                PassHist.entity_cre_flg == self.entity_cre_flg, 
                PassHist.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pw_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,pw_hist_id):
        try:
            return session.query(PassHist).filter(
                PassHist.pw_hist_id== pw_hist_id,
                PassHist.org_id == self.org_id, 
                PassHist.entity_cre_flg == self.entity_cre_flg, 
                PassHist.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
