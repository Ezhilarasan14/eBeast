from modelnew import *
class ClsUpMailAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_api_name(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_receiver_id(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_receiver_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_req_code(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_req_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_req_orig(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_req_orig Error :",str(e))
            return {'status' : "ERROR"}


    def get_req_type(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_req_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_resp_type(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_resp_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,req_id):
        try:
            return session.query(MailAuditDtl).filter(
                MailAuditDtl.req_id== req_id,
                MailAuditDtl.org_id == self.org_id, 
                MailAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                MailAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
