from modelnew import *
class ClsUpDjangoMigration:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_app(self,session,id):
        try:
            return session.query(DjangoMigration).filter(
                DjangoMigration.id== id,
                DjangoMigration.org_id == self.org_id, 
                DjangoMigration.entity_cre_flg == self.entity_cre_flg, 
                DjangoMigration.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied(self,session,id):
        try:
            return session.query(DjangoMigration).filter(
                DjangoMigration.id== id,
                DjangoMigration.org_id == self.org_id, 
                DjangoMigration.entity_cre_flg == self.entity_cre_flg, 
                DjangoMigration.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied Error :",str(e))
            return {'status' : "ERROR"}


    def get_name(self,session,id):
        try:
            return session.query(DjangoMigration).filter(
                DjangoMigration.id== id,
                DjangoMigration.org_id == self.org_id, 
                DjangoMigration.entity_cre_flg == self.entity_cre_flg, 
                DjangoMigration.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}
