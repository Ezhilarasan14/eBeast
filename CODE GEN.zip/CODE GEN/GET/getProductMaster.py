from modelnew import *
class ClsUpProductMaster:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_all_global_applnt(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_all_global_applnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_prod_name(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_cat(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_cat Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_fill_form(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_fill_form Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_frm(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_frm Error :",str(e))
            return {'status' : "ERROR"}


    def get_auto_approve(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auto_approve Error :",str(e))
            return {'status' : "ERROR"}


    def get_capture_doc(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_capture_doc Error :",str(e))
            return {'status' : "ERROR"}


    def get_collect_doc(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_collect_doc Error :",str(e))
            return {'status' : "ERROR"}


    def get_enable_otp(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_enable_otp Error :",str(e))
            return {'status' : "ERROR"}


    def get_enable_spoof(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_enable_spoof Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_match(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_match Error :",str(e))
            return {'status' : "ERROR"}


    def get_form_auto_fill(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_form_auto_fill Error :",str(e))
            return {'status' : "ERROR"}


    def get_kyc(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_kyc Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_ad_content(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_ad_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_alt_ad_content(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_alt_ad_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_name(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_nature(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_status(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_sub_type(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_type(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_img(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_img Error :",str(e))
            return {'status' : "ERROR"}


    def get_response(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_response Error :",str(e))
            return {'status' : "ERROR"}


    def get_sign_mode(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sign_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_skip_steps(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_skip_steps Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_order(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_order Error :",str(e))
            return {'status' : "ERROR"}


    def get_users(self,session,finserv_id,prod_code):
        try:
            return session.query(ProductMaster).filter(
                ProductMaster.finserv_id== finserv_id,ProductMaster.prod_code== prod_code,
                ProductMaster.org_id == self.org_id, 
                ProductMaster.entity_cre_flg == self.entity_cre_flg, 
                ProductMaster.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_users Error :",str(e))
            return {'status' : "ERROR"}
