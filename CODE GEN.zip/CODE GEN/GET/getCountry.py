from modelnew import *
class ClsUpCountry:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_capital(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_capital Error :",str(e))
            return {'status' : "ERROR"}


    def get_created_at(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_created_at Error :",str(e))
            return {'status' : "ERROR"}


    def get_currency(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_currency Error :",str(e))
            return {'status' : "ERROR"}


    def get_currency_name(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_currency_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_currency_symbol(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_currency_symbol Error :",str(e))
            return {'status' : "ERROR"}


    def get_emoji(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_emoji Error :",str(e))
            return {'status' : "ERROR"}


    def get_emojiU(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_emojiU Error :",str(e))
            return {'status' : "ERROR"}


    def get_flag(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_flag Error :",str(e))
            return {'status' : "ERROR"}


    def get_iso2(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iso2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_iso3(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iso3 Error :",str(e))
            return {'status' : "ERROR"}


    def get_latitude(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_longitude(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_name(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_native(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_native Error :",str(e))
            return {'status' : "ERROR"}


    def get_numeric_code(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_numeric_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_phonecode(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_phonecode Error :",str(e))
            return {'status' : "ERROR"}


    def get_region(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_region Error :",str(e))
            return {'status' : "ERROR"}


    def get_subregion(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_subregion Error :",str(e))
            return {'status' : "ERROR"}


    def get_timezones(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_timezones Error :",str(e))
            return {'status' : "ERROR"}


    def get_tld(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tld Error :",str(e))
            return {'status' : "ERROR"}


    def get_translations(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_translations Error :",str(e))
            return {'status' : "ERROR"}


    def get_updated_at(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_updated_at Error :",str(e))
            return {'status' : "ERROR"}


    def get_wikiDataId(self,session,id):
        try:
            return session.query(Country).filter(
                Country.id== id,
                Country.org_id == self.org_id, 
                Country.entity_cre_flg == self.entity_cre_flg, 
                Country.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}
