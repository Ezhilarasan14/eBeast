from modelnew import *
class ClsUpDjangoCeleryPendingList:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_expires(self,session,cache_key):
        try:
            return session.query(DjangoCeleryPendingList).filter(
                DjangoCeleryPendingList.cache_key== cache_key,
                DjangoCeleryPendingList.org_id == self.org_id, 
                DjangoCeleryPendingList.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryPendingList.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expires Error :",str(e))
            return {'status' : "ERROR"}


    def get_value(self,session,cache_key):
        try:
            return session.query(DjangoCeleryPendingList).filter(
                DjangoCeleryPendingList.cache_key== cache_key,
                DjangoCeleryPendingList.org_id == self.org_id, 
                DjangoCeleryPendingList.entity_cre_flg == self.entity_cre_flg, 
                DjangoCeleryPendingList.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_value Error :",str(e))
            return {'status' : "ERROR"}
