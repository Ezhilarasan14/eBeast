from modelnew import *
class ClsUpPreference:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_pref_event_value(self,session,cust_id,pref_event_name,pref_type,rem_parent_cat_id,rem_sys_cat_id):
        try:
            return session.query(Preference).filter(
                Preference.cust_id== cust_id,Preference.pref_event_name== pref_event_name,Preference.pref_type== pref_type,Preference.rem_parent_cat_id== rem_parent_cat_id,Preference.rem_sys_cat_id== rem_sys_cat_id,
                Preference.org_id == self.org_id, 
                Preference.entity_cre_flg == self.entity_cre_flg, 
                Preference.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pref_event_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_remind_bf_days(self,session,cust_id,pref_event_name,pref_type,rem_parent_cat_id,rem_sys_cat_id):
        try:
            return session.query(Preference).filter(
                Preference.cust_id== cust_id,Preference.pref_event_name== pref_event_name,Preference.pref_type== pref_type,Preference.rem_parent_cat_id== rem_parent_cat_id,Preference.rem_sys_cat_id== rem_sys_cat_id,
                Preference.org_id == self.org_id, 
                Preference.entity_cre_flg == self.entity_cre_flg, 
                Preference.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remind_bf_days Error :",str(e))
            return {'status' : "ERROR"}
