from modelnew import *
class ClsUpSubDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_details(self,session,plan_id):
        try:
            return session.query(SubDtl).filter(
                SubDtl.plan_id== plan_id,
                SubDtl.org_id == self.org_id, 
                SubDtl.entity_cre_flg == self.entity_cre_flg, 
                SubDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_details Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_date(self,session,plan_id):
        try:
            return session.query(SubDtl).filter(
                SubDtl.plan_id== plan_id,
                SubDtl.org_id == self.org_id, 
                SubDtl.entity_cre_flg == self.entity_cre_flg, 
                SubDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_plan_name(self,session,plan_id):
        try:
            return session.query(SubDtl).filter(
                SubDtl.plan_id== plan_id,
                SubDtl.org_id == self.org_id, 
                SubDtl.entity_cre_flg == self.entity_cre_flg, 
                SubDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_plan_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_date(self,session,plan_id):
        try:
            return session.query(SubDtl).filter(
                SubDtl.plan_id== plan_id,
                SubDtl.org_id == self.org_id, 
                SubDtl.entity_cre_flg == self.entity_cre_flg, 
                SubDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_status(self,session,plan_id):
        try:
            return session.query(SubDtl).filter(
                SubDtl.plan_id== plan_id,
                SubDtl.org_id == self.org_id, 
                SubDtl.entity_cre_flg == self.entity_cre_flg, 
                SubDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status Error :",str(e))
            return {'status' : "ERROR"}
