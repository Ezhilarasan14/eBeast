from modelnew import *
class ClsUpCallRequest:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_agent_id(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_agent_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_application_id(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_call_status(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_call_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_consent(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_consent Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_time(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_from_time(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_from_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_pref_lang(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pref_lang Error :",str(e))
            return {'status' : "ERROR"}


    def get_rsn_code(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rsn_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_rsn_type(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rsn_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_sched_on(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sched_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_sched_type(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sched_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_time(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_zone(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def get_to_time(self,session,req_id):
        try:
            return session.query(CallRequest).filter(
                CallRequest.req_id== req_id,
                CallRequest.org_id == self.org_id, 
                CallRequest.entity_cre_flg == self.entity_cre_flg, 
                CallRequest.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_to_time Error :",str(e))
            return {'status' : "ERROR"}
