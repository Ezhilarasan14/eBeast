from modelnew import *
class ClsUpProdStepsConfig:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_auth_matrix_code(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_id(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_mandatory(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def get_matrix_id(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_matrix_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_code(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_crncy_code(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_nature(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_sub_type(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_type(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_code(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_name(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_num(self,session,prod_step_id):
        try:
            return session.query(ProdStepsConfig).filter(
                ProdStepsConfig.prod_step_id== prod_step_id,
                ProdStepsConfig.org_id == self.org_id, 
                ProdStepsConfig.entity_cre_flg == self.entity_cre_flg, 
                ProdStepsConfig.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_num Error :",str(e))
            return {'status' : "ERROR"}
