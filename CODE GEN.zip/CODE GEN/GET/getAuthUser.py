from modelnew import *
class ClsUpAuthUser:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_date_joined(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_date_joined Error :",str(e))
            return {'status' : "ERROR"}


    def get_email(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_first_name(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_active(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_active Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_staff(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_staff Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_superuser(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_superuser Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_login(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_login Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_name(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_password(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_password Error :",str(e))
            return {'status' : "ERROR"}


    def get_username(self,session,id):
        try:
            return session.query(AuthUser).filter(
                AuthUser.id== id,
                AuthUser.org_id == self.org_id, 
                AuthUser.entity_cre_flg == self.entity_cre_flg, 
                AuthUser.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_username Error :",str(e))
            return {'status' : "ERROR"}
