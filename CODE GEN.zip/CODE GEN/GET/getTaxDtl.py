from modelnew import *
class ClsUpTaxDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_tax_amount(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_amt_ind(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_amt_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_crncy_code(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_desc(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_desc_alt(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_pcnt(self,session,fee_code,finserv_id,tax_code):
        try:
            return session.query(TaxDtl).filter(
                TaxDtl.fee_code== fee_code,TaxDtl.finserv_id== finserv_id,TaxDtl.tax_code== tax_code,
                TaxDtl.org_id == self.org_id, 
                TaxDtl.entity_cre_flg == self.entity_cre_flg, 
                TaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_pcnt Error :",str(e))
            return {'status' : "ERROR"}
