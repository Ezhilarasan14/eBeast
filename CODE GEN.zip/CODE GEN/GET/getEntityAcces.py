from modelnew import *
class ClsUpEntityAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_access_id(self,session,entity_int_id,finserv_id):
        try:
            return session.query(EntityAcces).filter(
                EntityAcces.entity_int_id== entity_int_id,EntityAcces.finserv_id== finserv_id,
                EntityAcces.org_id == self.org_id, 
                EntityAcces.entity_cre_flg == self.entity_cre_flg, 
                EntityAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,entity_int_id,finserv_id):
        try:
            return session.query(EntityAcces).filter(
                EntityAcces.entity_int_id== entity_int_id,EntityAcces.finserv_id== finserv_id,
                EntityAcces.org_id == self.org_id, 
                EntityAcces.entity_cre_flg == self.entity_cre_flg, 
                EntityAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,entity_int_id,finserv_id):
        try:
            return session.query(EntityAcces).filter(
                EntityAcces.entity_int_id== entity_int_id,EntityAcces.finserv_id== finserv_id,
                EntityAcces.org_id == self.org_id, 
                EntityAcces.entity_cre_flg == self.entity_cre_flg, 
                EntityAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
