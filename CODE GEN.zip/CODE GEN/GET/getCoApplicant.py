from modelnew import *
class ClsUpCoApplicant:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_app_status(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_applicant_type(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applicant_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_application_id(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cam_org_img(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cam_org_img Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_signature(self,session,co_applicant_id):
        try:
            return session.query(CoApplicant).filter(
                CoApplicant.co_applicant_id== co_applicant_id,
                CoApplicant.org_id == self.org_id, 
                CoApplicant.entity_cre_flg == self.entity_cre_flg, 
                CoApplicant.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_signature Error :",str(e))
            return {'status' : "ERROR"}
