from modelnew import *
class ClsUpAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_api_name(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_calling_url(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_calling_url Error :",str(e))
            return {'status' : "ERROR"}


    def get_reason(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reason Error :",str(e))
            return {'status' : "ERROR"}


    def get_req_orig(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_req_orig Error :",str(e))
            return {'status' : "ERROR"}


    def get_request(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request Error :",str(e))
            return {'status' : "ERROR"}


    def get_resp_type(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_resp_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_response(self,session,req_id):
        try:
            return session.query(AuditDtl).filter(
                AuditDtl.req_id== req_id,
                AuditDtl.org_id == self.org_id, 
                AuditDtl.entity_cre_flg == self.entity_cre_flg, 
                AuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_response Error :",str(e))
            return {'status' : "ERROR"}
