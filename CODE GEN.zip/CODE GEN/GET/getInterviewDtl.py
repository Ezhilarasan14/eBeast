from modelnew import *
class ClsUpInterviewDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_ans_status(self,session,application_id,call_id,ques_no):
        try:
            return session.query(InterviewDtl).filter(
                InterviewDtl.application_id== application_id,InterviewDtl.call_id== call_id,InterviewDtl.ques_no== ques_no,
                InterviewDtl.org_id == self.org_id, 
                InterviewDtl.entity_cre_flg == self.entity_cre_flg, 
                InterviewDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ans_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_answer(self,session,application_id,call_id,ques_no):
        try:
            return session.query(InterviewDtl).filter(
                InterviewDtl.application_id== application_id,InterviewDtl.call_id== call_id,InterviewDtl.ques_no== ques_no,
                InterviewDtl.org_id == self.org_id, 
                InterviewDtl.entity_cre_flg == self.entity_cre_flg, 
                InterviewDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_answer Error :",str(e))
            return {'status' : "ERROR"}


    def get_question(self,session,application_id,call_id,ques_no):
        try:
            return session.query(InterviewDtl).filter(
                InterviewDtl.application_id== application_id,InterviewDtl.call_id== call_id,InterviewDtl.ques_no== ques_no,
                InterviewDtl.org_id == self.org_id, 
                InterviewDtl.entity_cre_flg == self.entity_cre_flg, 
                InterviewDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_question Error :",str(e))
            return {'status' : "ERROR"}


    def get_remarks(self,session,application_id,call_id,ques_no):
        try:
            return session.query(InterviewDtl).filter(
                InterviewDtl.application_id== application_id,InterviewDtl.call_id== call_id,InterviewDtl.ques_no== ques_no,
                InterviewDtl.org_id == self.org_id, 
                InterviewDtl.entity_cre_flg == self.entity_cre_flg, 
                InterviewDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remarks Error :",str(e))
            return {'status' : "ERROR"}
