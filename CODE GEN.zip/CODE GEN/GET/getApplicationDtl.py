from modelnew import *
class ClsUpApplicationDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_add_ons_opted(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_add_ons_opted Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_mode(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_owner(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_owner Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_owner_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_owner_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_owner_role(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_owner_role Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_status(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_step_nxt_name(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_step_nxt_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_step_nxt_num(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_step_nxt_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied_by(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied_by Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied_for_user_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied_for_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied_for_user_nature(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied_for_user_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied_for_user_type(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied_for_user_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_applied_on(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applied_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_applying_prod_code(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applying_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_applying_prod_nature(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applying_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_applying_prod_sub_type(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applying_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_applying_prod_type(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applying_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_applying_user_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_applying_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cam_org_img(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cam_org_img Error :",str(e))
            return {'status' : "ERROR"}


    def get_captured_video(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_captured_video Error :",str(e))
            return {'status' : "ERROR"}


    def get_crncy_code(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_deposit_amount(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_deposit_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_emi_amount(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_emi_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_status(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_match_distance(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_match_distance Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_match_score(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_match_score Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_installment_freq(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_installment_freq Error :",str(e))
            return {'status' : "ERROR"}


    def get_int_rate(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_int_rate Error :",str(e))
            return {'status' : "ERROR"}


    def get_loan_amount(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_loan_amount Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_det(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_det Error :",str(e))
            return {'status' : "ERROR"}


    def get_otp_gen(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_otp_gen Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_application_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_pdf_path(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pdf_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_processed_video(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_processed_video Error :",str(e))
            return {'status' : "ERROR"}


    def get_request_id(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sign_remarks(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sign_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_sign_status(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sign_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_signature(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_signature Error :",str(e))
            return {'status' : "ERROR"}


    def get_tenure(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tenure Error :",str(e))
            return {'status' : "ERROR"}


    def get_verification_mode(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_verification_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_video_status(self,session,application_id):
        try:
            return session.query(ApplicationDtl).filter(
                ApplicationDtl.application_id== application_id,
                ApplicationDtl.org_id == self.org_id, 
                ApplicationDtl.entity_cre_flg == self.entity_cre_flg, 
                ApplicationDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_video_status Error :",str(e))
            return {'status' : "ERROR"}
