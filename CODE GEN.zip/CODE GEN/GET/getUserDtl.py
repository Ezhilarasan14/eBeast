from modelnew import *
class ClsUpUserDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_alt_first_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_last_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_middle_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_preferred_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_br_id(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_disabled_from_date(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_disabled_from_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_disabled_to_date(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_disabled_to_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_email_otp(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email_otp Error :",str(e))
            return {'status' : "ERROR"}


    def get_email_otp_count(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email_otp_count Error :",str(e))
            return {'status' : "ERROR"}


    def get_employee_id(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employee_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_first_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_inv_pw_attmpts(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_inv_pw_attmpts Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_login(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_login Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_logged_on_flg(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_logged_on_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_login_window_enabled(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_login_window_enabled Error :",str(e))
            return {'status' : "ERROR"}


    def get_middle_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_mobile_otp(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mobile_otp Error :",str(e))
            return {'status' : "ERROR"}


    def get_mobile_otp_count(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mobile_otp_count Error :",str(e))
            return {'status' : "ERROR"}


    def get_passw_expiry_date(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_passw_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_password(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_password Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferred_language(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferred_name(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_access_id(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_valid_till(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_currency(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_currency Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_cust_type(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_email(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_expiry_date(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_nature(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_phone(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_phone Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_phone_cntry(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_phone_cntry Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_status(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_type(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_view_access_id(self,session,user_id):
        try:
            return session.query(UserDtl).filter(
                UserDtl.user_id== user_id,
                UserDtl.org_id == self.org_id, 
                UserDtl.entity_cre_flg == self.entity_cre_flg, 
                UserDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
