from modelnew import *
class ClsUpAppDataCompare:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_info_value(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_info_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_name(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_system_comp_status(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_system_comp_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_accept_status(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_accept_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_remarks(self,session,app_step_id,doc_code,doc_type,id,info_key):
        try:
            return session.query(AppDataCompare).filter(
                AppDataCompare.app_step_id== app_step_id,AppDataCompare.doc_code== doc_code,AppDataCompare.doc_type== doc_type,AppDataCompare.id== id,AppDataCompare.info_key== info_key,
                AppDataCompare.org_id == self.org_id, 
                AppDataCompare.entity_cre_flg == self.entity_cre_flg, 
                AppDataCompare.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_remarks Error :",str(e))
            return {'status' : "ERROR"}
