from modelnew import *
class ClsUpAppInteg:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_api_status(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_app_id(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_dep_on(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dep_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_id(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_integ_type(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_integ_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_integ_url(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_integ_url Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_api_revokable(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_api_revokable Error :",str(e))
            return {'status' : "ERROR"}


    def get_result(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_result Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_name(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_action(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_action Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_seq(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_seq Error :",str(e))
            return {'status' : "ERROR"}


    def get_trigger_step(self,session,app_integ_id):
        try:
            return session.query(AppInteg).filter(
                AppInteg.app_integ_id== app_integ_id,
                AppInteg.org_id == self.org_id, 
                AppInteg.entity_cre_flg == self.entity_cre_flg, 
                AppInteg.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_trigger_step Error :",str(e))
            return {'status' : "ERROR"}
