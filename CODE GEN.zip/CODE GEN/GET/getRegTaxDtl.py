from modelnew import *
class ClsUpRegTaxDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_cust_id(self,session,tax_code,tax_name,tax_type):
        try:
            return session.query(RegTaxDtl).filter(
                RegTaxDtl.tax_code== tax_code,RegTaxDtl.tax_name== tax_name,RegTaxDtl.tax_type== tax_type,
                RegTaxDtl.org_id == self.org_id, 
                RegTaxDtl.entity_cre_flg == self.entity_cre_flg, 
                RegTaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_desc(self,session,tax_code,tax_name,tax_type):
        try:
            return session.query(RegTaxDtl).filter(
                RegTaxDtl.tax_code== tax_code,RegTaxDtl.tax_name== tax_name,RegTaxDtl.tax_type== tax_type,
                RegTaxDtl.org_id == self.org_id, 
                RegTaxDtl.entity_cre_flg == self.entity_cre_flg, 
                RegTaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_tax_percentage(self,session,tax_code,tax_name,tax_type):
        try:
            return session.query(RegTaxDtl).filter(
                RegTaxDtl.tax_code== tax_code,RegTaxDtl.tax_name== tax_name,RegTaxDtl.tax_type== tax_type,
                RegTaxDtl.org_id == self.org_id, 
                RegTaxDtl.entity_cre_flg == self.entity_cre_flg, 
                RegTaxDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tax_percentage Error :",str(e))
            return {'status' : "ERROR"}
