from modelnew import *
class ClsUpCustomerDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_alt_first_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_last_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_middle_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_alt_preferred_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_dob(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_dob Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_email(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_phone(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_phone Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_phone_cntry(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_phone_cntry Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_status(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_type(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_disabled_from_date(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_disabled_from_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_disabled_to_date(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_disabled_to_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_number(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_number Error :",str(e))
            return {'status' : "ERROR"}


    def get_employee_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_employee_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_status(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_expense_avg(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expense_avg Error :",str(e))
            return {'status' : "ERROR"}


    def get_first_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_gender(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gender Error :",str(e))
            return {'status' : "ERROR"}


    def get_gross_salary(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gross_salary Error :",str(e))
            return {'status' : "ERROR"}


    def get_income_avg(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_income_avg Error :",str(e))
            return {'status' : "ERROR"}


    def get_last_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_marital_status(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_middle_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferred_language(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def get_preferred_name(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_primary_rm_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_primary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_secondary_rm_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_secondary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_access_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_temp_view_valid_till(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def get_view_access_id(self,session,cust_id):
        try:
            return session.query(CustomerDtl).filter(
                CustomerDtl.cust_id== cust_id,
                CustomerDtl.org_id == self.org_id, 
                CustomerDtl.entity_cre_flg == self.entity_cre_flg, 
                CustomerDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
