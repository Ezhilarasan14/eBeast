from modelnew import *
class ClsUpGoalDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_expense_cat_id(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_expense_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_frequency_type(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_frequency_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_frequency(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_frequency Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_inst_amt(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_inst_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_inst_crncy(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_inst_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_nature(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_period_metric(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_period_metric Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_period_num(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_period_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_status(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_tgt_amt(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_tgt_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_tgt_crncy(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_tgt_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_type(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_target_date(self,session,cust_id,goal_name):
        try:
            return session.query(GoalDtl).filter(
                GoalDtl.cust_id== cust_id,GoalDtl.goal_name== goal_name,
                GoalDtl.org_id == self.org_id, 
                GoalDtl.entity_cre_flg == self.entity_cre_flg, 
                GoalDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_target_date Error :",str(e))
            return {'status' : "ERROR"}
