from modelnew import *
class ClsUpAppStep:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_auth_matrix_code(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_data_overall_point(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_data_overall_point Error :",str(e))
            return {'status' : "ERROR"}


    def get_mandatory(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_step_id(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_step_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_code(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_name(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_num(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_status(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_total_doc_cnt(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_total_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_uploaded_doc_cnt(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_uploaded_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_remarks(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_verified_doc_cnt(self,session,app_step_id):
        try:
            return session.query(AppStep).filter(
                AppStep.app_step_id== app_step_id,
                AppStep.org_id == self.org_id, 
                AppStep.entity_cre_flg == self.entity_cre_flg, 
                AppStep.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_verified_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}
