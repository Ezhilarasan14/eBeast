from modelnew import *
class ClsUpFormDetail:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_allowed_field_format(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_allowed_field_format Error :",str(e))
            return {'status' : "ERROR"}


    def get_condition(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_condition Error :",str(e))
            return {'status' : "ERROR"}


    def get_default(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_default Error :",str(e))
            return {'status' : "ERROR"}


    def get_dependant_field_id(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dependant_field_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_dependant_field_logic(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dependant_field_logic Error :",str(e))
            return {'status' : "ERROR"}


    def get_dependant_section_id(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dependant_section_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_error_msg(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_error_msg Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_help_info(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_help_info Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_name(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_pattern(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_pattern Error :",str(e))
            return {'status' : "ERROR"}


    def get_field_type(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_field_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_form_name(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_form_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_data_owner(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_data_owner Error :",str(e))
            return {'status' : "ERROR"}


    def get_is_mandatory(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_is_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def get_logic_value(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_logic_value Error :",str(e))
            return {'status' : "ERROR"}


    def get_ocr_field(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ocr_field Error :",str(e))
            return {'status' : "ERROR"}


    def get_order_id(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_order_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_section_identifier(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_section_identifier Error :",str(e))
            return {'status' : "ERROR"}


    def get_section_name(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_section_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_select_ref_type(self,session,field_id,form_id,id,section_id):
        try:
            return session.query(FormDetail).filter(
                FormDetail.field_id== field_id,FormDetail.form_id== form_id,FormDetail.id== id,FormDetail.section_id== section_id,
                FormDetail.org_id == self.org_id, 
                FormDetail.entity_cre_flg == self.entity_cre_flg, 
                FormDetail.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_select_ref_type Error :",str(e))
            return {'status' : "ERROR"}
