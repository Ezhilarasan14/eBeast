from modelnew import *
class ClsUpAppLocation:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_display_name(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_display_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_time(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_latitude(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_longitude(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def get_response(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_response Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_time(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_info(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_info Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_status(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_status(self,session,loc_id):
        try:
            return session.query(AppLocation).filter(
                AppLocation.loc_id== loc_id,
                AppLocation.org_id == self.org_id, 
                AppLocation.entity_cre_flg == self.entity_cre_flg, 
                AppLocation.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_status Error :",str(e))
            return {'status' : "ERROR"}
