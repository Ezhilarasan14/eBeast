from modelnew import *
class ClsUpOrgDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_address_line1(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line1 Error :",str(e))
            return {'status' : "ERROR"}


    def get_address_line2(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_address_line2 Error :",str(e))
            return {'status' : "ERROR"}


    def get_api_key(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_key Error :",str(e))
            return {'status' : "ERROR"}


    def get_api_user(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_api_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_central_bank_code(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_central_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_central_bank_name(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_central_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_city(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_city Error :",str(e))
            return {'status' : "ERROR"}


    def get_collect_doc(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_collect_doc Error :",str(e))
            return {'status' : "ERROR"}


    def get_cont_num(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cont_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_country(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_country Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_val(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_val Error :",str(e))
            return {'status' : "ERROR"}


    def get_email_mand_onb(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_email_mand_onb Error :",str(e))
            return {'status' : "ERROR"}


    def get_enable_otp(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_enable_otp Error :",str(e))
            return {'status' : "ERROR"}


    def get_enable_spoof(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_enable_spoof Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_match(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_match Error :",str(e))
            return {'status' : "ERROR"}


    def get_face_match_thres(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_face_match_thres Error :",str(e))
            return {'status' : "ERROR"}


    def get_form_auto_fill(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_form_auto_fill Error :",str(e))
            return {'status' : "ERROR"}


    def get_gen_qrcode(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gen_qrcode Error :",str(e))
            return {'status' : "ERROR"}


    def get_gesture_thres(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_gesture_thres Error :",str(e))
            return {'status' : "ERROR"}


    def get_home_cntry_code(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_home_cntry_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_home_crncy_code(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_home_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_ind_type(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ind_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_kyc(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_kyc Error :",str(e))
            return {'status' : "ERROR"}


    def get_land_on(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_land_on Error :",str(e))
            return {'status' : "ERROR"}


    def get_max_clerk_view_id(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_max_clerk_view_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_minor_age(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_minor_age Error :",str(e))
            return {'status' : "ERROR"}


    def get_multi_crncy(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_multi_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def get_onb_ph_otp(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_onb_ph_otp Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_alias(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_alias Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_bod_date(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_cls_date(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_code(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_desc(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_desc_alt(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_icon(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_icon Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_logo(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_logo Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_status(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_org_website(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_org_website Error :",str(e))
            return {'status' : "ERROR"}


    def get_override_err(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_override_err Error :",str(e))
            return {'status' : "ERROR"}


    def get_priv_pol(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_priv_pol Error :",str(e))
            return {'status' : "ERROR"}


    def get_pw_valid_period(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pw_valid_period Error :",str(e))
            return {'status' : "ERROR"}


    def get_reg_no(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_reg_no Error :",str(e))
            return {'status' : "ERROR"}


    def get_rekyc_req(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rekyc_req Error :",str(e))
            return {'status' : "ERROR"}


    def get_scope(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_scope Error :",str(e))
            return {'status' : "ERROR"}


    def get_sign_mode(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sign_mode Error :",str(e))
            return {'status' : "ERROR"}


    def get_spoof_thres(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_spoof_thres Error :",str(e))
            return {'status' : "ERROR"}


    def get_state(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_state Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_order(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_order Error :",str(e))
            return {'status' : "ERROR"}


    def get_sub_id(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sub_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sub_plan(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sub_plan Error :",str(e))
            return {'status' : "ERROR"}


    def get_sub_status(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sub_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_sup_email(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sup_email Error :",str(e))
            return {'status' : "ERROR"}


    def get_tandc(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tandc Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_zone(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_lim_crncy_code(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_lim_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_week_begins_on(self,session,):
        try:
            return session.query(OrgDtl).filter(
                
                OrgDtl.org_id == self.org_id, 
                OrgDtl.entity_cre_flg == self.entity_cre_flg, 
                OrgDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_week_begins_on Error :",str(e))
            return {'status' : "ERROR"}
