from modelnew import *
class ClsUpAuthUserGroup:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_group(self,session,id):
        try:
            return session.query(AuthUserGroup).filter(
                AuthUserGroup.id== id,
                AuthUserGroup.org_id == self.org_id, 
                AuthUserGroup.entity_cre_flg == self.entity_cre_flg, 
                AuthUserGroup.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_group Error :",str(e))
            return {'status' : "ERROR"}


    def get_group_id(self,session,id):
        try:
            return session.query(AuthUserGroup).filter(
                AuthUserGroup.id== id,
                AuthUserGroup.org_id == self.org_id, 
                AuthUserGroup.entity_cre_flg == self.entity_cre_flg, 
                AuthUserGroup.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user(self,session,id):
        try:
            return session.query(AuthUserGroup).filter(
                AuthUserGroup.id== id,
                AuthUserGroup.org_id == self.org_id, 
                AuthUserGroup.entity_cre_flg == self.entity_cre_flg, 
                AuthUserGroup.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,id):
        try:
            return session.query(AuthUserGroup).filter(
                AuthUserGroup.id== id,
                AuthUserGroup.org_id == self.org_id, 
                AuthUserGroup.entity_cre_flg == self.entity_cre_flg, 
                AuthUserGroup.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
