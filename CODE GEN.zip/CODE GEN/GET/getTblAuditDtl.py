from modelnew import *
class ClsUpTblAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_audit_srl_num(self,session,log_id):
        try:
            return session.query(TblAuditDtl).filter(
                TblAuditDtl.log_id== log_id,
                TblAuditDtl.org_id == self.org_id, 
                TblAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                TblAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_audit_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_modified_fields(self,session,log_id):
        try:
            return session.query(TblAuditDtl).filter(
                TblAuditDtl.log_id== log_id,
                TblAuditDtl.org_id == self.org_id, 
                TblAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                TblAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_modified_fields Error :",str(e))
            return {'status' : "ERROR"}


    def get_operation(self,session,log_id):
        try:
            return session.query(TblAuditDtl).filter(
                TblAuditDtl.log_id== log_id,
                TblAuditDtl.org_id == self.org_id, 
                TblAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                TblAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_operation Error :",str(e))
            return {'status' : "ERROR"}


    def get_table_key(self,session,log_id):
        try:
            return session.query(TblAuditDtl).filter(
                TblAuditDtl.log_id== log_id,
                TblAuditDtl.org_id == self.org_id, 
                TblAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                TblAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_table_key Error :",str(e))
            return {'status' : "ERROR"}


    def get_table_name(self,session,log_id):
        try:
            return session.query(TblAuditDtl).filter(
                TblAuditDtl.log_id== log_id,
                TblAuditDtl.org_id == self.org_id, 
                TblAuditDtl.entity_cre_flg == self.entity_cre_flg, 
                TblAuditDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_table_name Error :",str(e))
            return {'status' : "ERROR"}
