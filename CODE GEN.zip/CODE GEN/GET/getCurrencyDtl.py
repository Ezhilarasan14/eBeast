from modelnew import *
class ClsUpCurrencyDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_alt_crncy_name(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_alt_crncy_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_crncy_alias(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_alias Error :",str(e))
            return {'status' : "ERROR"}


    def get_crncy_name(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_currency_id(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_currency_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_dec_desc(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dec_desc Error :",str(e))
            return {'status' : "ERROR"}


    def get_dec_digits(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dec_digits Error :",str(e))
            return {'status' : "ERROR"}


    def get_iso_crncy_num(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iso_crncy_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_rnd_off_amt(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rnd_off_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_rnd_off_ind(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rnd_off_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_strong_crncy(self,session,crncy_code):
        try:
            return session.query(CurrencyDtl).filter(
                CurrencyDtl.crncy_code== crncy_code,
                CurrencyDtl.org_id == self.org_id, 
                CurrencyDtl.entity_cre_flg == self.entity_cre_flg, 
                CurrencyDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_strong_crncy Error :",str(e))
            return {'status' : "ERROR"}
