from modelnew import *
class ClsUpSilkProfile:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_dynamic(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_dynamic Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_line_num(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_line_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_end_time(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_exception_raised(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_exception_raised Error :",str(e))
            return {'status' : "ERROR"}


    def get_file_path(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_file_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_func_name(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_func_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_line_num(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_line_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_name(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_request(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request Error :",str(e))
            return {'status' : "ERROR"}


    def get_request_id(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_start_time(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def get_time_taken(self,session,id):
        try:
            return session.query(SilkProfile).filter(
                SilkProfile.id== id,
                SilkProfile.org_id == self.org_id, 
                SilkProfile.entity_cre_flg == self.entity_cre_flg, 
                SilkProfile.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_time_taken Error :",str(e))
            return {'status' : "ERROR"}
