from modelnew import *
class ClsUpEntityDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_acc_added_type(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_acc_added_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_aggregation_source(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_aggregation_source Error :",str(e))
            return {'status' : "ERROR"}


    def get_asset_category(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_asset_category Error :",str(e))
            return {'status' : "ERROR"}


    def get_available_balance(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_available_balance Error :",str(e))
            return {'status' : "ERROR"}


    def get_bank_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_bank_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_branch_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_branch_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_branch_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_chq_opt_flg(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_chq_opt_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_bank_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_branch_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_ind(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_num(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_acct_swift_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_acct_swift_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_coll_mode_ind(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coll_mode_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_crncy_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_eff_interest_rate(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_eff_interest_rate Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_alt_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_alt_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_branch(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_branch Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_cash_dr_lim(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_cash_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_cls_date(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_cls_flg(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_cls_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_curr_bal(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_curr_bal Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_cust_type(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_ext_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_ext_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_limit(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_limit Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_nature(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_nick_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_nick_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_open_date(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_open_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_pd_days(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_pd_days Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_pd_times(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_pd_times Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_status(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_entity_xfer_dr_lim(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_entity_xfer_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def get_goal_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_goal_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_iban_num(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_iban_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_ifsc_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_int_ext_flg(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_int_ext_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_maturity_date(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_maturity_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_bank_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_branch_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_ind(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_name(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_num(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_acct_swift_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_acct_swift_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_pay_mode_ind(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_pay_mode_ind Error :",str(e))
            return {'status' : "ERROR"}


    def get_primary_rm_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_primary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_code(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_product_type(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_product_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_providerId(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_providerId Error :",str(e))
            return {'status' : "ERROR"}


    def get_provider_account_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_provider_account_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_rem_installments(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_rem_installments Error :",str(e))
            return {'status' : "ERROR"}


    def get_requestId(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_requestId Error :",str(e))
            return {'status' : "ERROR"}


    def get_secondary_rm_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_secondary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_opt_flg(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_opt_flg Error :",str(e))
            return {'status' : "ERROR"}


    def get_sweep_pool_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sweep_pool_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_tot_installments(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_tot_installments Error :",str(e))
            return {'status' : "ERROR"}


    def get_total_due_amt(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_total_due_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_total_limit(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_total_limit Error :",str(e))
            return {'status' : "ERROR"}


    def get_upcoming_due_amt(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_upcoming_due_amt Error :",str(e))
            return {'status' : "ERROR"}


    def get_upcoming_due_date(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_upcoming_due_date Error :",str(e))
            return {'status' : "ERROR"}


    def get_upi_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_upi_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_yodlee_account_id(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_yodlee_account_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_yodlee_status(self,session,bank_id,entity_id,entity_int_id):
        try:
            return session.query(EntityDtl).filter(
                EntityDtl.bank_id== bank_id,EntityDtl.entity_id== entity_id,EntityDtl.entity_int_id== entity_int_id,
                EntityDtl.org_id == self.org_id, 
                EntityDtl.entity_cre_flg == self.entity_cre_flg, 
                EntityDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}
