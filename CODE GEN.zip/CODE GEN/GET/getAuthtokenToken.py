from modelnew import *
class ClsUpAuthtokenToken:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_created(self,session,key):
        try:
            return session.query(AuthtokenToken).filter(
                AuthtokenToken.key== key,
                AuthtokenToken.org_id == self.org_id, 
                AuthtokenToken.entity_cre_flg == self.entity_cre_flg, 
                AuthtokenToken.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_created Error :",str(e))
            return {'status' : "ERROR"}


    def get_user(self,session,key):
        try:
            return session.query(AuthtokenToken).filter(
                AuthtokenToken.key== key,
                AuthtokenToken.org_id == self.org_id, 
                AuthtokenToken.entity_cre_flg == self.entity_cre_flg, 
                AuthtokenToken.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user Error :",str(e))
            return {'status' : "ERROR"}


    def get_user_id(self,session,key):
        try:
            return session.query(AuthtokenToken).filter(
                AuthtokenToken.key== key,
                AuthtokenToken.org_id == self.org_id, 
                AuthtokenToken.entity_cre_flg == self.entity_cre_flg, 
                AuthtokenToken.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_user_id Error :",str(e))
            return {'status' : "ERROR"}
