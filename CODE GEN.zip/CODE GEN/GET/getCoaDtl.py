from modelnew import *
class ClsUpCoaDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_coa_name(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coa_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_coa_type(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_coa_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_head(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_head Error :",str(e))
            return {'status' : "ERROR"}


    def get_level(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_level Error :",str(e))
            return {'status' : "ERROR"}


    def get_parent_coa_id(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_parent_coa_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_sys_cat_id(self,session,coa_id):
        try:
            return session.query(CoaDtl).filter(
                CoaDtl.coa_id== coa_id,
                CoaDtl.org_id == self.org_id, 
                CoaDtl.entity_cre_flg == self.entity_cre_flg, 
                CoaDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}
