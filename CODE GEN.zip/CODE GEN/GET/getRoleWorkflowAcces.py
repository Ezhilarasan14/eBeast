from modelnew import *
class ClsUpRoleWorkflowAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_crncy_code(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_finserv_id(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_code(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_nature(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_sub_type(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_prod_type(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_role_code(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_step_code(self,session,role_wf_id):
        try:
            return session.query(RoleWorkflowAcces).filter(
                RoleWorkflowAcces.role_wf_id== role_wf_id,
                RoleWorkflowAcces.org_id == self.org_id, 
                RoleWorkflowAcces.entity_cre_flg == self.entity_cre_flg, 
                RoleWorkflowAcces.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_step_code Error :",str(e))
            return {'status' : "ERROR"}
