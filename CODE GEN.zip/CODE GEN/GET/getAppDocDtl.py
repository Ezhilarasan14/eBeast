from modelnew import *
class ClsUpAppDocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_application_id(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_doc_host(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_doc_host Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_doc_path(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_file_name(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_file_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_obj_cont(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_obj_cont Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_obj_det_content(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_obj_det_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_ocr_content(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_ocr_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_back_ocr_extract_list(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_back_ocr_extract_list Error :",str(e))
            return {'status' : "ERROR"}


    def get_cust_id(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_code(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_host(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_host Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_number(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_number Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_path(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_src(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_src Error :",str(e))
            return {'status' : "ERROR"}


    def get_doc_type(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_file_name(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_file_name Error :",str(e))
            return {'status' : "ERROR"}


    def get_front_obj_cont(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_front_obj_cont Error :",str(e))
            return {'status' : "ERROR"}


    def get_img_filename(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_img_filename Error :",str(e))
            return {'status' : "ERROR"}


    def get_img_match_score(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_img_match_score Error :",str(e))
            return {'status' : "ERROR"}


    def get_manual_status(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_manual_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_obj_det_content(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_obj_det_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_ocr_content(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ocr_content Error :",str(e))
            return {'status' : "ERROR"}


    def get_ocr_extract_list(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ocr_extract_list Error :",str(e))
            return {'status' : "ERROR"}


    def get_ocr_status(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_ocr_status Error :",str(e))
            return {'status' : "ERROR"}


    def get_purpose_of_doc(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_purpose_of_doc Error :",str(e))
            return {'status' : "ERROR"}


    def get_remarks(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def get_request_id(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_system_status(self,session,doc_id):
        try:
            return session.query(AppDocDtl).filter(
                AppDocDtl.doc_id== doc_id,
                AppDocDtl.org_id == self.org_id, 
                AppDocDtl.entity_cre_flg == self.entity_cre_flg, 
                AppDocDtl.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_system_status Error :",str(e))
            return {'status' : "ERROR"}
