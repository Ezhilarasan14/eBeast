from modelnew import *
class ClsUpAuditlogLogentry:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_action(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_action Error :",str(e))
            return {'status' : "ERROR"}


    def get_actor(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_actor Error :",str(e))
            return {'status' : "ERROR"}


    def get_actor_id(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_actor_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_additional_data(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_additional_data Error :",str(e))
            return {'status' : "ERROR"}


    def get_changes(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_changes Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def get_content_type_id(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_id(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_pk(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_pk Error :",str(e))
            return {'status' : "ERROR"}


    def get_object_repr(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_object_repr Error :",str(e))
            return {'status' : "ERROR"}


    def get_remote_addr(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_remote_addr Error :",str(e))
            return {'status' : "ERROR"}


    def get_timestamp(self,session,id):
        try:
            return session.query(AuditlogLogentry).filter(
                AuditlogLogentry.id== id,
                AuditlogLogentry.org_id == self.org_id, 
                AuditlogLogentry.entity_cre_flg == self.entity_cre_flg, 
                AuditlogLogentry.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_timestamp Error :",str(e))
            return {'status' : "ERROR"}
