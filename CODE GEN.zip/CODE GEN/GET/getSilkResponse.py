from modelnew import *
class ClsUpSilkResponse:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def get_body(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_body Error :",str(e))
            return {'status' : "ERROR"}


    def get_encoded_headers(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_encoded_headers Error :",str(e))
            return {'status' : "ERROR"}


    def get_raw_body(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_raw_body Error :",str(e))
            return {'status' : "ERROR"}


    def get_request(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request Error :",str(e))
            return {'status' : "ERROR"}


    def get_request_id(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def get_status_code(self,session,id):
        try:
            return session.query(SilkResponse).filter(
                SilkResponse.id== id,
                SilkResponse.org_id == self.org_id, 
                SilkResponse.entity_cre_flg == self.entity_cre_flg, 
                SilkResponse.del_flg == self.del_flg).all()
        except Exception as e:
            print(" {*} get_status_code Error :",str(e))
            return {'status' : "ERROR"}
