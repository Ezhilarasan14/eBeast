
import pymysql

pymysql.install_as_MySQLdb()

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session,sessionmaker
from django.conf import settings
from sqlalchemy.engine import url
# import cx_Oracle

# cx_Oracle.init_oracle_client(lib_dir="/Users/tocode/Projects/toCode/aiEndorse_Backend/instantclient_19_8")

DATABASE_ENGINE = 'mysql://root:tocodetech@localhost/digid_nov_2022'
engine = create_engine(DATABASE_ENGINE)

def Session():
    # POOL_RECYCLE is used to reset mysql timeout
    # engine = create_engine(settings.DATABASE_ENGINE,pool_recycle=settings.POOL_RECYCLE)
    _Session = scoped_session(sessionmaker(bind=engine))
    return _Session()

import pandas as pd
import json
import sys
from datetime import datetime

def SqlAlchemyModelEncoder(query,return_type='J'):
    df = pd.DataFrame(query)
    if df.empty:
        return []
    result = json.loads(df.to_json(orient='records',default_handler=str,date_format = 'iso'))
    del df
    try:
        new_result = []
        for l in result:
            temp_dict = {}
            for k,v in l.items():
                if type(v) == str:
                    temp_dict[k] = v.replace('T00:00:00.000Z','')
                else:
                    temp_dict[k] = v
            new_result.append(temp_dict)
        if return_type == 'J':
            return new_result
        if return_type == 'P':
            return pd.DataFrame(new_result)
        return new_result
    except Exception as e:
        print("ORM2JSON e", e)
    return result



""" Validation date format based on Platform """
def validDateByOS(date_string=None):
    try:
        if (sys.platform.startswith("linux")):  # could be "linux", "linux2", "linux3", etc
            return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%S.000')
        elif (sys.platform == "darwin"):  # refers "Mac OS X"
            return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%S.000Z')
        else:   # refers Windows (either 32-bit or 64-bit)
            return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%S.000Z')
    except (Exception) as e:
        log_error(' [*] == validDateByOS error ==',str(e))
        # raise Exception(ErrCode['INVALID_DATE_FORMAT'].format(date_string=date_string))
        return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%S.000Z')


from models import SubDtl

def chkSubExp():
    session = Session()
    query = session.query(
        SubDtl.plan_name,
        SubDtl.start_date,
        SubDtl.end_date,
        SubDtl.status,
        SubDtl.details
        )
    query = query.filter(
        SubDtl.status!='R',
        SubDtl.org_id=='SETUP',
        SubDtl.entity_cre_flg=='Y', 
        SubDtl.del_flg=='N'
    ).all()
    
    sub_list = SqlAlchemyModelEncoder(query)
    if(len(sub_list) > 0):
        cur_date = datetime.today()
        print("cur_date",cur_date)
        end_date = datetime.strptime(sub_list[0]['end_date'], '%Y-%m-%dT%H:%M:%S.000Z')
        print("end_date",end_date)
        
    return sub_list

result = chkSubExp()
print(result)

