from modelnew import *
class ClsUpNtfnConf:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_email(self,session,notif_code,email):
        try:
            session.query(NtfnConf).filter_by(
                org_id=self.org_id,
                			if notif_code:
				query = query.filter(NtfnConf.notif_code== notif_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email=email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_mobile(self,session,notif_code,mobile):
        try:
            session.query(NtfnConf).filter_by(
                org_id=self.org_id,
                			if notif_code:
				query = query.filter(NtfnConf.notif_code== notif_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mobile=mobile))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mobile Error :",str(e))
            return {'status' : "ERROR"}


    def update_notif_desc(self,session,notif_code,notif_desc):
        try:
            session.query(NtfnConf).filter_by(
                org_id=self.org_id,
                			if notif_code:
				query = query.filter(NtfnConf.notif_code== notif_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(notif_desc=notif_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_notif_desc Error :",str(e))
            return {'status' : "ERROR"}
