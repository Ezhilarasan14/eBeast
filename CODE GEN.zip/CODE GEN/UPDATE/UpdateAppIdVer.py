from modelnew import *
class ClsUpAppIdVer:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,id_ver_no,application_id):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_applnt_status(self,session,id_ver_no,applnt_status):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applnt_status=applnt_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applnt_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_applnt_status_remarks(self,session,id_ver_no,applnt_status_remarks):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applnt_status_remarks=applnt_status_remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applnt_status_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_capt_path(self,session,id_ver_no,capt_path):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(capt_path=capt_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_capt_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,id_ver_no,cust_id):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_dist(self,session,id_ver_no,face_dist):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_dist=face_dist))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_dist Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_score(self,session,id_ver_no,face_score):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_score=face_score))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_score Error :",str(e))
            return {'status' : "ERROR"}


    def update_frame_rate(self,session,id_ver_no,frame_rate):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(frame_rate=frame_rate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_frame_rate Error :",str(e))
            return {'status' : "ERROR"}


    def update_img_status(self,session,id_ver_no,img_status):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(img_status=img_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_img_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_det(self,session,id_ver_no,otp_det):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_det=otp_det))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_det Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_gen(self,session,id_ver_no,otp_gen):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_gen=otp_gen))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_gen Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_status(self,session,id_ver_no,otp_status):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_status=otp_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_ph_cap_path(self,session,id_ver_no,ph_cap_path):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ph_cap_path=ph_cap_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ph_cap_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_ph_doc_code(self,session,id_ver_no,ph_doc_code):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ph_doc_code=ph_doc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ph_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_ph_doc_path(self,session,id_ver_no,ph_doc_path):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ph_doc_path=ph_doc_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ph_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_ph_vid_fig(self,session,id_ver_no,ph_vid_fig):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ph_vid_fig=ph_vid_fig))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ph_vid_fig Error :",str(e))
            return {'status' : "ERROR"}


    def update_proc_path(self,session,id_ver_no,proc_path):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(proc_path=proc_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_proc_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_spoof_score(self,session,id_ver_no,spoof_score):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(spoof_score=spoof_score))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_spoof_score Error :",str(e))
            return {'status' : "ERROR"}


    def update_spoof_status(self,session,id_ver_no,spoof_status):
        try:
            session.query(AppIdVer).filter_by(
                org_id=self.org_id,
                			if id_ver_no:
				query = query.filter(AppIdVer.id_ver_no== id_ver_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(spoof_status=spoof_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_spoof_status Error :",str(e))
            return {'status' : "ERROR"}
