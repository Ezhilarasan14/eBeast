from modelnew import *
class ClsUpCustomerDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_alt_first_name(self,session,cust_id,alt_first_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_first_name=alt_first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_last_name(self,session,cust_id,alt_last_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_last_name=alt_last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_middle_name(self,session,cust_id,alt_middle_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_middle_name=alt_middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_preferred_name(self,session,cust_id,alt_preferred_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_preferred_name=alt_preferred_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_dob(self,session,cust_id,cust_dob):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_dob=cust_dob))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_dob Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_email(self,session,cust_id,cust_email):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_email=cust_email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_phone(self,session,cust_id,cust_phone):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_phone=cust_phone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_phone Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_phone_cntry(self,session,cust_id,cust_phone_cntry):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_phone_cntry=cust_phone_cntry))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_phone_cntry Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_status(self,session,cust_id,cust_status):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_status=cust_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_type(self,session,cust_id,cust_type):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_type=cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_disabled_from_date(self,session,cust_id,disabled_from_date):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(disabled_from_date=disabled_from_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_disabled_from_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_disabled_to_date(self,session,cust_id,disabled_to_date):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(disabled_to_date=disabled_to_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_disabled_to_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_number(self,session,cust_id,doc_number):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_number=doc_number))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_number Error :",str(e))
            return {'status' : "ERROR"}


    def update_employee_id(self,session,cust_id,employee_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employee_id=employee_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employee_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_id(self,session,cust_id,entity_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_id=entity_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_status(self,session,cust_id,entity_status):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_status=entity_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_expense_avg(self,session,cust_id,expense_avg):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(expense_avg=expense_avg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_expense_avg Error :",str(e))
            return {'status' : "ERROR"}


    def update_first_name(self,session,cust_id,first_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(first_name=first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_gender(self,session,cust_id,gender):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gender=gender))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gender Error :",str(e))
            return {'status' : "ERROR"}


    def update_gross_salary(self,session,cust_id,gross_salary):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gross_salary=gross_salary))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gross_salary Error :",str(e))
            return {'status' : "ERROR"}


    def update_income_avg(self,session,cust_id,income_avg):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(income_avg=income_avg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_income_avg Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_name(self,session,cust_id,last_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_name=last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_marital_status(self,session,cust_id,marital_status):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(marital_status=marital_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_middle_name(self,session,cust_id,middle_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(middle_name=middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferred_language(self,session,cust_id,preferred_language):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferred_language=preferred_language))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferred_name(self,session,cust_id,preferred_name):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferred_name=preferred_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_primary_rm_id(self,session,cust_id,primary_rm_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(primary_rm_id=primary_rm_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_primary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_secondary_rm_id(self,session,cust_id,secondary_rm_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(secondary_rm_id=secondary_rm_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_secondary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_access_id(self,session,cust_id,temp_view_access_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_access_id=temp_view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_valid_till(self,session,cust_id,temp_view_valid_till):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_valid_till=temp_view_valid_till))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def update_view_access_id(self,session,cust_id,view_access_id):
        try:
            session.query(CustomerDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustomerDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(view_access_id=view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
