from modelnew import *
class ClsUpGeneralCode:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_alt_ref_desc(self,session,gen_id,alt_ref_desc):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_ref_desc=alt_ref_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_ref_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_level(self,session,gen_id,level):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(level=level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_nature(self,session,gen_id,nature):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(nature=nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_ref_code(self,session,gen_id,parent_ref_code):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_ref_code=parent_ref_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_ref_type(self,session,gen_id,parent_ref_type):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_ref_type=parent_ref_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_code(self,session,gen_id,ref_code):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_code=ref_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_desc(self,session,gen_id,ref_desc):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_desc=ref_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_type(self,session,gen_id,ref_type):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_type=ref_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_type_desc(self,session,gen_id,ref_type_desc):
        try:
            session.query(GeneralCode).filter_by(
                org_id=self.org_id,
                			if gen_id:
				query = query.filter(GeneralCode.gen_id== gen_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_type_desc=ref_type_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_type_desc Error :",str(e))
            return {'status' : "ERROR"}
