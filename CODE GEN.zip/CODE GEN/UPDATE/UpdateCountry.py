from modelnew import *
class ClsUpCountry:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_capital(self,session,id,capital):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(capital=capital))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_capital Error :",str(e))
            return {'status' : "ERROR"}


    def update_created_at(self,session,id,created_at):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(created_at=created_at))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_created_at Error :",str(e))
            return {'status' : "ERROR"}


    def update_currency(self,session,id,currency):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(currency=currency))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_currency Error :",str(e))
            return {'status' : "ERROR"}


    def update_currency_name(self,session,id,currency_name):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(currency_name=currency_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_currency_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_currency_symbol(self,session,id,currency_symbol):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(currency_symbol=currency_symbol))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_currency_symbol Error :",str(e))
            return {'status' : "ERROR"}


    def update_emoji(self,session,id,emoji):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(emoji=emoji))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_emoji Error :",str(e))
            return {'status' : "ERROR"}


    def update_emojiU(self,session,id,emojiU):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(emojiU=emojiU))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_emojiU Error :",str(e))
            return {'status' : "ERROR"}


    def update_flag(self,session,id,flag):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(flag=flag))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_flag Error :",str(e))
            return {'status' : "ERROR"}


    def update_iso2(self,session,id,iso2):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iso2=iso2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iso2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_iso3(self,session,id,iso3):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iso3=iso3))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iso3 Error :",str(e))
            return {'status' : "ERROR"}


    def update_latitude(self,session,id,latitude):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(latitude=latitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_longitude(self,session,id,longitude):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(longitude=longitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_name(self,session,id,name):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_native(self,session,id,native):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(native=native))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_native Error :",str(e))
            return {'status' : "ERROR"}


    def update_numeric_code(self,session,id,numeric_code):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(numeric_code=numeric_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_numeric_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_phonecode(self,session,id,phonecode):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(phonecode=phonecode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_phonecode Error :",str(e))
            return {'status' : "ERROR"}


    def update_region(self,session,id,region):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(region=region))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_region Error :",str(e))
            return {'status' : "ERROR"}


    def update_subregion(self,session,id,subregion):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(subregion=subregion))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_subregion Error :",str(e))
            return {'status' : "ERROR"}


    def update_timezones(self,session,id,timezones):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(timezones=timezones))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_timezones Error :",str(e))
            return {'status' : "ERROR"}


    def update_tld(self,session,id,tld):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tld=tld))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tld Error :",str(e))
            return {'status' : "ERROR"}


    def update_translations(self,session,id,translations):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(translations=translations))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_translations Error :",str(e))
            return {'status' : "ERROR"}


    def update_updated_at(self,session,id,updated_at):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(updated_at=updated_at))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_updated_at Error :",str(e))
            return {'status' : "ERROR"}


    def update_wikiDataId(self,session,id,wikiDataId):
        try:
            session.query(Country).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Country.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(wikiDataId=wikiDataId))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}
