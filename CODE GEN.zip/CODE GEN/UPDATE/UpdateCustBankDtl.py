from modelnew import *
class ClsUpCustBankDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_acct_number(self,session,cust_id,acct_number):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(acct_number=acct_number))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_acct_number Error :",str(e))
            return {'status' : "ERROR"}


    def update_bank_code(self,session,cust_id,bank_code):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(bank_code=bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_bank_name(self,session,cust_id,bank_name):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(bank_name=bank_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_branch_code(self,session,cust_id,branch_code):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(branch_code=branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_iban_number(self,session,cust_id,iban_number):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iban_number=iban_number))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iban_number Error :",str(e))
            return {'status' : "ERROR"}


    def update_image_path(self,session,cust_id,image_path):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(image_path=image_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_payment_integration(self,session,cust_id,payment_integration):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(payment_integration=payment_integration))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_payment_integration Error :",str(e))
            return {'status' : "ERROR"}


    def update_sector(self,session,cust_id,sector):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sector=sector))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sector Error :",str(e))
            return {'status' : "ERROR"}


    def update_swift_code(self,session,cust_id,swift_code):
        try:
            session.query(CustBankDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustBankDtl.cust_id== cust_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(swift_code=swift_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_swift_code Error :",str(e))
            return {'status' : "ERROR"}
