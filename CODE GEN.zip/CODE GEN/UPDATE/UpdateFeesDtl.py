from modelnew import *
class ClsUpFeesDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_fee_amount(self,session,fee_code,fee_crncy_code,finserv_id,fee_amount):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fee_amount=fee_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fee_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_fee_amt_ind(self,session,fee_code,fee_crncy_code,finserv_id,fee_amt_ind):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fee_amt_ind=fee_amt_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fee_amt_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_fee_desc(self,session,fee_code,fee_crncy_code,finserv_id,fee_desc):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fee_desc=fee_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fee_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_fee_desc_alt(self,session,fee_code,fee_crncy_code,finserv_id,fee_desc_alt):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fee_desc_alt=fee_desc_alt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fee_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def update_fee_pcnt(self,session,fee_code,fee_crncy_code,finserv_id,fee_pcnt):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fee_pcnt=fee_pcnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fee_pcnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_apply(self,session,fee_code,fee_crncy_code,finserv_id,tax_apply):
        try:
            session.query(FeesDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(FeesDtl.fee_code== fee_code)
			if fee_crncy_code:
				query = query.filter(FeesDtl.fee_crncy_code== fee_crncy_code)
			if finserv_id:
				query = query.filter(FeesDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_apply=tax_apply))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_apply Error :",str(e))
            return {'status' : "ERROR"}
