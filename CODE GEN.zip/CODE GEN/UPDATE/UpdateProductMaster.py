from modelnew import *
class ClsUpProductMaster:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_all_global_applnt(self,session,finserv_id,prod_code,all_global_applnt):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(all_global_applnt=all_global_applnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_all_global_applnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_prod_name(self,session,finserv_id,prod_code,alt_prod_name):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_prod_name=alt_prod_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_cat(self,session,finserv_id,prod_code,app_cat):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_cat=app_cat))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_cat Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_fill_form(self,session,finserv_id,prod_code,app_fill_form):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_fill_form=app_fill_form))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_fill_form Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_frm(self,session,finserv_id,prod_code,app_frm):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_frm=app_frm))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_frm Error :",str(e))
            return {'status' : "ERROR"}


    def update_auto_approve(self,session,finserv_id,prod_code,auto_approve):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auto_approve=auto_approve))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auto_approve Error :",str(e))
            return {'status' : "ERROR"}


    def update_capture_doc(self,session,finserv_id,prod_code,capture_doc):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(capture_doc=capture_doc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_capture_doc Error :",str(e))
            return {'status' : "ERROR"}


    def update_collect_doc(self,session,finserv_id,prod_code,collect_doc):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(collect_doc=collect_doc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_collect_doc Error :",str(e))
            return {'status' : "ERROR"}


    def update_enable_otp(self,session,finserv_id,prod_code,enable_otp):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(enable_otp=enable_otp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_enable_otp Error :",str(e))
            return {'status' : "ERROR"}


    def update_enable_spoof(self,session,finserv_id,prod_code,enable_spoof):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(enable_spoof=enable_spoof))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_enable_spoof Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_match(self,session,finserv_id,prod_code,face_match):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_match=face_match))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_match Error :",str(e))
            return {'status' : "ERROR"}


    def update_form_auto_fill(self,session,finserv_id,prod_code,form_auto_fill):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(form_auto_fill=form_auto_fill))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_form_auto_fill Error :",str(e))
            return {'status' : "ERROR"}


    def update_kyc(self,session,finserv_id,prod_code,kyc):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(kyc=kyc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_kyc Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_ad_content(self,session,finserv_id,prod_code,prod_ad_content):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_ad_content=prod_ad_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_ad_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_alt_ad_content(self,session,finserv_id,prod_code,prod_alt_ad_content):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_alt_ad_content=prod_alt_ad_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_alt_ad_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_name(self,session,finserv_id,prod_code,prod_name):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_name=prod_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_nature(self,session,finserv_id,prod_code,prod_nature):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_nature=prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_status(self,session,finserv_id,prod_code,prod_status):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_status=prod_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_sub_type(self,session,finserv_id,prod_code,prod_sub_type):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_sub_type=prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_type(self,session,finserv_id,prod_code,prod_type):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_type=prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_img(self,session,finserv_id,prod_code,product_img):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_img=product_img))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_img Error :",str(e))
            return {'status' : "ERROR"}


    def update_response(self,session,finserv_id,prod_code,response):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(response=response))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_response Error :",str(e))
            return {'status' : "ERROR"}


    def update_sign_mode(self,session,finserv_id,prod_code,sign_mode):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sign_mode=sign_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sign_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_skip_steps(self,session,finserv_id,prod_code,skip_steps):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(skip_steps=skip_steps))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_skip_steps Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_order(self,session,finserv_id,prod_code,step_order):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_order=step_order))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_order Error :",str(e))
            return {'status' : "ERROR"}


    def update_users(self,session,finserv_id,prod_code,users):
        try:
            session.query(ProductMaster).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(ProductMaster.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductMaster.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(users=users))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_users Error :",str(e))
            return {'status' : "ERROR"}
