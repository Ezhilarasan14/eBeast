from modelnew import *
class ClsUpSilkRequest:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_body(self,session,id,body):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(body=body))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_body Error :",str(e))
            return {'status' : "ERROR"}


    def update_encoded_headers(self,session,id,encoded_headers):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(encoded_headers=encoded_headers))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_encoded_headers Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,id,end_time):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_meta_num_queries(self,session,id,meta_num_queries):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(meta_num_queries=meta_num_queries))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_meta_num_queries Error :",str(e))
            return {'status' : "ERROR"}


    def update_meta_time(self,session,id,meta_time):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(meta_time=meta_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_meta_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_meta_time_spent_queries(self,session,id,meta_time_spent_queries):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(meta_time_spent_queries=meta_time_spent_queries))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_meta_time_spent_queries Error :",str(e))
            return {'status' : "ERROR"}


    def update_method(self,session,id,method):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(method=method))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_method Error :",str(e))
            return {'status' : "ERROR"}


    def update_num_sql_queries(self,session,id,num_sql_queries):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(num_sql_queries=num_sql_queries))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_num_sql_queries Error :",str(e))
            return {'status' : "ERROR"}


    def update_path(self,session,id,path):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(path=path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_prof_file(self,session,id,prof_file):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prof_file=prof_file))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prof_file Error :",str(e))
            return {'status' : "ERROR"}


    def update_pyprofile(self,session,id,pyprofile):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pyprofile=pyprofile))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pyprofile Error :",str(e))
            return {'status' : "ERROR"}


    def update_query_params(self,session,id,query_params):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(query_params=query_params))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_query_params Error :",str(e))
            return {'status' : "ERROR"}


    def update_raw_body(self,session,id,raw_body):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(raw_body=raw_body))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_raw_body Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,id,start_time):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_taken(self,session,id,time_taken):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_taken=time_taken))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_taken Error :",str(e))
            return {'status' : "ERROR"}


    def update_view_name(self,session,id,view_name):
        try:
            session.query(SilkRequest).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkRequest.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(view_name=view_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_view_name Error :",str(e))
            return {'status' : "ERROR"}
