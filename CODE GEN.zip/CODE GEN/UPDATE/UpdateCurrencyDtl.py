from modelnew import *
class ClsUpCurrencyDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_alt_crncy_name(self,session,crncy_code,alt_crncy_name):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_crncy_name=alt_crncy_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_crncy_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_crncy_alias(self,session,crncy_code,crncy_alias):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_alias=crncy_alias))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_alias Error :",str(e))
            return {'status' : "ERROR"}


    def update_crncy_name(self,session,crncy_code,crncy_name):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_name=crncy_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_currency_id(self,session,crncy_code,currency_id):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(currency_id=currency_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_currency_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_dec_desc(self,session,crncy_code,dec_desc):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dec_desc=dec_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dec_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_dec_digits(self,session,crncy_code,dec_digits):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dec_digits=dec_digits))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dec_digits Error :",str(e))
            return {'status' : "ERROR"}


    def update_iso_crncy_num(self,session,crncy_code,iso_crncy_num):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iso_crncy_num=iso_crncy_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iso_crncy_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_rnd_off_amt(self,session,crncy_code,rnd_off_amt):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rnd_off_amt=rnd_off_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rnd_off_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_rnd_off_ind(self,session,crncy_code,rnd_off_ind):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rnd_off_ind=rnd_off_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rnd_off_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_strong_crncy(self,session,crncy_code,strong_crncy):
        try:
            session.query(CurrencyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(CurrencyDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(strong_crncy=strong_crncy))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_strong_crncy Error :",str(e))
            return {'status' : "ERROR"}
