from modelnew import *
class ClsUpAppointmentDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_agent_person_id(self,session,appointment_id,agent_person_id):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(agent_person_id=agent_person_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_agent_person_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_comments(self,session,appointment_id,appointment_comments):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_comments=appointment_comments))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_comments Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_date(self,session,appointment_id,appointment_date):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_date=appointment_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_day(self,session,appointment_id,appointment_day):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_day=appointment_day))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_day Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_owner(self,session,appointment_id,appointment_owner):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_owner=appointment_owner))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_owner Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_status(self,session,appointment_id,appointment_status):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_status=appointment_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_appointment_type(self,session,appointment_id,appointment_type):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(appointment_type=appointment_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_appointment_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,appointment_id,end_time):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,appointment_id,start_time):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_target_person_id(self,session,appointment_id,target_person_id):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(target_person_id=target_person_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_target_person_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_target_person_type(self,session,appointment_id,target_person_type):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(target_person_type=target_person_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_target_person_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_zone(self,session,appointment_id,time_zone):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_zone=time_zone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def update_topic(self,session,appointment_id,topic):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(topic=topic))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_topic Error :",str(e))
            return {'status' : "ERROR"}


    def update_venue(self,session,appointment_id,venue):
        try:
            session.query(AppointmentDtl).filter_by(
                org_id=self.org_id,
                			if appointment_id:
				query = query.filter(AppointmentDtl.appointment_id== appointment_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(venue=venue))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_venue Error :",str(e))
            return {'status' : "ERROR"}
