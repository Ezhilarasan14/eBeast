from modelnew import *
class ClsUpUserDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_alt_first_name(self,session,user_id,alt_first_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_first_name=alt_first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_last_name(self,session,user_id,alt_last_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_last_name=alt_last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_middle_name(self,session,user_id,alt_middle_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_middle_name=alt_middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_preferred_name(self,session,user_id,alt_preferred_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_preferred_name=alt_preferred_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_id(self,session,user_id,br_id):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_id=br_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_disabled_from_date(self,session,user_id,disabled_from_date):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(disabled_from_date=disabled_from_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_disabled_from_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_disabled_to_date(self,session,user_id,disabled_to_date):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(disabled_to_date=disabled_to_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_disabled_to_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_email_otp(self,session,user_id,email_otp):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email_otp=email_otp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email_otp Error :",str(e))
            return {'status' : "ERROR"}


    def update_email_otp_count(self,session,user_id,email_otp_count):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email_otp_count=email_otp_count))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email_otp_count Error :",str(e))
            return {'status' : "ERROR"}


    def update_employee_id(self,session,user_id,employee_id):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employee_id=employee_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employee_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_first_name(self,session,user_id,first_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(first_name=first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_inv_pw_attmpts(self,session,user_id,inv_pw_attmpts):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(inv_pw_attmpts=inv_pw_attmpts))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_inv_pw_attmpts Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_login(self,session,user_id,last_login):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_login=last_login))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_login Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_name(self,session,user_id,last_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_name=last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_logged_on_flg(self,session,user_id,logged_on_flg):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(logged_on_flg=logged_on_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_logged_on_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_login_window_enabled(self,session,user_id,login_window_enabled):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(login_window_enabled=login_window_enabled))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_login_window_enabled Error :",str(e))
            return {'status' : "ERROR"}


    def update_middle_name(self,session,user_id,middle_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(middle_name=middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_mobile_otp(self,session,user_id,mobile_otp):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mobile_otp=mobile_otp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mobile_otp Error :",str(e))
            return {'status' : "ERROR"}


    def update_mobile_otp_count(self,session,user_id,mobile_otp_count):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mobile_otp_count=mobile_otp_count))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mobile_otp_count Error :",str(e))
            return {'status' : "ERROR"}


    def update_passw_expiry_date(self,session,user_id,passw_expiry_date):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(passw_expiry_date=passw_expiry_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_passw_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_password(self,session,user_id,password):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(password=password))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_password Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferred_language(self,session,user_id,preferred_language):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferred_language=preferred_language))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferred_name(self,session,user_id,preferred_name):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferred_name=preferred_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferred_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,user_id,role_code):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_access_id(self,session,user_id,temp_view_access_id):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_access_id=temp_view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_valid_till(self,session,user_id,temp_view_valid_till):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_valid_till=temp_view_valid_till))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_currency(self,session,user_id,user_currency):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_currency=user_currency))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_currency Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cust_type(self,session,user_id,user_cust_type):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cust_type=user_cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_email(self,session,user_id,user_email):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_email=user_email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_expiry_date(self,session,user_id,user_expiry_date):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_expiry_date=user_expiry_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_nature(self,session,user_id,user_nature):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_nature=user_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_phone(self,session,user_id,user_phone):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_phone=user_phone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_phone Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_phone_cntry(self,session,user_id,user_phone_cntry):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_phone_cntry=user_phone_cntry))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_phone_cntry Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_status(self,session,user_id,user_status):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_status=user_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_type(self,session,user_id,user_type):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_type=user_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_view_access_id(self,session,user_id,view_access_id):
        try:
            session.query(UserDtl).filter_by(
                org_id=self.org_id,
                			if user_id:
				query = query.filter(UserDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(view_access_id=view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
