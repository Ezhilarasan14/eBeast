from modelnew import *
class ClsUpRoleCrncyDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_cash_dr_lim(self,session,crncy_code,role_code,cash_dr_lim):
        try:
            session.query(RoleCrncyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(RoleCrncyDtl.crncy_code== crncy_code)
			if role_code:
				query = query.filter(RoleCrncyDtl.role_code== role_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cash_dr_lim=cash_dr_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cash_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def update_clg_dr_lim(self,session,crncy_code,role_code,clg_dr_lim):
        try:
            session.query(RoleCrncyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(RoleCrncyDtl.crncy_code== crncy_code)
			if role_code:
				query = query.filter(RoleCrncyDtl.role_code== role_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(clg_dr_lim=clg_dr_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_clg_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def update_xfer_dr_lim(self,session,crncy_code,role_code,xfer_dr_lim):
        try:
            session.query(RoleCrncyDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(RoleCrncyDtl.crncy_code== crncy_code)
			if role_code:
				query = query.filter(RoleCrncyDtl.role_code== role_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(xfer_dr_lim=xfer_dr_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_xfer_dr_lim Error :",str(e))
            return {'status' : "ERROR"}
