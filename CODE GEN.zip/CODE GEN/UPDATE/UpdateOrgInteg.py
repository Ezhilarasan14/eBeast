from modelnew import *
class ClsUpOrgInteg:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_api_key(self,session,org_integ_id,api_key):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_key=api_key))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_key Error :",str(e))
            return {'status' : "ERROR"}


    def update_api_user(self,session,org_integ_id,api_user):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_user=api_user))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_user Error :",str(e))
            return {'status' : "ERROR"}


    def update_crncy_code(self,session,org_integ_id,crncy_code):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_dep_on(self,session,org_integ_id,dep_on):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dep_on=dep_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dep_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_int_type(self,session,org_integ_id,int_type):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(int_type=int_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_int_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_integ_name(self,session,org_integ_id,integ_name):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(integ_name=integ_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_integ_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_integ_type(self,session,org_integ_id,integ_type):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(integ_type=integ_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_integ_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_integ_url(self,session,org_integ_id,integ_url):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(integ_url=integ_url))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_integ_url Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_after_before(self,session,org_integ_id,is_after_before):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_after_before=is_after_before))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_after_before Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_api_revokable(self,session,org_integ_id,is_api_revokable):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_api_revokable=is_api_revokable))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_api_revokable Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_from(self,session,org_integ_id,org_from):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_from=org_from))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_from Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_code(self,session,org_integ_id,prod_code):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_code=prod_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_name(self,session,org_integ_id,sys_name):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_name=sys_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_action(self,session,org_integ_id,trigger_action):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_action=trigger_action))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_action Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_event(self,session,org_integ_id,trigger_event):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_event=trigger_event))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_event Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_seq(self,session,org_integ_id,trigger_seq):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_seq=trigger_seq))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_seq Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_step(self,session,org_integ_id,trigger_step):
        try:
            session.query(OrgInteg).filter_by(
                org_id=self.org_id,
                			if org_integ_id:
				query = query.filter(OrgInteg.org_integ_id== org_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_step=trigger_step))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_step Error :",str(e))
            return {'status' : "ERROR"}
