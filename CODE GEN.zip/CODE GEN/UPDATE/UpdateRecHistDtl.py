from modelnew import *
class ClsUpRecHistDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_crncy_code(self,session,cust_id,finserv_id,prod_code,crncy_code):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_limit(self,session,cust_id,finserv_id,prod_code,entity_limit):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_limit=entity_limit))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_limit Error :",str(e))
            return {'status' : "ERROR"}


    def update_owned_products(self,session,cust_id,finserv_id,prod_code,owned_products):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(owned_products=owned_products))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_owned_products Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_nature(self,session,cust_id,finserv_id,prod_code,prod_nature):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_nature=prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_sub_type(self,session,cust_id,finserv_id,prod_code,prod_sub_type):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_sub_type=prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_type(self,session,cust_id,finserv_id,prod_code,prod_type):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_type=prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_reco_action_status(self,session,cust_id,finserv_id,prod_code,reco_action_status):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reco_action_status=reco_action_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reco_action_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_reco_as_on(self,session,cust_id,finserv_id,prod_code,reco_as_on):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reco_as_on=reco_as_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reco_as_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_reco_reject_reason(self,session,cust_id,finserv_id,prod_code,reco_reject_reason):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reco_reject_reason=reco_reject_reason))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reco_reject_reason Error :",str(e))
            return {'status' : "ERROR"}


    def update_reco_srl_num(self,session,cust_id,finserv_id,prod_code,reco_srl_num):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reco_srl_num=reco_srl_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reco_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_score(self,session,cust_id,finserv_id,prod_code,score):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(score=score))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_score Error :",str(e))
            return {'status' : "ERROR"}


    def update_steer_coeff(self,session,cust_id,finserv_id,prod_code,steer_coeff):
        try:
            session.query(RecHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(RecHistDtl.cust_id== cust_id)
			if finserv_id:
				query = query.filter(RecHistDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(RecHistDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(steer_coeff=steer_coeff))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_steer_coeff Error :",str(e))
            return {'status' : "ERROR"}
