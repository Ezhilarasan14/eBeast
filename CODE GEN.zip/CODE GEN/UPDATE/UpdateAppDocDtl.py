from modelnew import *
class ClsUpAppDocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,doc_id,application_id):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_doc_host(self,session,doc_id,back_doc_host):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_doc_host=back_doc_host))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_doc_host Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_doc_path(self,session,doc_id,back_doc_path):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_doc_path=back_doc_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_file_name(self,session,doc_id,back_file_name):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_file_name=back_file_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_file_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_obj_cont(self,session,doc_id,back_obj_cont):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_obj_cont=back_obj_cont))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_obj_cont Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_obj_det_content(self,session,doc_id,back_obj_det_content):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_obj_det_content=back_obj_det_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_obj_det_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_ocr_content(self,session,doc_id,back_ocr_content):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_ocr_content=back_ocr_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_ocr_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_back_ocr_extract_list(self,session,doc_id,back_ocr_extract_list):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_ocr_extract_list=back_ocr_extract_list))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_ocr_extract_list Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,doc_id,cust_id):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_code(self,session,doc_id,doc_code):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_code=doc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_host(self,session,doc_id,doc_host):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_host=doc_host))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_host Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_number(self,session,doc_id,doc_number):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_number=doc_number))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_number Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_path(self,session,doc_id,doc_path):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_path=doc_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_src(self,session,doc_id,doc_src):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_src=doc_src))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_src Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_type(self,session,doc_id,doc_type):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_type=doc_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_file_name(self,session,doc_id,file_name):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(file_name=file_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_file_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_front_obj_cont(self,session,doc_id,front_obj_cont):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(front_obj_cont=front_obj_cont))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_front_obj_cont Error :",str(e))
            return {'status' : "ERROR"}


    def update_img_filename(self,session,doc_id,img_filename):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(img_filename=img_filename))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_img_filename Error :",str(e))
            return {'status' : "ERROR"}


    def update_img_match_score(self,session,doc_id,img_match_score):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(img_match_score=img_match_score))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_img_match_score Error :",str(e))
            return {'status' : "ERROR"}


    def update_manual_status(self,session,doc_id,manual_status):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(manual_status=manual_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_manual_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_obj_det_content(self,session,doc_id,obj_det_content):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(obj_det_content=obj_det_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_obj_det_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_ocr_content(self,session,doc_id,ocr_content):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ocr_content=ocr_content))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ocr_content Error :",str(e))
            return {'status' : "ERROR"}


    def update_ocr_extract_list(self,session,doc_id,ocr_extract_list):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ocr_extract_list=ocr_extract_list))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ocr_extract_list Error :",str(e))
            return {'status' : "ERROR"}


    def update_ocr_status(self,session,doc_id,ocr_status):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ocr_status=ocr_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ocr_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_purpose_of_doc(self,session,doc_id,purpose_of_doc):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(purpose_of_doc=purpose_of_doc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_purpose_of_doc Error :",str(e))
            return {'status' : "ERROR"}


    def update_remarks(self,session,doc_id,remarks):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remarks=remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_request_id(self,session,doc_id,request_id):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request_id=request_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_system_status(self,session,doc_id,system_status):
        try:
            session.query(AppDocDtl).filter_by(
                org_id=self.org_id,
                			if doc_id:
				query = query.filter(AppDocDtl.doc_id== doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(system_status=system_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_system_status Error :",str(e))
            return {'status' : "ERROR"}
