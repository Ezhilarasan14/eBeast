from modelnew import *
class ClsUpDailyTranDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_Orig_bank_code(self,session,int_tran_id,Orig_bank_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Orig_bank_code=Orig_bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Orig_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_Orig_branch_code(self,session,int_tran_id,Orig_branch_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Orig_branch_code=Orig_branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Orig_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_Orig_ifsc_code(self,session,int_tran_id,Orig_ifsc_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Orig_ifsc_code=Orig_ifsc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Orig_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_bank_id(self,session,int_tran_id,bank_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(bank_id=bank_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_bank_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_ben_acct_num(self,session,int_tran_id,ben_acct_num):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ben_acct_num=ben_acct_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ben_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_ben_bank_code(self,session,int_tran_id,ben_bank_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ben_bank_code=ben_bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ben_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_ben_branch_code(self,session,int_tran_id,ben_branch_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ben_branch_code=ben_branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ben_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_ben_ifsc_code(self,session,int_tran_id,ben_ifsc_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ben_ifsc_code=ben_ifsc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ben_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_id(self,session,int_tran_id,br_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_id=br_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,int_tran_id,cust_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_int_id(self,session,int_tran_id,entity_int_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_int_id=entity_int_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_int_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_instr_num(self,session,int_tran_id,instr_num):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(instr_num=instr_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_instr_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_instr_type(self,session,int_tran_id,instr_type):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(instr_type=instr_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_instr_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_merchant_cat_code(self,session,int_tran_id,merchant_cat_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(merchant_cat_code=merchant_cat_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_merchant_cat_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_sys_cat_id(self,session,int_tran_id,parent_sys_cat_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_sys_cat_id=parent_sys_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_user_cat_id(self,session,int_tran_id,parent_user_cat_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_user_cat_id=parent_user_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_user_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_part_tran_srl_num(self,session,int_tran_id,part_tran_srl_num):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(part_tran_srl_num=part_tran_srl_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_part_tran_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_part_tran_type(self,session,int_tran_id,part_tran_type):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(part_tran_type=part_tran_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_part_tran_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_pstd_flg(self,session,int_tran_id,pstd_flg):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pstd_flg=pstd_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pstd_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_rate(self,session,int_tran_id,rate):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rate=rate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rate Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_amt(self,session,int_tran_id,ref_amt):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_amt=ref_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_crncy_code(self,session,int_tran_id,ref_crncy_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_crncy_code=ref_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_si_exec_date(self,session,int_tran_id,si_exec_date):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(si_exec_date=si_exec_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_si_exec_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_si_num(self,session,int_tran_id,si_num):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(si_num=si_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_si_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_id(self,session,int_tran_id,sys_cat_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_id=sys_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_name(self,session,int_tran_id,sys_cat_name):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_name=sys_cat_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_amt(self,session,int_tran_id,tran_amt):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_amt=tran_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_crncy_code(self,session,int_tran_id,tran_crncy_code):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_crncy_code=tran_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_date(self,session,int_tran_id,tran_date):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_date=tran_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_id(self,session,int_tran_id,tran_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_id=tran_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_particular_1(self,session,int_tran_id,tran_particular_1):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_particular_1=tran_particular_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_particular_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_particular_2(self,session,int_tran_id,tran_particular_2):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_particular_2=tran_particular_2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_particular_2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_rmks_1(self,session,int_tran_id,tran_rmks_1):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_rmks_1=tran_rmks_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_rmks_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_rmks_2(self,session,int_tran_id,tran_rmks_2):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_rmks_2=tran_rmks_2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_rmks_2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_sub_type(self,session,int_tran_id,tran_sub_type):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_sub_type=tran_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_tran_type(self,session,int_tran_id,tran_type):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tran_type=tran_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tran_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cat_id(self,session,int_tran_id,user_cat_id):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cat_id=user_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cat_name(self,session,int_tran_id,user_cat_name):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cat_name=user_cat_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_value_date(self,session,int_tran_id,value_date):
        try:
            session.query(DailyTranDtl).filter_by(
                org_id=self.org_id,
                			if int_tran_id:
				query = query.filter(DailyTranDtl.int_tran_id== int_tran_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(value_date=value_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_value_date Error :",str(e))
            return {'status' : "ERROR"}
