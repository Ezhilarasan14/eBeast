from modelnew import *
class ClsUpProductAddon:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_add_on_name(self,session,add_on_code,crncy_code,finserv_id,prod_code,add_on_name):
        try:
            session.query(ProductAddon).filter_by(
                org_id=self.org_id,
                			if add_on_code:
				query = query.filter(ProductAddon.add_on_code== add_on_code)
			if crncy_code:
				query = query.filter(ProductAddon.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductAddon.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductAddon.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(add_on_name=add_on_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_add_on_name Error :",str(e))
            return {'status' : "ERROR"}
