from modelnew import *
class ClsUpDjangoCeleryResultsTaskresult:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_content_encoding(self,session,id,content_encoding):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_encoding=content_encoding))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_encoding Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_date_created(self,session,id,date_created):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(date_created=date_created))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_date_created Error :",str(e))
            return {'status' : "ERROR"}


    def update_date_done(self,session,id,date_done):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(date_done=date_done))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_date_done Error :",str(e))
            return {'status' : "ERROR"}


    def update_meta(self,session,id,meta):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(meta=meta))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_meta Error :",str(e))
            return {'status' : "ERROR"}


    def update_periodic_task_name(self,session,id,periodic_task_name):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(periodic_task_name=periodic_task_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_periodic_task_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_result(self,session,id,result):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(result=result))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_result Error :",str(e))
            return {'status' : "ERROR"}


    def update_status(self,session,id,status):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status=status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_task_args(self,session,id,task_args):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(task_args=task_args))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_task_args Error :",str(e))
            return {'status' : "ERROR"}


    def update_task_id(self,session,id,task_id):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(task_id=task_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_task_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_task_kwargs(self,session,id,task_kwargs):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(task_kwargs=task_kwargs))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_task_kwargs Error :",str(e))
            return {'status' : "ERROR"}


    def update_task_name(self,session,id,task_name):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(task_name=task_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_task_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_traceback(self,session,id,traceback):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(traceback=traceback))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_traceback Error :",str(e))
            return {'status' : "ERROR"}


    def update_worker(self,session,id,worker):
        try:
            session.query(DjangoCeleryResultsTaskresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsTaskresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(worker=worker))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_worker Error :",str(e))
            return {'status' : "ERROR"}
