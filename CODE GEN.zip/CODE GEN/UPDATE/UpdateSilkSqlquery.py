from modelnew import *
class ClsUpSilkSqlquery:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_analysis(self,session,id,analysis):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(analysis=analysis))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_analysis Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,id,end_time):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_identifier(self,session,id,identifier):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(identifier=identifier))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_identifier Error :",str(e))
            return {'status' : "ERROR"}


    def update_query(self,session,id,query):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(query=query))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_query Error :",str(e))
            return {'status' : "ERROR"}


    def update_request(self,session,id,request):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request=request))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request Error :",str(e))
            return {'status' : "ERROR"}


    def update_request_id(self,session,id,request_id):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request_id=request_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,id,start_time):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_taken(self,session,id,time_taken):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_taken=time_taken))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_taken Error :",str(e))
            return {'status' : "ERROR"}


    def update_traceback(self,session,id,traceback):
        try:
            session.query(SilkSqlquery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkSqlquery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(traceback=traceback))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_traceback Error :",str(e))
            return {'status' : "ERROR"}
