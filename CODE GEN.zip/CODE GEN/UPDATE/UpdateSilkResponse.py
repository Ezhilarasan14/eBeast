from modelnew import *
class ClsUpSilkResponse:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_body(self,session,id,body):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(body=body))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_body Error :",str(e))
            return {'status' : "ERROR"}


    def update_encoded_headers(self,session,id,encoded_headers):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(encoded_headers=encoded_headers))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_encoded_headers Error :",str(e))
            return {'status' : "ERROR"}


    def update_raw_body(self,session,id,raw_body):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(raw_body=raw_body))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_raw_body Error :",str(e))
            return {'status' : "ERROR"}


    def update_request(self,session,id,request):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request=request))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request Error :",str(e))
            return {'status' : "ERROR"}


    def update_request_id(self,session,id,request_id):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request_id=request_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_status_code(self,session,id,status_code):
        try:
            session.query(SilkResponse).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkResponse.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status_code=status_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status_code Error :",str(e))
            return {'status' : "ERROR"}
