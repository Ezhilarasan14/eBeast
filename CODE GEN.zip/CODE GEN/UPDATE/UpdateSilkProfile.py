from modelnew import *
class ClsUpSilkProfile:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_dynamic(self,session,id,dynamic):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dynamic=dynamic))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dynamic Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_line_num(self,session,id,end_line_num):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_line_num=end_line_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_line_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,id,end_time):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_exception_raised(self,session,id,exception_raised):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(exception_raised=exception_raised))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_exception_raised Error :",str(e))
            return {'status' : "ERROR"}


    def update_file_path(self,session,id,file_path):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(file_path=file_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_file_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_func_name(self,session,id,func_name):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(func_name=func_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_func_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_line_num(self,session,id,line_num):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(line_num=line_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_line_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_name(self,session,id,name):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_request(self,session,id,request):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request=request))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request Error :",str(e))
            return {'status' : "ERROR"}


    def update_request_id(self,session,id,request_id):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request_id=request_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,id,start_time):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_taken(self,session,id,time_taken):
        try:
            session.query(SilkProfile).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfile.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_taken=time_taken))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_taken Error :",str(e))
            return {'status' : "ERROR"}
