from modelnew import *
class ClsUpRptPerm:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_role_code(self,session,rpt_perm_id,role_code):
        try:
            session.query(RptPerm).filter_by(
                org_id=self.org_id,
                			if rpt_perm_id:
				query = query.filter(RptPerm.rpt_perm_id== rpt_perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_rpt_cat(self,session,rpt_perm_id,rpt_cat):
        try:
            session.query(RptPerm).filter_by(
                org_id=self.org_id,
                			if rpt_perm_id:
				query = query.filter(RptPerm.rpt_perm_id== rpt_perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rpt_cat=rpt_cat))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rpt_cat Error :",str(e))
            return {'status' : "ERROR"}


    def update_rpt_code(self,session,rpt_perm_id,rpt_code):
        try:
            session.query(RptPerm).filter_by(
                org_id=self.org_id,
                			if rpt_perm_id:
				query = query.filter(RptPerm.rpt_perm_id== rpt_perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rpt_code=rpt_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rpt_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_rpt_dwnld(self,session,rpt_perm_id,rpt_dwnld):
        try:
            session.query(RptPerm).filter_by(
                org_id=self.org_id,
                			if rpt_perm_id:
				query = query.filter(RptPerm.rpt_perm_id== rpt_perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rpt_dwnld=rpt_dwnld))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rpt_dwnld Error :",str(e))
            return {'status' : "ERROR"}


    def update_rpt_view(self,session,rpt_perm_id,rpt_view):
        try:
            session.query(RptPerm).filter_by(
                org_id=self.org_id,
                			if rpt_perm_id:
				query = query.filter(RptPerm.rpt_perm_id== rpt_perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rpt_view=rpt_view))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rpt_view Error :",str(e))
            return {'status' : "ERROR"}
