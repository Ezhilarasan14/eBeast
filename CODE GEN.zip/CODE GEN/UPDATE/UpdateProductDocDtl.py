from modelnew import *
class ClsUpProductDocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_crncy_code(self,session,prod_doc_id,crncy_code):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_code(self,session,prod_doc_id,doc_code):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_code=doc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_src(self,session,prod_doc_id,doc_src):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_src=doc_src))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_src Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_type(self,session,prod_doc_id,doc_type):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_type=doc_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_id(self,session,prod_doc_id,finserv_id):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_id=finserv_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_mandate(self,session,prod_doc_id,mandate):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mandate=mandate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mandate Error :",str(e))
            return {'status' : "ERROR"}


    def update_num_of_docs(self,session,prod_doc_id,num_of_docs):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(num_of_docs=num_of_docs))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_num_of_docs Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_code(self,session,prod_doc_id,prod_code):
        try:
            session.query(ProductDocDtl).filter_by(
                org_id=self.org_id,
                			if prod_doc_id:
				query = query.filter(ProductDocDtl.prod_doc_id== prod_doc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_code=prod_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_code Error :",str(e))
            return {'status' : "ERROR"}
