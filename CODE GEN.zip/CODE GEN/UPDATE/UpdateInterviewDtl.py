from modelnew import *
class ClsUpInterviewDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_ans_status(self,session,application_id,call_id,ques_no,ans_status):
        try:
            session.query(InterviewDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(InterviewDtl.application_id== application_id)
			if call_id:
				query = query.filter(InterviewDtl.call_id== call_id)
			if ques_no:
				query = query.filter(InterviewDtl.ques_no== ques_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ans_status=ans_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ans_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_answer(self,session,application_id,call_id,ques_no,answer):
        try:
            session.query(InterviewDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(InterviewDtl.application_id== application_id)
			if call_id:
				query = query.filter(InterviewDtl.call_id== call_id)
			if ques_no:
				query = query.filter(InterviewDtl.ques_no== ques_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(answer=answer))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_answer Error :",str(e))
            return {'status' : "ERROR"}


    def update_question(self,session,application_id,call_id,ques_no,question):
        try:
            session.query(InterviewDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(InterviewDtl.application_id== application_id)
			if call_id:
				query = query.filter(InterviewDtl.call_id== call_id)
			if ques_no:
				query = query.filter(InterviewDtl.ques_no== ques_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(question=question))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_question Error :",str(e))
            return {'status' : "ERROR"}


    def update_remarks(self,session,application_id,call_id,ques_no,remarks):
        try:
            session.query(InterviewDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(InterviewDtl.application_id== application_id)
			if call_id:
				query = query.filter(InterviewDtl.call_id== call_id)
			if ques_no:
				query = query.filter(InterviewDtl.ques_no== ques_no)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remarks=remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remarks Error :",str(e))
            return {'status' : "ERROR"}
