from modelnew import *
class ClsUpProdStepsConfig:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_auth_matrix_code(self,session,prod_step_id,auth_matrix_code):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auth_matrix_code=auth_matrix_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_id(self,session,prod_step_id,finserv_id):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_id=finserv_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_mandatory(self,session,prod_step_id,mandatory):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mandatory=mandatory))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def update_matrix_id(self,session,prod_step_id,matrix_id):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(matrix_id=matrix_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_matrix_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_code(self,session,prod_step_id,prod_code):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_code=prod_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_crncy_code(self,session,prod_step_id,prod_crncy_code):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_crncy_code=prod_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_nature(self,session,prod_step_id,prod_nature):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_nature=prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_sub_type(self,session,prod_step_id,prod_sub_type):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_sub_type=prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_type(self,session,prod_step_id,prod_type):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_type=prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_code(self,session,prod_step_id,step_code):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_code=step_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_name(self,session,prod_step_id,step_name):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_name=step_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_num(self,session,prod_step_id,step_num):
        try:
            session.query(ProdStepsConfig).filter_by(
                org_id=self.org_id,
                			if prod_step_id:
				query = query.filter(ProdStepsConfig.prod_step_id== prod_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_num=step_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_num Error :",str(e))
            return {'status' : "ERROR"}
