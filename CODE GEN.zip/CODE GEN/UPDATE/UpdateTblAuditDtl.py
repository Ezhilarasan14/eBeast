from modelnew import *
class ClsUpTblAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_audit_srl_num(self,session,log_id,audit_srl_num):
        try:
            session.query(TblAuditDtl).filter_by(
                org_id=self.org_id,
                			if log_id:
				query = query.filter(TblAuditDtl.log_id== log_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(audit_srl_num=audit_srl_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_audit_srl_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_modified_fields(self,session,log_id,modified_fields):
        try:
            session.query(TblAuditDtl).filter_by(
                org_id=self.org_id,
                			if log_id:
				query = query.filter(TblAuditDtl.log_id== log_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(modified_fields=modified_fields))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_modified_fields Error :",str(e))
            return {'status' : "ERROR"}


    def update_operation(self,session,log_id,operation):
        try:
            session.query(TblAuditDtl).filter_by(
                org_id=self.org_id,
                			if log_id:
				query = query.filter(TblAuditDtl.log_id== log_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(operation=operation))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_operation Error :",str(e))
            return {'status' : "ERROR"}


    def update_table_key(self,session,log_id,table_key):
        try:
            session.query(TblAuditDtl).filter_by(
                org_id=self.org_id,
                			if log_id:
				query = query.filter(TblAuditDtl.log_id== log_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(table_key=table_key))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_table_key Error :",str(e))
            return {'status' : "ERROR"}


    def update_table_name(self,session,log_id,table_name):
        try:
            session.query(TblAuditDtl).filter_by(
                org_id=self.org_id,
                			if log_id:
				query = query.filter(TblAuditDtl.log_id== log_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(table_name=table_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_table_name Error :",str(e))
            return {'status' : "ERROR"}
