from modelnew import *
class ClsUpNetworkDir:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_address_1(self,session,file_source,file_type,ref_key,unq_bank_identifier,address_1):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_1=address_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_2(self,session,file_source,file_type,ref_key,unq_bank_identifier,address_2):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_2=address_2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_branch_info_1(self,session,file_source,file_type,ref_key,unq_bank_identifier,branch_info_1):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(branch_info_1=branch_info_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_branch_info_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_country_code(self,session,file_source,file_type,ref_key,unq_bank_identifier,country_code):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country_code=country_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_country_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier,country_name_1):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country_name_1=country_name_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_delta_matching_key(self,session,file_source,file_type,ref_key,unq_bank_identifier,delta_matching_key):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(delta_matching_key=delta_matching_key))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_delta_matching_key Error :",str(e))
            return {'status' : "ERROR"}


    def update_institute_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier,institute_name_1):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(institute_name_1=institute_name_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_institute_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_institute_name_2(self,session,file_source,file_type,ref_key,unq_bank_identifier,institute_name_2):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(institute_name_2=institute_name_2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_institute_name_2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_location_name_1(self,session,file_source,file_type,ref_key,unq_bank_identifier,location_name_1):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(location_name_1=location_name_1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_location_name_1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_primary_rec_flg(self,session,file_source,file_type,ref_key,unq_bank_identifier,primary_rec_flg):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(primary_rec_flg=primary_rec_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_primary_rec_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_primary_ref(self,session,file_source,file_type,ref_key,unq_bank_identifier,primary_ref):
        try:
            session.query(NetworkDir).filter_by(
                org_id=self.org_id,
                			if file_source:
				query = query.filter(NetworkDir.file_source== file_source)
			if file_type:
				query = query.filter(NetworkDir.file_type== file_type)
			if ref_key:
				query = query.filter(NetworkDir.ref_key== ref_key)
			if unq_bank_identifier:
				query = query.filter(NetworkDir.unq_bank_identifier== unq_bank_identifier)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(primary_ref=primary_ref))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_primary_ref Error :",str(e))
            return {'status' : "ERROR"}
