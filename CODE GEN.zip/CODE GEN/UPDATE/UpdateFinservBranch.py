from modelnew import *
class ClsUpFinservBranch:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_br_address1(self,session,br_id,finserv_id,br_address1):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_address1=br_address1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_address1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_address2(self,session,br_id,finserv_id,br_address2):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_address2=br_address2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_address2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_alias(self,session,br_id,finserv_id,br_alias):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_alias=br_alias))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_alias Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_bod_date(self,session,br_id,finserv_id,br_bod_date):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_bod_date=br_bod_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_cls_date(self,session,br_id,finserv_id,br_cls_date):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_cls_date=br_cls_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_code(self,session,br_id,finserv_id,br_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_code=br_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_desc(self,session,br_id,finserv_id,br_desc):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_desc=br_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_desc_alt(self,session,br_id,finserv_id,br_desc_alt):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_desc_alt=br_desc_alt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_name(self,session,br_id,finserv_id,br_name):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_name=br_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_nature(self,session,br_id,finserv_id,br_nature):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_nature=br_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_type(self,session,br_id,finserv_id,br_type):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_type=br_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_city_code(self,session,br_id,finserv_id,city_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(city_code=city_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_city_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_country_code(self,session,br_id,finserv_id,country_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country_code=country_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_home_crncy_code(self,session,br_id,finserv_id,home_crncy_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(home_crncy_code=home_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_home_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_pin_code(self,session,br_id,finserv_id,pin_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pin_code=pin_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pin_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_state_code(self,session,br_id,finserv_id,state_code):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(state_code=state_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_state_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_zone(self,session,br_id,finserv_id,time_zone):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_zone=time_zone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def update_week_begins_on(self,session,br_id,finserv_id,week_begins_on):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(week_begins_on=week_begins_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_week_begins_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_wkly_off(self,session,br_id,finserv_id,wkly_off):
        try:
            session.query(FinservBranch).filter_by(
                org_id=self.org_id,
                			if br_id:
				query = query.filter(FinservBranch.br_id== br_id)
			if finserv_id:
				query = query.filter(FinservBranch.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(wkly_off=wkly_off))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_wkly_off Error :",str(e))
            return {'status' : "ERROR"}
