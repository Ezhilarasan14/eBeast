from modelnew import *
class ClsUpApplicationDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_add_ons_opted(self,session,application_id,add_ons_opted):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(add_ons_opted=add_ons_opted))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_add_ons_opted Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_mode(self,session,application_id,app_mode):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_mode=app_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_owner(self,session,application_id,app_owner):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_owner=app_owner))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_owner Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_owner_id(self,session,application_id,app_owner_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_owner_id=app_owner_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_owner_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_owner_role(self,session,application_id,app_owner_role):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_owner_role=app_owner_role))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_owner_role Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_status(self,session,application_id,app_status):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_status=app_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_step_nxt_name(self,session,application_id,app_step_nxt_name):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_step_nxt_name=app_step_nxt_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_step_nxt_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_step_nxt_num(self,session,application_id,app_step_nxt_num):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_step_nxt_num=app_step_nxt_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_step_nxt_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied_by(self,session,application_id,applied_by):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied_by=applied_by))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied_by Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied_for_user_id(self,session,application_id,applied_for_user_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied_for_user_id=applied_for_user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied_for_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied_for_user_nature(self,session,application_id,applied_for_user_nature):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied_for_user_nature=applied_for_user_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied_for_user_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied_for_user_type(self,session,application_id,applied_for_user_type):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied_for_user_type=applied_for_user_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied_for_user_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied_on(self,session,application_id,applied_on):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied_on=applied_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_applying_prod_code(self,session,application_id,applying_prod_code):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applying_prod_code=applying_prod_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applying_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_applying_prod_nature(self,session,application_id,applying_prod_nature):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applying_prod_nature=applying_prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applying_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_applying_prod_sub_type(self,session,application_id,applying_prod_sub_type):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applying_prod_sub_type=applying_prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applying_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_applying_prod_type(self,session,application_id,applying_prod_type):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applying_prod_type=applying_prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applying_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_applying_user_id(self,session,application_id,applying_user_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applying_user_id=applying_user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applying_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cam_org_img(self,session,application_id,cam_org_img):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cam_org_img=cam_org_img))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cam_org_img Error :",str(e))
            return {'status' : "ERROR"}


    def update_captured_video(self,session,application_id,captured_video):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(captured_video=captured_video))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_captured_video Error :",str(e))
            return {'status' : "ERROR"}


    def update_crncy_code(self,session,application_id,crncy_code):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_deposit_amount(self,session,application_id,deposit_amount):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(deposit_amount=deposit_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_deposit_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_emi_amount(self,session,application_id,emi_amount):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(emi_amount=emi_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_emi_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_id(self,session,application_id,entity_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_id=entity_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_status(self,session,application_id,entity_status):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_status=entity_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_match_distance(self,session,application_id,face_match_distance):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_match_distance=face_match_distance))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_match_distance Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_match_score(self,session,application_id,face_match_score):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_match_score=face_match_score))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_match_score Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_id(self,session,application_id,finserv_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_id=finserv_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_installment_freq(self,session,application_id,installment_freq):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(installment_freq=installment_freq))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_installment_freq Error :",str(e))
            return {'status' : "ERROR"}


    def update_int_rate(self,session,application_id,int_rate):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(int_rate=int_rate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_int_rate Error :",str(e))
            return {'status' : "ERROR"}


    def update_loan_amount(self,session,application_id,loan_amount):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(loan_amount=loan_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_loan_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_det(self,session,application_id,otp_det):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_det=otp_det))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_det Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_gen(self,session,application_id,otp_gen):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_gen=otp_gen))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_gen Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_application_id(self,session,application_id,parent_application_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_application_id=parent_application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_pdf_path(self,session,application_id,pdf_path):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pdf_path=pdf_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pdf_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_processed_video(self,session,application_id,processed_video):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(processed_video=processed_video))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_processed_video Error :",str(e))
            return {'status' : "ERROR"}


    def update_request_id(self,session,application_id,request_id):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request_id=request_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sign_remarks(self,session,application_id,sign_remarks):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sign_remarks=sign_remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sign_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_sign_status(self,session,application_id,sign_status):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sign_status=sign_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sign_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_signature(self,session,application_id,signature):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(signature=signature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_signature Error :",str(e))
            return {'status' : "ERROR"}


    def update_tenure(self,session,application_id,tenure):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tenure=tenure))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tenure Error :",str(e))
            return {'status' : "ERROR"}


    def update_verification_mode(self,session,application_id,verification_mode):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(verification_mode=verification_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_verification_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_video_status(self,session,application_id,video_status):
        try:
            session.query(ApplicationDtl).filter_by(
                org_id=self.org_id,
                			if application_id:
				query = query.filter(ApplicationDtl.application_id== application_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(video_status=video_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_video_status Error :",str(e))
            return {'status' : "ERROR"}
