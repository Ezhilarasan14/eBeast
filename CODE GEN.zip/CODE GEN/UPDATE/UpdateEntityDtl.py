from modelnew import *
class ClsUpEntityDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_acc_added_type(self,session,bank_id,entity_id,entity_int_id,acc_added_type):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(acc_added_type=acc_added_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_acc_added_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_aggregation_source(self,session,bank_id,entity_id,entity_int_id,aggregation_source):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(aggregation_source=aggregation_source))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_aggregation_source Error :",str(e))
            return {'status' : "ERROR"}


    def update_asset_category(self,session,bank_id,entity_id,entity_int_id,asset_category):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(asset_category=asset_category))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_asset_category Error :",str(e))
            return {'status' : "ERROR"}


    def update_available_balance(self,session,bank_id,entity_id,entity_int_id,available_balance):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(available_balance=available_balance))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_available_balance Error :",str(e))
            return {'status' : "ERROR"}


    def update_bank_code(self,session,bank_id,entity_id,entity_int_id,bank_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(bank_code=bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_bank_name(self,session,bank_id,entity_id,entity_int_id,bank_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(bank_name=bank_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_branch_code(self,session,bank_id,entity_id,entity_int_id,branch_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(branch_code=branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_branch_name(self,session,bank_id,entity_id,entity_int_id,branch_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(branch_name=branch_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_branch_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_chq_opt_flg(self,session,bank_id,entity_id,entity_int_id,chq_opt_flg):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(chq_opt_flg=chq_opt_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_chq_opt_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_bank_code(self,session,bank_id,entity_id,entity_int_id,coll_acct_bank_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_bank_code=coll_acct_bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_branch_code(self,session,bank_id,entity_id,entity_int_id,coll_acct_branch_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_branch_code=coll_acct_branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_ind(self,session,bank_id,entity_id,entity_int_id,coll_acct_ind):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_ind=coll_acct_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_name(self,session,bank_id,entity_id,entity_int_id,coll_acct_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_name=coll_acct_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_num(self,session,bank_id,entity_id,entity_int_id,coll_acct_num):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_num=coll_acct_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_acct_swift_code(self,session,bank_id,entity_id,entity_int_id,coll_acct_swift_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_acct_swift_code=coll_acct_swift_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_acct_swift_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_coll_mode_ind(self,session,bank_id,entity_id,entity_int_id,coll_mode_ind):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coll_mode_ind=coll_mode_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coll_mode_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_crncy_code(self,session,bank_id,entity_id,entity_int_id,crncy_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,bank_id,entity_id,entity_int_id,cust_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_eff_interest_rate(self,session,bank_id,entity_id,entity_int_id,eff_interest_rate):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(eff_interest_rate=eff_interest_rate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_eff_interest_rate Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_alt_name(self,session,bank_id,entity_id,entity_int_id,entity_alt_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_alt_name=entity_alt_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_alt_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_branch(self,session,bank_id,entity_id,entity_int_id,entity_branch):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_branch=entity_branch))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_branch Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_cash_dr_lim(self,session,bank_id,entity_id,entity_int_id,entity_cash_dr_lim):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_cash_dr_lim=entity_cash_dr_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_cash_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_cls_date(self,session,bank_id,entity_id,entity_int_id,entity_cls_date):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_cls_date=entity_cls_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_cls_flg(self,session,bank_id,entity_id,entity_int_id,entity_cls_flg):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_cls_flg=entity_cls_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_cls_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_curr_bal(self,session,bank_id,entity_id,entity_int_id,entity_curr_bal):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_curr_bal=entity_curr_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_curr_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_cust_type(self,session,bank_id,entity_id,entity_int_id,entity_cust_type):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_cust_type=entity_cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_ext_id(self,session,bank_id,entity_id,entity_int_id,entity_ext_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_ext_id=entity_ext_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_ext_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_limit(self,session,bank_id,entity_id,entity_int_id,entity_limit):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_limit=entity_limit))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_limit Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_name(self,session,bank_id,entity_id,entity_int_id,entity_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_name=entity_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_nature(self,session,bank_id,entity_id,entity_int_id,entity_nature):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_nature=entity_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_nick_name(self,session,bank_id,entity_id,entity_int_id,entity_nick_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_nick_name=entity_nick_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_nick_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_open_date(self,session,bank_id,entity_id,entity_int_id,entity_open_date):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_open_date=entity_open_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_open_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_pd_days(self,session,bank_id,entity_id,entity_int_id,entity_pd_days):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_pd_days=entity_pd_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_pd_days Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_pd_times(self,session,bank_id,entity_id,entity_int_id,entity_pd_times):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_pd_times=entity_pd_times))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_pd_times Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_status(self,session,bank_id,entity_id,entity_int_id,entity_status):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_status=entity_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_xfer_dr_lim(self,session,bank_id,entity_id,entity_int_id,entity_xfer_dr_lim):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_xfer_dr_lim=entity_xfer_dr_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_xfer_dr_lim Error :",str(e))
            return {'status' : "ERROR"}


    def update_goal_id(self,session,bank_id,entity_id,entity_int_id,goal_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(goal_id=goal_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_goal_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_iban_num(self,session,bank_id,entity_id,entity_int_id,iban_num):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iban_num=iban_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iban_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_ifsc_code(self,session,bank_id,entity_id,entity_int_id,ifsc_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ifsc_code=ifsc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ifsc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_int_ext_flg(self,session,bank_id,entity_id,entity_int_id,int_ext_flg):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(int_ext_flg=int_ext_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_int_ext_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_maturity_date(self,session,bank_id,entity_id,entity_int_id,maturity_date):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(maturity_date=maturity_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_maturity_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_bank_code(self,session,bank_id,entity_id,entity_int_id,pay_acct_bank_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_bank_code=pay_acct_bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_branch_code(self,session,bank_id,entity_id,entity_int_id,pay_acct_branch_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_branch_code=pay_acct_branch_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_branch_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_ind(self,session,bank_id,entity_id,entity_int_id,pay_acct_ind):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_ind=pay_acct_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_name(self,session,bank_id,entity_id,entity_int_id,pay_acct_name):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_name=pay_acct_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_num(self,session,bank_id,entity_id,entity_int_id,pay_acct_num):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_num=pay_acct_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_acct_swift_code(self,session,bank_id,entity_id,entity_int_id,pay_acct_swift_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_acct_swift_code=pay_acct_swift_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_acct_swift_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_pay_mode_ind(self,session,bank_id,entity_id,entity_int_id,pay_mode_ind):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pay_mode_ind=pay_mode_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pay_mode_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_primary_rm_id(self,session,bank_id,entity_id,entity_int_id,primary_rm_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(primary_rm_id=primary_rm_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_primary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_code(self,session,bank_id,entity_id,entity_int_id,product_code):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_code=product_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_type(self,session,bank_id,entity_id,entity_int_id,product_type):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_type=product_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_providerId(self,session,bank_id,entity_id,entity_int_id,providerId):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(providerId=providerId))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_providerId Error :",str(e))
            return {'status' : "ERROR"}


    def update_provider_account_id(self,session,bank_id,entity_id,entity_int_id,provider_account_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(provider_account_id=provider_account_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_provider_account_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_rem_installments(self,session,bank_id,entity_id,entity_int_id,rem_installments):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rem_installments=rem_installments))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rem_installments Error :",str(e))
            return {'status' : "ERROR"}


    def update_requestId(self,session,bank_id,entity_id,entity_int_id,requestId):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(requestId=requestId))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_requestId Error :",str(e))
            return {'status' : "ERROR"}


    def update_secondary_rm_id(self,session,bank_id,entity_id,entity_int_id,secondary_rm_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(secondary_rm_id=secondary_rm_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_secondary_rm_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_opt_flg(self,session,bank_id,entity_id,entity_int_id,sweep_opt_flg):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_opt_flg=sweep_opt_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_opt_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_pool_id(self,session,bank_id,entity_id,entity_int_id,sweep_pool_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_pool_id=sweep_pool_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_pool_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_tot_installments(self,session,bank_id,entity_id,entity_int_id,tot_installments):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tot_installments=tot_installments))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tot_installments Error :",str(e))
            return {'status' : "ERROR"}


    def update_total_due_amt(self,session,bank_id,entity_id,entity_int_id,total_due_amt):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(total_due_amt=total_due_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_total_due_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_total_limit(self,session,bank_id,entity_id,entity_int_id,total_limit):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(total_limit=total_limit))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_total_limit Error :",str(e))
            return {'status' : "ERROR"}


    def update_upcoming_due_amt(self,session,bank_id,entity_id,entity_int_id,upcoming_due_amt):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(upcoming_due_amt=upcoming_due_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_upcoming_due_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_upcoming_due_date(self,session,bank_id,entity_id,entity_int_id,upcoming_due_date):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(upcoming_due_date=upcoming_due_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_upcoming_due_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_upi_id(self,session,bank_id,entity_id,entity_int_id,upi_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(upi_id=upi_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_upi_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,bank_id,entity_id,entity_int_id,user_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_yodlee_account_id(self,session,bank_id,entity_id,entity_int_id,yodlee_account_id):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(yodlee_account_id=yodlee_account_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_yodlee_account_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_yodlee_status(self,session,bank_id,entity_id,entity_int_id,yodlee_status):
        try:
            session.query(EntityDtl).filter_by(
                org_id=self.org_id,
                			if bank_id:
				query = query.filter(EntityDtl.bank_id== bank_id)
			if entity_id:
				query = query.filter(EntityDtl.entity_id== entity_id)
			if entity_int_id:
				query = query.filter(EntityDtl.entity_int_id== entity_int_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(yodlee_status=yodlee_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}
