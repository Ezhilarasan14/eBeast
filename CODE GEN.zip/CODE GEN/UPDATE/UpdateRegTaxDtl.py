from modelnew import *
class ClsUpRegTaxDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_cust_id(self,session,tax_code,tax_name,tax_type,cust_id):
        try:
            session.query(RegTaxDtl).filter_by(
                org_id=self.org_id,
                			if tax_code:
				query = query.filter(RegTaxDtl.tax_code== tax_code)
			if tax_name:
				query = query.filter(RegTaxDtl.tax_name== tax_name)
			if tax_type:
				query = query.filter(RegTaxDtl.tax_type== tax_type)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_desc(self,session,tax_code,tax_name,tax_type,tax_desc):
        try:
            session.query(RegTaxDtl).filter_by(
                org_id=self.org_id,
                			if tax_code:
				query = query.filter(RegTaxDtl.tax_code== tax_code)
			if tax_name:
				query = query.filter(RegTaxDtl.tax_name== tax_name)
			if tax_type:
				query = query.filter(RegTaxDtl.tax_type== tax_type)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_desc=tax_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_percentage(self,session,tax_code,tax_name,tax_type,tax_percentage):
        try:
            session.query(RegTaxDtl).filter_by(
                org_id=self.org_id,
                			if tax_code:
				query = query.filter(RegTaxDtl.tax_code== tax_code)
			if tax_name:
				query = query.filter(RegTaxDtl.tax_name== tax_name)
			if tax_type:
				query = query.filter(RegTaxDtl.tax_type== tax_type)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_percentage=tax_percentage))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_percentage Error :",str(e))
            return {'status' : "ERROR"}
