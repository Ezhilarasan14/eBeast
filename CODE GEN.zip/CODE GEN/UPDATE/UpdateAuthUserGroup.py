from modelnew import *
class ClsUpAuthUserGroup:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_group(self,session,id,group):
        try:
            session.query(AuthUserGroup).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUserGroup.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group=group))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group Error :",str(e))
            return {'status' : "ERROR"}


    def update_group_id(self,session,id,group_id):
        try:
            session.query(AuthUserGroup).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUserGroup.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group_id=group_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_user(self,session,id,user):
        try:
            session.query(AuthUserGroup).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUserGroup.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user=user))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,id,user_id):
        try:
            session.query(AuthUserGroup).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUserGroup.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
