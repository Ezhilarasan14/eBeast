from modelnew import *
class ClsUpDjangoCeleryResultsGroupresult:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_content_encoding(self,session,id,content_encoding):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_encoding=content_encoding))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_encoding Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_date_created(self,session,id,date_created):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(date_created=date_created))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_date_created Error :",str(e))
            return {'status' : "ERROR"}


    def update_date_done(self,session,id,date_done):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(date_done=date_done))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_date_done Error :",str(e))
            return {'status' : "ERROR"}


    def update_group_id(self,session,id,group_id):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group_id=group_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_result(self,session,id,result):
        try:
            session.query(DjangoCeleryResultsGroupresult).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsGroupresult.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(result=result))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_result Error :",str(e))
            return {'status' : "ERROR"}
