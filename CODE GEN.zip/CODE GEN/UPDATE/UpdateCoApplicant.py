from modelnew import *
class ClsUpCoApplicant:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_app_status(self,session,co_applicant_id,app_status):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_status=app_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_applicant_type(self,session,co_applicant_id,applicant_type):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applicant_type=applicant_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applicant_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_application_id(self,session,co_applicant_id,application_id):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cam_org_img(self,session,co_applicant_id,cam_org_img):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cam_org_img=cam_org_img))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cam_org_img Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,co_applicant_id,cust_id):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_signature(self,session,co_applicant_id,signature):
        try:
            session.query(CoApplicant).filter_by(
                org_id=self.org_id,
                			if co_applicant_id:
				query = query.filter(CoApplicant.co_applicant_id== co_applicant_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(signature=signature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_signature Error :",str(e))
            return {'status' : "ERROR"}
