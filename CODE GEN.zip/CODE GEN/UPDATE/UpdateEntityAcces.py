from modelnew import *
class ClsUpEntityAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_access_id(self,session,entity_int_id,finserv_id,access_id):
        try:
            session.query(EntityAcces).filter_by(
                org_id=self.org_id,
                			if entity_int_id:
				query = query.filter(EntityAcces.entity_int_id== entity_int_id)
			if finserv_id:
				query = query.filter(EntityAcces.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(access_id=access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,entity_int_id,finserv_id,cust_id):
        try:
            session.query(EntityAcces).filter_by(
                org_id=self.org_id,
                			if entity_int_id:
				query = query.filter(EntityAcces.entity_int_id== entity_int_id)
			if finserv_id:
				query = query.filter(EntityAcces.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,entity_int_id,finserv_id,user_id):
        try:
            session.query(EntityAcces).filter_by(
                org_id=self.org_id,
                			if entity_int_id:
				query = query.filter(EntityAcces.entity_int_id== entity_int_id)
			if finserv_id:
				query = query.filter(EntityAcces.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
