from modelnew import *
class ClsUpPreprocHistDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_age_range(self,session,cust_id,preproc_as_on,preproc_srl_num,age_range):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(age_range=age_range))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_age_range Error :",str(e))
            return {'status' : "ERROR"}


    def update_annual_sal_crncy(self,session,cust_id,preproc_as_on,preproc_srl_num,annual_sal_crncy):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(annual_sal_crncy=annual_sal_crncy))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_annual_sal_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def update_annual_salary_range(self,session,cust_id,preproc_as_on,preproc_srl_num,annual_salary_range):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(annual_salary_range=annual_salary_range))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_annual_salary_range Error :",str(e))
            return {'status' : "ERROR"}


    def update_blacklist_flg(self,session,cust_id,preproc_as_on,preproc_srl_num,blacklist_flg):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(blacklist_flg=blacklist_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_blacklist_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_type(self,session,cust_id,preproc_as_on,preproc_srl_num,cust_type):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_type=cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_employment_status(self,session,cust_id,preproc_as_on,preproc_srl_num,employment_status):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employment_status=employment_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employment_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_fin_quality(self,session,cust_id,preproc_as_on,preproc_srl_num,fin_quality):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fin_quality=fin_quality))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fin_quality Error :",str(e))
            return {'status' : "ERROR"}


    def update_gender(self,session,cust_id,preproc_as_on,preproc_srl_num,gender):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gender=gender))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gender Error :",str(e))
            return {'status' : "ERROR"}


    def update_marital_status(self,session,cust_id,preproc_as_on,preproc_srl_num,marital_status):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(marital_status=marital_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_minor_flg(self,session,cust_id,preproc_as_on,preproc_srl_num,minor_flg):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minor_flg=minor_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minor_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_nre_flg(self,session,cust_id,preproc_as_on,preproc_srl_num,nre_flg):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(nre_flg=nre_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_nre_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_region(self,session,cust_id,preproc_as_on,preproc_srl_num,region):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(region=region))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_region Error :",str(e))
            return {'status' : "ERROR"}


    def update_segment(self,session,cust_id,preproc_as_on,preproc_srl_num,segment):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(segment=segment))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_segment Error :",str(e))
            return {'status' : "ERROR"}


    def update_staff_flg(self,session,cust_id,preproc_as_on,preproc_srl_num,staff_flg):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(staff_flg=staff_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_staff_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_state(self,session,cust_id,preproc_as_on,preproc_srl_num,state):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(state=state))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_state Error :",str(e))
            return {'status' : "ERROR"}


    def update_suspend_flg(self,session,cust_id,preproc_as_on,preproc_srl_num,suspend_flg):
        try:
            session.query(PreprocHistDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocHistDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocHistDtl.preproc_as_on== preproc_as_on)
			if preproc_srl_num:
				query = query.filter(PreprocHistDtl.preproc_srl_num== preproc_srl_num)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(suspend_flg=suspend_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_suspend_flg Error :",str(e))
            return {'status' : "ERROR"}
