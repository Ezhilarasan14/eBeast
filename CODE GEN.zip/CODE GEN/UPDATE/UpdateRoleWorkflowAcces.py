from modelnew import *
class ClsUpRoleWorkflowAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_crncy_code(self,session,role_wf_id,crncy_code):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(crncy_code=crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_id(self,session,role_wf_id,finserv_id):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_id=finserv_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_code(self,session,role_wf_id,prod_code):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_code=prod_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_nature(self,session,role_wf_id,prod_nature):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_nature=prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_sub_type(self,session,role_wf_id,prod_sub_type):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_sub_type=prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_type(self,session,role_wf_id,prod_type):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_type=prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,role_wf_id,role_code):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_code(self,session,role_wf_id,step_code):
        try:
            session.query(RoleWorkflowAcces).filter_by(
                org_id=self.org_id,
                			if role_wf_id:
				query = query.filter(RoleWorkflowAcces.role_wf_id== role_wf_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_code=step_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_code Error :",str(e))
            return {'status' : "ERROR"}
