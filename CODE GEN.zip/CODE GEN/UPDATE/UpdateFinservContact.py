from modelnew import *
class ClsUpFinservContact:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_Plot_num(self,session,contact_sub_type,contact_type,finserv_id,Plot_num):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Plot_num=Plot_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Plot_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_format(self,session,contact_sub_type,contact_type,finserv_id,address_format):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_format=address_format))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_format Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_line1(self,session,contact_sub_type,contact_type,finserv_id,address_line1):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_line1=address_line1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_line1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_line2(self,session,contact_sub_type,contact_type,finserv_id,address_line2):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_line2=address_line2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_line2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_line3(self,session,contact_sub_type,contact_type,finserv_id,address_line3):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_line3=address_line3))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_line3 Error :",str(e))
            return {'status' : "ERROR"}


    def update_building_num(self,session,contact_sub_type,contact_type,finserv_id,building_num):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(building_num=building_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_building_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_city(self,session,contact_sub_type,contact_type,finserv_id,city):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(city=city))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_city Error :",str(e))
            return {'status' : "ERROR"}


    def update_country(self,session,contact_sub_type,contact_type,finserv_id,country):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country=country))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country Error :",str(e))
            return {'status' : "ERROR"}


    def update_domicle(self,session,contact_sub_type,contact_type,finserv_id,domicle):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(domicle=domicle))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_domicle Error :",str(e))
            return {'status' : "ERROR"}


    def update_email(self,session,contact_sub_type,contact_type,finserv_id,email):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email=email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_floor_no(self,session,contact_sub_type,contact_type,finserv_id,floor_no):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(floor_no=floor_no))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_floor_no Error :",str(e))
            return {'status' : "ERROR"}


    def update_locality(self,session,contact_sub_type,contact_type,finserv_id,locality):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(locality=locality))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_locality Error :",str(e))
            return {'status' : "ERROR"}


    def update_phone_no(self,session,contact_sub_type,contact_type,finserv_id,phone_no):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(phone_no=phone_no))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_phone_no Error :",str(e))
            return {'status' : "ERROR"}


    def update_phoneno_countrycode(self,session,contact_sub_type,contact_type,finserv_id,phoneno_countrycode):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(phoneno_countrycode=phoneno_countrycode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_phoneno_countrycode Error :",str(e))
            return {'status' : "ERROR"}


    def update_phoneno_localcode(self,session,contact_sub_type,contact_type,finserv_id,phoneno_localcode):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(phoneno_localcode=phoneno_localcode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_phoneno_localcode Error :",str(e))
            return {'status' : "ERROR"}


    def update_pin(self,session,contact_sub_type,contact_type,finserv_id,pin):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pin=pin))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pin Error :",str(e))
            return {'status' : "ERROR"}


    def update_premise_name(self,session,contact_sub_type,contact_type,finserv_id,premise_name):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(premise_name=premise_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_premise_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_region(self,session,contact_sub_type,contact_type,finserv_id,region):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(region=region))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_region Error :",str(e))
            return {'status' : "ERROR"}


    def update_state(self,session,contact_sub_type,contact_type,finserv_id,state):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(state=state))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_state Error :",str(e))
            return {'status' : "ERROR"}


    def update_street_name(self,session,contact_sub_type,contact_type,finserv_id,street_name):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(street_name=street_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_street_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_street_no(self,session,contact_sub_type,contact_type,finserv_id,street_no):
        try:
            session.query(FinservContact).filter_by(
                org_id=self.org_id,
                			if contact_sub_type:
				query = query.filter(FinservContact.contact_sub_type== contact_sub_type)
			if contact_type:
				query = query.filter(FinservContact.contact_type== contact_type)
			if finserv_id:
				query = query.filter(FinservContact.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(street_no=street_no))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_street_no Error :",str(e))
            return {'status' : "ERROR"}
