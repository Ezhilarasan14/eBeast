from modelnew import *
class ClsUpRolePermissionDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_checker(self,session,perm_id,checker):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(checker=checker))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_checker Error :",str(e))
            return {'status' : "ERROR"}


    def update_modifier(self,session,perm_id,modifier):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(modifier=modifier))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_modifier Error :",str(e))
            return {'status' : "ERROR"}


    def update_module(self,session,perm_id,module):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(module=module))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_module Error :",str(e))
            return {'status' : "ERROR"}


    def update_reader(self,session,perm_id,reader):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reader=reader))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reader Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,perm_id,role_code):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_verifier(self,session,perm_id,verifier):
        try:
            session.query(RolePermissionDtl).filter_by(
                org_id=self.org_id,
                			if perm_id:
				query = query.filter(RolePermissionDtl.perm_id== perm_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(verifier=verifier))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_verifier Error :",str(e))
            return {'status' : "ERROR"}
