from modelnew import *
class ClsUpAuditor:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_action(self,session,id,action):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(action=action))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_action Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_object(self,session,id,content_object):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_object=content_object))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_object Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type_id(self,session,id,content_type_id):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type_id=content_type_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_field(self,session,id,field):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field=field))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field Error :",str(e))
            return {'status' : "ERROR"}


    def update_new_value(self,session,id,new_value):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(new_value=new_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_new_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_id(self,session,id,object_id):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_id=object_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_old_value(self,session,id,old_value):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(old_value=old_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_old_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_stamp(self,session,id,stamp):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(stamp=stamp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_stamp Error :",str(e))
            return {'status' : "ERROR"}


    def update_user(self,session,id,user):
        try:
            session.query(Auditor).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(Auditor.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user=user))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user Error :",str(e))
            return {'status' : "ERROR"}
