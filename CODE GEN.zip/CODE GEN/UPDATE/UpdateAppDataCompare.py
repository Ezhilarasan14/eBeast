from modelnew import *
class ClsUpAppDataCompare:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,app_step_id,doc_code,doc_type,id,info_key,application_id):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,app_step_id,doc_code,doc_type,id,info_key,cust_id):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_info_value(self,session,app_step_id,doc_code,doc_type,id,info_key,info_value):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(info_value=info_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_info_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_name(self,session,app_step_id,doc_code,doc_type,id,info_key,step_name):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_name=step_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_system_comp_status(self,session,app_step_id,doc_code,doc_type,id,info_key,system_comp_status):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(system_comp_status=system_comp_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_system_comp_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_accept_status(self,session,app_step_id,doc_code,doc_type,id,info_key,user_accept_status):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_accept_status=user_accept_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_accept_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_remarks(self,session,app_step_id,doc_code,doc_type,id,info_key,user_remarks):
        try:
            session.query(AppDataCompare).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppDataCompare.app_step_id== app_step_id)
			if doc_code:
				query = query.filter(AppDataCompare.doc_code== doc_code)
			if doc_type:
				query = query.filter(AppDataCompare.doc_type== doc_type)
			if id:
				query = query.filter(AppDataCompare.id== id)
			if info_key:
				query = query.filter(AppDataCompare.info_key== info_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_remarks=user_remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_remarks Error :",str(e))
            return {'status' : "ERROR"}
