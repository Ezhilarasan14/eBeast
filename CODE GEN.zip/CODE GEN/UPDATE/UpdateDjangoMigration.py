from modelnew import *
class ClsUpDjangoMigration:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_app(self,session,id,app):
        try:
            session.query(DjangoMigration).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoMigration.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app=app))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app Error :",str(e))
            return {'status' : "ERROR"}


    def update_applied(self,session,id,applied):
        try:
            session.query(DjangoMigration).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoMigration.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(applied=applied))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_applied Error :",str(e))
            return {'status' : "ERROR"}


    def update_name(self,session,id,name):
        try:
            session.query(DjangoMigration).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoMigration.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}
