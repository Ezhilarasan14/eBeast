from modelnew import *
class ClsUpCountryDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_cntry_code_alpha3(self,session,cntry_code,crncy_code,cntry_code_alpha3):
        try:
            session.query(CountryDtl).filter_by(
                org_id=self.org_id,
                			if cntry_code:
				query = query.filter(CountryDtl.cntry_code== cntry_code)
			if crncy_code:
				query = query.filter(CountryDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cntry_code_alpha3=cntry_code_alpha3))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cntry_code_alpha3 Error :",str(e))
            return {'status' : "ERROR"}


    def update_cntry_name(self,session,cntry_code,crncy_code,cntry_name):
        try:
            session.query(CountryDtl).filter_by(
                org_id=self.org_id,
                			if cntry_code:
				query = query.filter(CountryDtl.cntry_code== cntry_code)
			if crncy_code:
				query = query.filter(CountryDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cntry_name=cntry_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cntry_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_iso_cntry_num(self,session,cntry_code,crncy_code,iso_cntry_num):
        try:
            session.query(CountryDtl).filter_by(
                org_id=self.org_id,
                			if cntry_code:
				query = query.filter(CountryDtl.cntry_code== cntry_code)
			if crncy_code:
				query = query.filter(CountryDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iso_cntry_num=iso_cntry_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iso_cntry_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_status(self,session,cntry_code,crncy_code,status):
        try:
            session.query(CountryDtl).filter_by(
                org_id=self.org_id,
                			if cntry_code:
				query = query.filter(CountryDtl.cntry_code== cntry_code)
			if crncy_code:
				query = query.filter(CountryDtl.crncy_code== crncy_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status=status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status Error :",str(e))
            return {'status' : "ERROR"}
