from modelnew import *
class ClsUpFinservDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_cntry_code(self,session,finserv_id,cntry_code):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cntry_code=cntry_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cntry_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_name(self,session,finserv_id,finserv_name):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_name=finserv_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_finserv_type(self,session,finserv_id,finserv_type):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(finserv_type=finserv_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_finserv_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_image_path(self,session,finserv_id,image_path):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(image_path=image_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_ocr_enabled(self,session,finserv_id,ocr_enabled):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ocr_enabled=ocr_enabled))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ocr_enabled Error :",str(e))
            return {'status' : "ERROR"}


    def update_pymt_intgn(self,session,finserv_id,pymt_intgn):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pymt_intgn=pymt_intgn))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pymt_intgn Error :",str(e))
            return {'status' : "ERROR"}


    def update_sector(self,session,finserv_id,sector):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sector=sector))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sector Error :",str(e))
            return {'status' : "ERROR"}


    def update_swift_code(self,session,finserv_id,swift_code):
        try:
            session.query(FinservDtl).filter_by(
                org_id=self.org_id,
                			if finserv_id:
				query = query.filter(FinservDtl.finserv_id== finserv_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(swift_code=swift_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_swift_code Error :",str(e))
            return {'status' : "ERROR"}
