from modelnew import *
class ClsUpDjangoSession:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_expire_date(self,session,session_key,expire_date):
        try:
            session.query(DjangoSession).filter_by(
                org_id=self.org_id,
                			if session_key:
				query = query.filter(DjangoSession.session_key== session_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(expire_date=expire_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_expire_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_session_data(self,session,session_key,session_data):
        try:
            session.query(DjangoSession).filter_by(
                org_id=self.org_id,
                			if session_key:
				query = query.filter(DjangoSession.session_key== session_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(session_data=session_data))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_session_data Error :",str(e))
            return {'status' : "ERROR"}
