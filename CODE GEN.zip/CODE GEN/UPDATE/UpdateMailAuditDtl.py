from modelnew import *
class ClsUpMailAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_api_name(self,session,req_id,api_name):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_name=api_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_receiver_id(self,session,req_id,receiver_id):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(receiver_id=receiver_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_receiver_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_req_code(self,session,req_id,req_code):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(req_code=req_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_req_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_req_orig(self,session,req_id,req_orig):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(req_orig=req_orig))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_req_orig Error :",str(e))
            return {'status' : "ERROR"}


    def update_req_type(self,session,req_id,req_type):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(req_type=req_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_req_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_resp_type(self,session,req_id,resp_type):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(resp_type=resp_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_resp_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,req_id,user_id):
        try:
            session.query(MailAuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(MailAuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
