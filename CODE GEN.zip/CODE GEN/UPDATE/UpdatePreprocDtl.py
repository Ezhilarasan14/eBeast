from modelnew import *
class ClsUpPreprocDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_age_range(self,session,cust_id,preproc_as_on,age_range):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(age_range=age_range))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_age_range Error :",str(e))
            return {'status' : "ERROR"}


    def update_annual_sal_crncy(self,session,cust_id,preproc_as_on,annual_sal_crncy):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(annual_sal_crncy=annual_sal_crncy))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_annual_sal_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def update_annual_salary_range(self,session,cust_id,preproc_as_on,annual_salary_range):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(annual_salary_range=annual_salary_range))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_annual_salary_range Error :",str(e))
            return {'status' : "ERROR"}


    def update_blacklist_flg(self,session,cust_id,preproc_as_on,blacklist_flg):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(blacklist_flg=blacklist_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_blacklist_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_type(self,session,cust_id,preproc_as_on,cust_type):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_type=cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_employment_status(self,session,cust_id,preproc_as_on,employment_status):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employment_status=employment_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employment_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_fin_quality(self,session,cust_id,preproc_as_on,fin_quality):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fin_quality=fin_quality))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fin_quality Error :",str(e))
            return {'status' : "ERROR"}


    def update_gender(self,session,cust_id,preproc_as_on,gender):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gender=gender))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gender Error :",str(e))
            return {'status' : "ERROR"}


    def update_marital_status(self,session,cust_id,preproc_as_on,marital_status):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(marital_status=marital_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_minor_flg(self,session,cust_id,preproc_as_on,minor_flg):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minor_flg=minor_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minor_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_region(self,session,cust_id,preproc_as_on,region):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(region=region))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_region Error :",str(e))
            return {'status' : "ERROR"}


    def update_resident_flg(self,session,cust_id,preproc_as_on,resident_flg):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(resident_flg=resident_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_resident_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_segment(self,session,cust_id,preproc_as_on,segment):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(segment=segment))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_segment Error :",str(e))
            return {'status' : "ERROR"}


    def update_staff_flg(self,session,cust_id,preproc_as_on,staff_flg):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(staff_flg=staff_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_staff_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_state(self,session,cust_id,preproc_as_on,state):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(state=state))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_state Error :",str(e))
            return {'status' : "ERROR"}


    def update_suspend_flg(self,session,cust_id,preproc_as_on,suspend_flg):
        try:
            session.query(PreprocDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreprocDtl.cust_id== cust_id)
			if preproc_as_on:
				query = query.filter(PreprocDtl.preproc_as_on== preproc_as_on)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(suspend_flg=suspend_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_suspend_flg Error :",str(e))
            return {'status' : "ERROR"}
