from modelnew import *
class ClsUpRoleActionAcces:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_accept(self,session,action_id,accept):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(accept=accept))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_accept Error :",str(e))
            return {'status' : "ERROR"}


    def update_add_perm(self,session,action_id,add_perm):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(add_perm=add_perm))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_add_perm Error :",str(e))
            return {'status' : "ERROR"}


    def update_allocate(self,session,action_id,allocate):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(allocate=allocate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_allocate Error :",str(e))
            return {'status' : "ERROR"}


    def update_approve(self,session,action_id,approve):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(approve=approve))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_approve Error :",str(e))
            return {'status' : "ERROR"}


    def update_capture(self,session,action_id,capture):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(capture=capture))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_capture Error :",str(e))
            return {'status' : "ERROR"}


    def update_delete_perm(self,session,action_id,delete_perm):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(delete_perm=delete_perm))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_delete_perm Error :",str(e))
            return {'status' : "ERROR"}


    def update_download(self,session,action_id,download):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(download=download))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_download Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_name(self,session,action_id,entity_name):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_name=entity_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_modify_perm(self,session,action_id,modify_perm):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(modify_perm=modify_perm))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_modify_perm Error :",str(e))
            return {'status' : "ERROR"}


    def update_module(self,session,action_id,module):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(module=module))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_module Error :",str(e))
            return {'status' : "ERROR"}


    def update_recollect(self,session,action_id,recollect):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(recollect=recollect))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_recollect Error :",str(e))
            return {'status' : "ERROR"}


    def update_refer(self,session,action_id,refer):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(refer=refer))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_refer Error :",str(e))
            return {'status' : "ERROR"}


    def update_reject(self,session,action_id,reject):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reject=reject))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reject Error :",str(e))
            return {'status' : "ERROR"}


    def update_revoke(self,session,action_id,revoke):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(revoke=revoke))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_revoke Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,action_id,role_code):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_upload(self,session,action_id,upload):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(upload=upload))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_upload Error :",str(e))
            return {'status' : "ERROR"}


    def update_verify(self,session,action_id,verify):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(verify=verify))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_verify Error :",str(e))
            return {'status' : "ERROR"}


    def update_view_perm(self,session,action_id,view_perm):
        try:
            session.query(RoleActionAcces).filter_by(
                org_id=self.org_id,
                			if action_id:
				query = query.filter(RoleActionAcces.action_id== action_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(view_perm=view_perm))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_view_perm Error :",str(e))
            return {'status' : "ERROR"}
