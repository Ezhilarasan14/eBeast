from modelnew import *
class ClsUpCalendarDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_End_time(self,session,mmyyyy,End_time):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(End_time=End_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_End_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_Start_time(self,session,mmyyyy,Start_time):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Start_time=Start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_id(self,session,mmyyyy,br_id):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_id=br_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_set(self,session,mmyyyy,br_set):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_set=br_set))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_set Error :",str(e))
            return {'status' : "ERROR"}


    def update_call_duration(self,session,mmyyyy,call_duration):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(call_duration=call_duration))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_call_duration Error :",str(e))
            return {'status' : "ERROR"}


    def update_holiday(self,session,mmyyyy,holiday):
        try:
            session.query(CalendarDtl).filter_by(
                org_id=self.org_id,
                			if mmyyyy:
				query = query.filter(CalendarDtl.mmyyyy== mmyyyy)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(holiday=holiday))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_holiday Error :",str(e))
            return {'status' : "ERROR"}
