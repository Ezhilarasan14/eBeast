from modelnew import *
class ClsUpAuthToken:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_created(self,session,key,created):
        try:
            session.query(AuthToken).filter_by(
                org_id=self.org_id,
                			if key:
				query = query.filter(AuthToken.key== key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(created=created))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_created Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,key,user_id):
        try:
            session.query(AuthToken).filter_by(
                org_id=self.org_id,
                			if key:
				query = query.filter(AuthToken.key== key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
