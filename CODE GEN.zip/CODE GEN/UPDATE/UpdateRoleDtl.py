from modelnew import *
class ClsUpRoleDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_do_ref_code(self,session,role_id,do_ref_code):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(do_ref_code=do_ref_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_do_ref_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_do_ref_type(self,session,role_id,do_ref_type):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(do_ref_type=do_ref_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_do_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_hide_sensitive_data(self,session,role_id,hide_sensitive_data):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(hide_sensitive_data=hide_sensitive_data))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_hide_sensitive_data Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_customer_assistant(self,session,role_id,is_customer_assistant):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_customer_assistant=is_customer_assistant))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_customer_assistant Error :",str(e))
            return {'status' : "ERROR"}

    def update_is_super_admin(self,session,role_id,is_super_admin):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_super_admin=is_super_admin))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_super_admin Error :",str(e))
            return {'status' : "ERROR"}


    def update_limit_amount(self,session,role_id,limit_amount):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(limit_amount=limit_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_limit_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_limit_scope(self,session,role_id,limit_scope):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(limit_scope=limit_scope))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_limit_scope Error :",str(e))
            return {'status' : "ERROR"}


    def update_onb_agent(self,session,role_id,onb_agent):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(onb_agent=onb_agent))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_onb_agent Error :",str(e))
            return {'status' : "ERROR"}


    def update_override_err(self,session,role_id,override_err):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(override_err=override_err))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_override_err Error :",str(e))
            return {'status' : "ERROR"}


    def update_rest_data(self,session,role_id,rest_data):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rest_data=rest_data))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rest_data Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,role_id,role_code):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_desc(self,session,role_id,role_desc):
        try:
            session.query(RoleDtl).filter_by(
                org_id=self.org_id,
                			if role_id:
				query = query.filter(RoleDtl.role_id== role_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_desc=role_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_desc Error :",str(e))
            return {'status' : "ERROR"}
