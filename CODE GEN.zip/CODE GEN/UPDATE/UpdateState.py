from modelnew import *
class ClsUpState:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_country(self,session,id,country):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country=country))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country Error :",str(e))
            return {'status' : "ERROR"}


    def update_country_code(self,session,id,country_code):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country_code=country_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_country_id(self,session,id,country_id):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country_id=country_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_created_at(self,session,id,created_at):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(created_at=created_at))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_created_at Error :",str(e))
            return {'status' : "ERROR"}


    def update_fips_code(self,session,id,fips_code):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(fips_code=fips_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_fips_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_flag(self,session,id,flag):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(flag=flag))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_flag Error :",str(e))
            return {'status' : "ERROR"}


    def update_iso2(self,session,id,iso2):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(iso2=iso2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_iso2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_latitude(self,session,id,latitude):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(latitude=latitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_longitude(self,session,id,longitude):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(longitude=longitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_name(self,session,id,name):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_type(self,session,id,type):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(type=type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_updated_at(self,session,id,updated_at):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(updated_at=updated_at))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_updated_at Error :",str(e))
            return {'status' : "ERROR"}


    def update_wikiDataId(self,session,id,wikiDataId):
        try:
            session.query(State).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(State.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(wikiDataId=wikiDataId))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_wikiDataId Error :",str(e))
            return {'status' : "ERROR"}
