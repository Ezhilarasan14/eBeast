from modelnew import *
class ClsUpSessionDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_back_fore_flg(self,session,sess_uniq_id,back_fore_flg):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(back_fore_flg=back_fore_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_back_fore_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_calling_prog_id(self,session,sess_uniq_id,calling_prog_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(calling_prog_id=calling_prog_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_calling_prog_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_device_id(self,session,sess_uniq_id,device_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_id=device_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_device_token(self,session,sess_uniq_id,device_token):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_token=device_token))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_token Error :",str(e))
            return {'status' : "ERROR"}


    def update_device_type(self,session,sess_uniq_id,device_type):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_type=device_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_exe_name(self,session,sess_uniq_id,exe_name):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(exe_name=exe_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_exe_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_home_crncy(self,session,sess_uniq_id,home_crncy):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(home_crncy=home_crncy))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_home_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def update_logged_on_mode(self,session,sess_uniq_id,logged_on_mode):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(logged_on_mode=logged_on_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_logged_on_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_module_id(self,session,sess_uniq_id,module_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(module_id=module_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_module_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_node_id(self,session,sess_uniq_id,node_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(node_id=node_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_node_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_node_name(self,session,sess_uniq_id,node_name):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(node_name=node_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_node_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_node_type(self,session,sess_uniq_id,node_type):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(node_type=node_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_node_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_bod_date(self,session,sess_uniq_id,org_bod_date):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_bod_date=org_bod_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_cls_date(self,session,sess_uniq_id,org_cls_date):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_cls_date=org_cls_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_session_id(self,session,sess_uniq_id,parent_session_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_session_id=parent_session_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_session_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferred_language(self,session,sess_uniq_id,preferred_language):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferred_language=preferred_language))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferred_language Error :",str(e))
            return {'status' : "ERROR"}


    def update_proc_id(self,session,sess_uniq_id,proc_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(proc_id=proc_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_proc_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,sess_uniq_id,role_code):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_session_id(self,session,sess_uniq_id,session_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(session_id=session_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_session_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_session_time_zone(self,session,sess_uniq_id,session_time_zone):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(session_time_zone=session_time_zone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_session_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_access_id(self,session,sess_uniq_id,temp_view_access_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_access_id=temp_view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_access_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_temp_view_valid_till(self,session,sess_uniq_id,temp_view_valid_till):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(temp_view_valid_till=temp_view_valid_till))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_temp_view_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def update_todays_date(self,session,sess_uniq_id,todays_date):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(todays_date=todays_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_todays_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,sess_uniq_id,user_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_view_access_id(self,session,sess_uniq_id,view_access_id):
        try:
            session.query(SessionDtl).filter_by(
                org_id=self.org_id,
                			if sess_uniq_id:
				query = query.filter(SessionDtl.sess_uniq_id== sess_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(view_access_id=view_access_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_view_access_id Error :",str(e))
            return {'status' : "ERROR"}
