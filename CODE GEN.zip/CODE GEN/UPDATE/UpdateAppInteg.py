from modelnew import *
class ClsUpAppInteg:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_api_status(self,session,app_integ_id,api_status):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_status=api_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_id(self,session,app_integ_id,app_id):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_id=app_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_dep_on(self,session,app_integ_id,dep_on):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dep_on=dep_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dep_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_entity_id(self,session,app_integ_id,entity_id):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_id=entity_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_integ_type(self,session,app_integ_id,integ_type):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(integ_type=integ_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_integ_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_integ_url(self,session,app_integ_id,integ_url):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(integ_url=integ_url))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_integ_url Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_api_revokable(self,session,app_integ_id,is_api_revokable):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_api_revokable=is_api_revokable))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_api_revokable Error :",str(e))
            return {'status' : "ERROR"}


    def update_result(self,session,app_integ_id,result):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(result=result))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_result Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_name(self,session,app_integ_id,sys_name):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_name=sys_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_action(self,session,app_integ_id,trigger_action):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_action=trigger_action))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_action Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_seq(self,session,app_integ_id,trigger_seq):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_seq=trigger_seq))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_seq Error :",str(e))
            return {'status' : "ERROR"}


    def update_trigger_step(self,session,app_integ_id,trigger_step):
        try:
            session.query(AppInteg).filter_by(
                org_id=self.org_id,
                			if app_integ_id:
				query = query.filter(AppInteg.app_integ_id== app_integ_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(trigger_step=trigger_step))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_trigger_step Error :",str(e))
            return {'status' : "ERROR"}
