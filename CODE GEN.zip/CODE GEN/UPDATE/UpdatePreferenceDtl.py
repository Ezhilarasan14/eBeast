from modelnew import *
class ClsUpPreferenceDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_pref_event_value(self,session,cust_id,pref_event_name,pref_type,remind_par_cat_id,sys_tran_cat_id,user_id,pref_event_value):
        try:
            session.query(PreferenceDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreferenceDtl.cust_id== cust_id)
			if pref_event_name:
				query = query.filter(PreferenceDtl.pref_event_name== pref_event_name)
			if pref_type:
				query = query.filter(PreferenceDtl.pref_type== pref_type)
			if remind_par_cat_id:
				query = query.filter(PreferenceDtl.remind_par_cat_id== remind_par_cat_id)
			if sys_tran_cat_id:
				query = query.filter(PreferenceDtl.sys_tran_cat_id== sys_tran_cat_id)
			if user_id:
				query = query.filter(PreferenceDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pref_event_value=pref_event_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pref_event_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_remind_bf_days(self,session,cust_id,pref_event_name,pref_type,remind_par_cat_id,sys_tran_cat_id,user_id,remind_bf_days):
        try:
            session.query(PreferenceDtl).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(PreferenceDtl.cust_id== cust_id)
			if pref_event_name:
				query = query.filter(PreferenceDtl.pref_event_name== pref_event_name)
			if pref_type:
				query = query.filter(PreferenceDtl.pref_type== pref_type)
			if remind_par_cat_id:
				query = query.filter(PreferenceDtl.remind_par_cat_id== remind_par_cat_id)
			if sys_tran_cat_id:
				query = query.filter(PreferenceDtl.sys_tran_cat_id== sys_tran_cat_id)
			if user_id:
				query = query.filter(PreferenceDtl.user_id== user_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remind_bf_days=remind_bf_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remind_bf_days Error :",str(e))
            return {'status' : "ERROR"}
