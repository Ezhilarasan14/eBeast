from modelnew import *
class ClsUpAuditDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_api_name(self,session,req_id,api_name):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_name=api_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_calling_url(self,session,req_id,calling_url):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(calling_url=calling_url))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_calling_url Error :",str(e))
            return {'status' : "ERROR"}


    def update_reason(self,session,req_id,reason):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reason=reason))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reason Error :",str(e))
            return {'status' : "ERROR"}


    def update_req_orig(self,session,req_id,req_orig):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(req_orig=req_orig))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_req_orig Error :",str(e))
            return {'status' : "ERROR"}


    def update_request(self,session,req_id,request):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(request=request))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_request Error :",str(e))
            return {'status' : "ERROR"}


    def update_resp_type(self,session,req_id,resp_type):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(resp_type=resp_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_resp_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_response(self,session,req_id,response):
        try:
            session.query(AuditDtl).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(AuditDtl.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(response=response))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_response Error :",str(e))
            return {'status' : "ERROR"}
