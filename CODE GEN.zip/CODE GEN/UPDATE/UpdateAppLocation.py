from modelnew import *
class ClsUpAppLocation:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,loc_id,application_id):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,loc_id,cust_id):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_display_name(self,session,loc_id,display_name):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(display_name=display_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_display_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,loc_id,end_time):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_latitude(self,session,loc_id,latitude):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(latitude=latitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_latitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_longitude(self,session,loc_id,longitude):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(longitude=longitude))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_longitude Error :",str(e))
            return {'status' : "ERROR"}


    def update_response(self,session,loc_id,response):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(response=response))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_response Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,loc_id,start_time):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_info(self,session,loc_id,sys_info):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_info=sys_info))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_info Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_status(self,session,loc_id,sys_status):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_status=sys_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_status(self,session,loc_id,user_status):
        try:
            session.query(AppLocation).filter_by(
                org_id=self.org_id,
                			if loc_id:
				query = query.filter(AppLocation.loc_id== loc_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_status=user_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_status Error :",str(e))
            return {'status' : "ERROR"}
