from modelnew import *
class ClsUpTaxDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_tax_amount(self,session,fee_code,finserv_id,tax_code,tax_amount):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_amount=tax_amount))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_amount Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_amt_ind(self,session,fee_code,finserv_id,tax_code,tax_amt_ind):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_amt_ind=tax_amt_ind))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_amt_ind Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_crncy_code(self,session,fee_code,finserv_id,tax_code,tax_crncy_code):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_crncy_code=tax_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_desc(self,session,fee_code,finserv_id,tax_code,tax_desc):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_desc=tax_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_desc_alt(self,session,fee_code,finserv_id,tax_code,tax_desc_alt):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_desc_alt=tax_desc_alt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def update_tax_pcnt(self,session,fee_code,finserv_id,tax_code,tax_pcnt):
        try:
            session.query(TaxDtl).filter_by(
                org_id=self.org_id,
                			if fee_code:
				query = query.filter(TaxDtl.fee_code== fee_code)
			if finserv_id:
				query = query.filter(TaxDtl.finserv_id== finserv_id)
			if tax_code:
				query = query.filter(TaxDtl.tax_code== tax_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tax_pcnt=tax_pcnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tax_pcnt Error :",str(e))
            return {'status' : "ERROR"}
