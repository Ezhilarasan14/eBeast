from modelnew import *
class ClsUpAuthMatrixConfig:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_Idle_measure_unit(self,session,auth_matrix_id,Idle_measure_unit):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Idle_measure_unit=Idle_measure_unit))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Idle_measure_unit Error :",str(e))
            return {'status' : "ERROR"}


    def update_Idle_measure_value(self,session,auth_matrix_id,Idle_measure_value):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(Idle_measure_value=Idle_measure_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_Idle_measure_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_auth_level(self,session,auth_matrix_id,auth_level):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auth_level=auth_level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auth_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_auth_matrix_code(self,session,auth_matrix_id,auth_matrix_code):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auth_matrix_code=auth_matrix_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_auth_nature(self,session,auth_matrix_id,auth_nature):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auth_nature=auth_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auth_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_scope(self,session,auth_matrix_id,br_scope):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_scope=br_scope))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_scope Error :",str(e))
            return {'status' : "ERROR"}


    def update_br_set_id(self,session,auth_matrix_id,br_set_id):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(br_set_id=br_set_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_br_set_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_role_code(self,session,auth_matrix_id,role_code):
        try:
            session.query(AuthMatrixConfig).filter_by(
                org_id=self.org_id,
                			if auth_matrix_id:
				query = query.filter(AuthMatrixConfig.auth_matrix_id== auth_matrix_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role_code=role_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role_code Error :",str(e))
            return {'status' : "ERROR"}
