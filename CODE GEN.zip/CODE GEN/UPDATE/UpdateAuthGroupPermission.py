from modelnew import *
class ClsUpAuthGroupPermission:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_group(self,session,id,group):
        try:
            session.query(AuthGroupPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthGroupPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group=group))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group Error :",str(e))
            return {'status' : "ERROR"}


    def update_group_id(self,session,id,group_id):
        try:
            session.query(AuthGroupPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthGroupPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group_id=group_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_permission(self,session,id,permission):
        try:
            session.query(AuthGroupPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthGroupPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(permission=permission))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_permission Error :",str(e))
            return {'status' : "ERROR"}


    def update_permission_id(self,session,id,permission_id):
        try:
            session.query(AuthGroupPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthGroupPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(permission_id=permission_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_permission_id Error :",str(e))
            return {'status' : "ERROR"}
