from modelnew import *
class ClsUpAppOtherField:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,id,application_id):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,id,cust_id):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_id(self,session,id,field_id):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_id=field_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_type(self,session,id,field_type):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_type=field_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_value(self,session,id,field_value):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_value=field_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_form_id(self,session,id,form_id):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(form_id=form_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_form_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_ref_type(self,session,id,ref_type):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ref_type=ref_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ref_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_section_id(self,session,id,section_id):
        try:
            session.query(AppOtherField).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AppOtherField.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(section_id=section_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_section_id Error :",str(e))
            return {'status' : "ERROR"}
