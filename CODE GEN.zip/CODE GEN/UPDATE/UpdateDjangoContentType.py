from modelnew import *
class ClsUpDjangoContentType:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_app_label(self,session,id,app_label):
        try:
            session.query(DjangoContentType).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoContentType.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_label=app_label))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_label Error :",str(e))
            return {'status' : "ERROR"}


    def update_model(self,session,id,model):
        try:
            session.query(DjangoContentType).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoContentType.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(model=model))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_model Error :",str(e))
            return {'status' : "ERROR"}
