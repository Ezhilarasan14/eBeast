from modelnew import *
class ClsUpCallRequest:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_agent_id(self,session,req_id,agent_id):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(agent_id=agent_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_agent_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_application_id(self,session,req_id,application_id):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_call_status(self,session,req_id,call_status):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(call_status=call_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_call_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_consent(self,session,req_id,consent):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(consent=consent))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_consent Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,req_id,cust_id):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_time(self,session,req_id,end_time):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_time=end_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_from_time(self,session,req_id,from_time):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(from_time=from_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_from_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_pref_lang(self,session,req_id,pref_lang):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pref_lang=pref_lang))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pref_lang Error :",str(e))
            return {'status' : "ERROR"}


    def update_rsn_code(self,session,req_id,rsn_code):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rsn_code=rsn_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rsn_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_rsn_type(self,session,req_id,rsn_type):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rsn_type=rsn_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rsn_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_sched_on(self,session,req_id,sched_on):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sched_on=sched_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sched_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_sched_type(self,session,req_id,sched_type):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sched_type=sched_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sched_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_time(self,session,req_id,start_time):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_time=start_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_zone(self,session,req_id,time_zone):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_zone=time_zone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def update_to_time(self,session,req_id,to_time):
        try:
            session.query(CallRequest).filter_by(
                org_id=self.org_id,
                			if req_id:
				query = query.filter(CallRequest.req_id== req_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(to_time=to_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_to_time Error :",str(e))
            return {'status' : "ERROR"}
