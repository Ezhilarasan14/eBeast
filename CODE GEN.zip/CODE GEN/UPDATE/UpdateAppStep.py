from modelnew import *
class ClsUpAppStep:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,app_step_id,application_id):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_auth_matrix_code(self,session,app_step_id,auth_matrix_code):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auth_matrix_code=auth_matrix_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auth_matrix_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_data_overall_point(self,session,app_step_id,data_overall_point):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(data_overall_point=data_overall_point))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_data_overall_point Error :",str(e))
            return {'status' : "ERROR"}


    def update_mandatory(self,session,app_step_id,mandatory):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(mandatory=mandatory))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_step_id(self,session,app_step_id,prod_step_id):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_step_id=prod_step_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_step_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_code(self,session,app_step_id,step_code):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_code=step_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_name(self,session,app_step_id,step_name):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_name=step_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_num(self,session,app_step_id,step_num):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_num=step_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_status(self,session,app_step_id,step_status):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_status=step_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_total_doc_cnt(self,session,app_step_id,total_doc_cnt):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(total_doc_cnt=total_doc_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_total_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_uploaded_doc_cnt(self,session,app_step_id,uploaded_doc_cnt):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(uploaded_doc_cnt=uploaded_doc_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_uploaded_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_remarks(self,session,app_step_id,user_remarks):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_remarks=user_remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_verified_doc_cnt(self,session,app_step_id,verified_doc_cnt):
        try:
            session.query(AppStep).filter_by(
                org_id=self.org_id,
                			if app_step_id:
				query = query.filter(AppStep.app_step_id== app_step_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(verified_doc_cnt=verified_doc_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_verified_doc_cnt Error :",str(e))
            return {'status' : "ERROR"}
