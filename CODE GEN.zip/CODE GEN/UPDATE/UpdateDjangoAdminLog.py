from modelnew import *
class ClsUpDjangoAdminLog:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_action_flag(self,session,id,action_flag):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(action_flag=action_flag))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_action_flag Error :",str(e))
            return {'status' : "ERROR"}


    def update_action_time(self,session,id,action_time):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(action_time=action_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_action_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_change_message(self,session,id,change_message):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(change_message=change_message))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_change_message Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type_id(self,session,id,content_type_id):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type_id=content_type_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_id(self,session,id,object_id):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_id=object_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_repr(self,session,id,object_repr):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_repr=object_repr))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_repr Error :",str(e))
            return {'status' : "ERROR"}


    def update_user(self,session,id,user):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user=user))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,id,user_id):
        try:
            session.query(DjangoAdminLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoAdminLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
