from modelnew import *
class ClsUpAuditlogLogentry:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_action(self,session,id,action):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(action=action))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_action Error :",str(e))
            return {'status' : "ERROR"}


    def update_actor(self,session,id,actor):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(actor=actor))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_actor Error :",str(e))
            return {'status' : "ERROR"}


    def update_actor_id(self,session,id,actor_id):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(actor_id=actor_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_actor_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_additional_data(self,session,id,additional_data):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(additional_data=additional_data))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_additional_data Error :",str(e))
            return {'status' : "ERROR"}


    def update_changes(self,session,id,changes):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(changes=changes))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_changes Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type_id(self,session,id,content_type_id):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type_id=content_type_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_id(self,session,id,object_id):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_id=object_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_pk(self,session,id,object_pk):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_pk=object_pk))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_pk Error :",str(e))
            return {'status' : "ERROR"}


    def update_object_repr(self,session,id,object_repr):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(object_repr=object_repr))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_object_repr Error :",str(e))
            return {'status' : "ERROR"}


    def update_remote_addr(self,session,id,remote_addr):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remote_addr=remote_addr))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remote_addr Error :",str(e))
            return {'status' : "ERROR"}


    def update_timestamp(self,session,id,timestamp):
        try:
            session.query(AuditlogLogentry).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuditlogLogentry.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(timestamp=timestamp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_timestamp Error :",str(e))
            return {'status' : "ERROR"}
