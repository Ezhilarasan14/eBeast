from modelnew import *
class ClsUpAppEmpDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,employer_id,application_id):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,employer_id,cust_id):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_address(self,session,employer_id,employer_address):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_address=employer_address))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_address Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_city(self,session,employer_id,employer_city):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_city=employer_city))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_city Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_country(self,session,employer_id,employer_country):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_country=employer_country))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_country Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_name(self,session,employer_id,employer_name):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_name=employer_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_pin(self,session,employer_id,employer_pin):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_pin=employer_pin))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_pin Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_state(self,session,employer_id,employer_state):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_state=employer_state))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_state Error :",str(e))
            return {'status' : "ERROR"}


    def update_employer_type(self,session,employer_id,employer_type):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employer_type=employer_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employer_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_from_yr(self,session,employer_id,from_yr):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(from_yr=from_yr))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_from_yr Error :",str(e))
            return {'status' : "ERROR"}


    def update_gross_salary(self,session,employer_id,gross_salary):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gross_salary=gross_salary))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gross_salary Error :",str(e))
            return {'status' : "ERROR"}


    def update_image_path(self,session,employer_id,image_path):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(image_path=image_path))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_image_path Error :",str(e))
            return {'status' : "ERROR"}


    def update_role(self,session,employer_id,role):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(role=role))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_role Error :",str(e))
            return {'status' : "ERROR"}


    def update_salary_currency(self,session,employer_id,salary_currency):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(salary_currency=salary_currency))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_salary_currency Error :",str(e))
            return {'status' : "ERROR"}


    def update_sector(self,session,employer_id,sector):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sector=sector))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sector Error :",str(e))
            return {'status' : "ERROR"}


    def update_to_yr(self,session,employer_id,to_yr):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(to_yr=to_yr))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_to_yr Error :",str(e))
            return {'status' : "ERROR"}


    def update_years_of_exp(self,session,employer_id,years_of_exp):
        try:
            session.query(AppEmpDtl).filter_by(
                org_id=self.org_id,
                			if employer_id:
				query = query.filter(AppEmpDtl.employer_id== employer_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(years_of_exp=years_of_exp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_years_of_exp Error :",str(e))
            return {'status' : "ERROR"}
