from modelnew import *
class ClsUpLeadsDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_alt_first_name(self,session,lead_id,alt_first_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_first_name=alt_first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_last_name(self,session,lead_id,alt_last_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_last_name=alt_last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_middle_name(self,session,lead_id,alt_middle_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_middle_name=alt_middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_annual_salary(self,session,lead_id,annual_salary):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(annual_salary=annual_salary))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_annual_salary Error :",str(e))
            return {'status' : "ERROR"}


    def update_campaign_name(self,session,lead_id,campaign_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(campaign_name=campaign_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_campaign_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_classification(self,session,lead_id,classification):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(classification=classification))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_classification Error :",str(e))
            return {'status' : "ERROR"}


    def update_company_category(self,session,lead_id,company_category):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(company_category=company_category))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_company_category Error :",str(e))
            return {'status' : "ERROR"}


    def update_company_name(self,session,lead_id,company_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(company_name=company_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_company_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_employment_status(self,session,lead_id,employment_status):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(employment_status=employment_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_employment_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_expense(self,session,lead_id,expense):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(expense=expense))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_expense Error :",str(e))
            return {'status' : "ERROR"}


    def update_first_name(self,session,lead_id,first_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(first_name=first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_gender(self,session,lead_id,gender):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gender=gender))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gender Error :",str(e))
            return {'status' : "ERROR"}


    def update_income(self,session,lead_id,income):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(income=income))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_income Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_name(self,session,lead_id,last_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_name=last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_lead_date(self,session,lead_id,lead_date):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(lead_date=lead_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_lead_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_lead_source(self,session,lead_id,lead_source):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(lead_source=lead_source))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_lead_source Error :",str(e))
            return {'status' : "ERROR"}


    def update_lead_to_cust(self,session,lead_id,lead_to_cust):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(lead_to_cust=lead_to_cust))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_lead_to_cust Error :",str(e))
            return {'status' : "ERROR"}


    def update_lead_type(self,session,lead_id,lead_type):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(lead_type=lead_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_lead_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_marital_status(self,session,lead_id,marital_status):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(marital_status=marital_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_marital_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_middle_name(self,session,lead_id,middle_name):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(middle_name=middle_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_middle_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_nre_flg(self,session,lead_id,nre_flg):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(nre_flg=nre_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_nre_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_nre_since(self,session,lead_id,nre_since):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(nre_since=nre_since))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_nre_since Error :",str(e))
            return {'status' : "ERROR"}


    def update_num_of_child_dependants(self,session,lead_id,num_of_child_dependants):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(num_of_child_dependants=num_of_child_dependants))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_num_of_child_dependants Error :",str(e))
            return {'status' : "ERROR"}


    def update_num_of_dependants(self,session,lead_id,num_of_dependants):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(num_of_dependants=num_of_dependants))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_num_of_dependants Error :",str(e))
            return {'status' : "ERROR"}


    def update_preferref_language(self,session,lead_id,preferref_language):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(preferref_language=preferref_language))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_preferref_language Error :",str(e))
            return {'status' : "ERROR"}


    def update_primary_relationship_manager_id(self,session,lead_id,primary_relationship_manager_id):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(primary_relationship_manager_id=primary_relationship_manager_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_primary_relationship_manager_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_interested(self,session,lead_id,product_interested):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_interested=product_interested))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_interested Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_proposed(self,session,lead_id,product_proposed):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_proposed=product_proposed))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_proposed Error :",str(e))
            return {'status' : "ERROR"}


    def update_rating(self,session,lead_id,rating):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rating=rating))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rating Error :",str(e))
            return {'status' : "ERROR"}


    def update_ratingdate(self,session,lead_id,ratingdate):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ratingdate=ratingdate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ratingdate Error :",str(e))
            return {'status' : "ERROR"}


    def update_referred_by(self,session,lead_id,referred_by):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(referred_by=referred_by))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_referred_by Error :",str(e))
            return {'status' : "ERROR"}


    def update_salary_currency(self,session,lead_id,salary_currency):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(salary_currency=salary_currency))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_salary_currency Error :",str(e))
            return {'status' : "ERROR"}


    def update_salutation(self,session,lead_id,salutation):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(salutation=salutation))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_salutation Error :",str(e))
            return {'status' : "ERROR"}


    def update_secondary_relationship_manager_id(self,session,lead_id,secondary_relationship_manager_id):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(secondary_relationship_manager_id=secondary_relationship_manager_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_secondary_relationship_manager_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_segment(self,session,lead_id,segment):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(segment=segment))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_segment Error :",str(e))
            return {'status' : "ERROR"}


    def update_status(self,session,lead_id,status):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status=status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_subsegment(self,session,lead_id,subsegment):
        try:
            session.query(LeadsDtl).filter_by(
                org_id=self.org_id,
                			if lead_id:
				query = query.filter(LeadsDtl.lead_id== lead_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(subsegment=subsegment))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_subsegment Error :",str(e))
            return {'status' : "ERROR"}
