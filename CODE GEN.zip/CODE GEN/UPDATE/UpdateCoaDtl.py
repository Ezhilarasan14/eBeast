from modelnew import *
class ClsUpCoaDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_coa_name(self,session,coa_id,coa_name):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coa_name=coa_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coa_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_coa_type(self,session,coa_id,coa_type):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coa_type=coa_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coa_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_head(self,session,coa_id,head):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(head=head))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_head Error :",str(e))
            return {'status' : "ERROR"}


    def update_level(self,session,coa_id,level):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(level=level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_coa_id(self,session,coa_id,parent_coa_id):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_coa_id=parent_coa_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_coa_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_id(self,session,coa_id,sys_cat_id):
        try:
            session.query(CoaDtl).filter_by(
                org_id=self.org_id,
                			if coa_id:
				query = query.filter(CoaDtl.coa_id== coa_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_id=sys_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_id Error :",str(e))
            return {'status' : "ERROR"}
