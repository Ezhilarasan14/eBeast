from modelnew import *
class ClsUpAuthUser:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_date_joined(self,session,id,date_joined):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(date_joined=date_joined))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_date_joined Error :",str(e))
            return {'status' : "ERROR"}


    def update_email(self,session,id,email):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email=email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_first_name(self,session,id,first_name):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(first_name=first_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_first_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_active(self,session,id,is_active):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_active=is_active))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_active Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_staff(self,session,id,is_staff):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_staff=is_staff))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_staff Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_superuser(self,session,id,is_superuser):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_superuser=is_superuser))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_superuser Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_login(self,session,id,last_login):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_login=last_login))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_login Error :",str(e))
            return {'status' : "ERROR"}


    def update_last_name(self,session,id,last_name):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(last_name=last_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_last_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_password(self,session,id,password):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(password=password))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_password Error :",str(e))
            return {'status' : "ERROR"}


    def update_username(self,session,id,username):
        try:
            session.query(AuthUser).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthUser.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(username=username))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_username Error :",str(e))
            return {'status' : "ERROR"}
