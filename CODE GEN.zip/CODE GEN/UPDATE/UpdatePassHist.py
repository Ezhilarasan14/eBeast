from modelnew import *
class ClsUpPassHist:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_curr_flag(self,session,pw_hist_id,curr_flag):
        try:
            session.query(PassHist).filter_by(
                org_id=self.org_id,
                			if pw_hist_id:
				query = query.filter(PassHist.pw_hist_id== pw_hist_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(curr_flag=curr_flag))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_curr_flag Error :",str(e))
            return {'status' : "ERROR"}


    def update_password(self,session,pw_hist_id,password):
        try:
            session.query(PassHist).filter_by(
                org_id=self.org_id,
                			if pw_hist_id:
				query = query.filter(PassHist.pw_hist_id== pw_hist_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(password=password))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_password Error :",str(e))
            return {'status' : "ERROR"}


    def update_pw_cre_date(self,session,pw_hist_id,pw_cre_date):
        try:
            session.query(PassHist).filter_by(
                org_id=self.org_id,
                			if pw_hist_id:
				query = query.filter(PassHist.pw_hist_id== pw_hist_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pw_cre_date=pw_cre_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pw_cre_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_pw_expiry_date(self,session,pw_hist_id,pw_expiry_date):
        try:
            session.query(PassHist).filter_by(
                org_id=self.org_id,
                			if pw_hist_id:
				query = query.filter(PassHist.pw_hist_id== pw_hist_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pw_expiry_date=pw_expiry_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pw_expiry_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,pw_hist_id,user_id):
        try:
            session.query(PassHist).filter_by(
                org_id=self.org_id,
                			if pw_hist_id:
				query = query.filter(PassHist.pw_hist_id== pw_hist_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
