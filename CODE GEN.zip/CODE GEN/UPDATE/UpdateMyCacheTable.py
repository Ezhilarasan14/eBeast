from modelnew import *
class ClsUpMyCacheTable:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_expires(self,session,cache_key,expires):
        try:
            session.query(MyCacheTable).filter_by(
                org_id=self.org_id,
                			if cache_key:
				query = query.filter(MyCacheTable.cache_key== cache_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(expires=expires))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_expires Error :",str(e))
            return {'status' : "ERROR"}


    def update_value(self,session,cache_key,value):
        try:
            session.query(MyCacheTable).filter_by(
                org_id=self.org_id,
                			if cache_key:
				query = query.filter(MyCacheTable.cache_key== cache_key)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(value=value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_value Error :",str(e))
            return {'status' : "ERROR"}
