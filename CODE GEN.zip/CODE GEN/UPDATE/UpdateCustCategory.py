from modelnew import *
class ClsUpCustCategory:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_entity_int_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,entity_int_id):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(entity_int_id=entity_int_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_entity_int_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_global_change(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,global_change):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(global_change=global_change))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_global_change Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_level(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,sys_cat_level):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_level=sys_cat_level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_name(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,sys_cat_name):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_name=sys_cat_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_cat_type(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,sys_cat_type):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_cat_type=sys_cat_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_head(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,sys_head):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_head=sys_head))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_head Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_parent_cat_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,sys_parent_cat_id):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_parent_cat_id=sys_parent_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cat_level(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,user_cat_level):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cat_level=user_cat_level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cat_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cat_name(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,user_cat_name):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cat_name=user_cat_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_cat_type(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,user_cat_type):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_cat_type=user_cat_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_head(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,user_head):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_head=user_head))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_head Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_parent_cat_id(self,session,cust_id,sys_cat_id,tran_date,tran_id,user_cat_id,user_parent_cat_id):
        try:
            session.query(CustCategory).filter_by(
                org_id=self.org_id,
                			if cust_id:
				query = query.filter(CustCategory.cust_id== cust_id)
			if sys_cat_id:
				query = query.filter(CustCategory.sys_cat_id== sys_cat_id)
			if tran_date:
				query = query.filter(CustCategory.tran_date== tran_date)
			if tran_id:
				query = query.filter(CustCategory.tran_id== tran_id)
			if user_cat_id:
				query = query.filter(CustCategory.user_cat_id== user_cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_parent_cat_id=user_parent_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}
