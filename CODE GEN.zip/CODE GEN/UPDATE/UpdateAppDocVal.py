from modelnew import *
class ClsUpAppDocVal:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_app(self,session,doc_val_id,app):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app=app))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_id(self,session,doc_val_id,app_id):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_id=app_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,doc_val_id,cust_id):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc(self,session,doc_val_id,doc):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc=doc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_code(self,session,doc_val_id,doc_code):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_code=doc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_id(self,session,doc_val_id,doc_id):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_id=doc_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_type(self,session,doc_val_id,doc_type):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_type=doc_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_val(self,session,doc_val_id,doc_val):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_val=doc_val))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_val Error :",str(e))
            return {'status' : "ERROR"}


    def update_missing(self,session,doc_val_id,missing):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(missing=missing))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_missing Error :",str(e))
            return {'status' : "ERROR"}


    def update_remarks(self,session,doc_val_id,remarks):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remarks=remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_side(self,session,doc_val_id,side):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(side=side))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_side Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_status(self,session,doc_val_id,sys_status):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_status=sys_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_status(self,session,doc_val_id,user_status):
        try:
            session.query(AppDocVal).filter_by(
                org_id=self.org_id,
                			if doc_val_id:
				query = query.filter(AppDocVal.doc_val_id== doc_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_status=user_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_status Error :",str(e))
            return {'status' : "ERROR"}
