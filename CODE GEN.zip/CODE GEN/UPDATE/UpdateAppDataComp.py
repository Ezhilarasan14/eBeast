from modelnew import *
class ClsUpAppDataComp:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_application_id(self,session,comp_id,application_id):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(application_id=application_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_application_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,comp_id,cust_id):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_values(self,session,comp_id,doc_values):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_values=doc_values))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_values Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_name(self,session,comp_id,field_name):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_name=field_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_status(self,session,comp_id,sys_status):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_status=sys_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_remarks(self,session,comp_id,user_remarks):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_remarks=user_remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_status(self,session,comp_id,user_status):
        try:
            session.query(AppDataComp).filter_by(
                org_id=self.org_id,
                			if comp_id:
				query = query.filter(AppDataComp.comp_id== comp_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_status=user_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_status Error :",str(e))
            return {'status' : "ERROR"}
