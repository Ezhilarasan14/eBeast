from modelnew import *
class ClsUpOrgDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_address_line1(self,session,,address_line1):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_line1=address_line1))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_line1 Error :",str(e))
            return {'status' : "ERROR"}


    def update_address_line2(self,session,,address_line2):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(address_line2=address_line2))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_address_line2 Error :",str(e))
            return {'status' : "ERROR"}


    def update_api_key(self,session,,api_key):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_key=api_key))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_key Error :",str(e))
            return {'status' : "ERROR"}


    def update_api_user(self,session,,api_user):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api_user=api_user))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api_user Error :",str(e))
            return {'status' : "ERROR"}


    def update_central_bank_code(self,session,,central_bank_code):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(central_bank_code=central_bank_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_central_bank_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_central_bank_name(self,session,,central_bank_name):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(central_bank_name=central_bank_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_central_bank_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_city(self,session,,city):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(city=city))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_city Error :",str(e))
            return {'status' : "ERROR"}


    def update_collect_doc(self,session,,collect_doc):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(collect_doc=collect_doc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_collect_doc Error :",str(e))
            return {'status' : "ERROR"}


    def update_cont_num(self,session,,cont_num):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cont_num=cont_num))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cont_num Error :",str(e))
            return {'status' : "ERROR"}


    def update_country(self,session,,country):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(country=country))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_country Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_val(self,session,,doc_val):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_val=doc_val))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_val Error :",str(e))
            return {'status' : "ERROR"}


    def update_email_mand_onb(self,session,,email_mand_onb):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(email_mand_onb=email_mand_onb))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_email_mand_onb Error :",str(e))
            return {'status' : "ERROR"}


    def update_enable_otp(self,session,,enable_otp):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(enable_otp=enable_otp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_enable_otp Error :",str(e))
            return {'status' : "ERROR"}


    def update_enable_spoof(self,session,,enable_spoof):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(enable_spoof=enable_spoof))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_enable_spoof Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_match(self,session,,face_match):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_match=face_match))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_match Error :",str(e))
            return {'status' : "ERROR"}


    def update_face_match_thres(self,session,,face_match_thres):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(face_match_thres=face_match_thres))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_face_match_thres Error :",str(e))
            return {'status' : "ERROR"}


    def update_form_auto_fill(self,session,,form_auto_fill):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(form_auto_fill=form_auto_fill))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_form_auto_fill Error :",str(e))
            return {'status' : "ERROR"}


    def update_gen_qrcode(self,session,,gen_qrcode):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gen_qrcode=gen_qrcode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gen_qrcode Error :",str(e))
            return {'status' : "ERROR"}


    def update_gesture_thres(self,session,,gesture_thres):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(gesture_thres=gesture_thres))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_gesture_thres Error :",str(e))
            return {'status' : "ERROR"}


    def update_home_cntry_code(self,session,,home_cntry_code):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(home_cntry_code=home_cntry_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_home_cntry_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_home_crncy_code(self,session,,home_crncy_code):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(home_crncy_code=home_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_home_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_ind_type(self,session,,ind_type):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ind_type=ind_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ind_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_kyc(self,session,,kyc):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(kyc=kyc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_kyc Error :",str(e))
            return {'status' : "ERROR"}


    def update_land_on(self,session,,land_on):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(land_on=land_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_land_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_clerk_view_id(self,session,,max_clerk_view_id):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_clerk_view_id=max_clerk_view_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_clerk_view_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_minor_age(self,session,,minor_age):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minor_age=minor_age))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minor_age Error :",str(e))
            return {'status' : "ERROR"}


    def update_multi_crncy(self,session,,multi_crncy):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(multi_crncy=multi_crncy))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_multi_crncy Error :",str(e))
            return {'status' : "ERROR"}


    def update_onb_ph_otp(self,session,,onb_ph_otp):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(onb_ph_otp=onb_ph_otp))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_onb_ph_otp Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_alias(self,session,,org_alias):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_alias=org_alias))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_alias Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_bod_date(self,session,,org_bod_date):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_bod_date=org_bod_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_cls_date(self,session,,org_cls_date):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_cls_date=org_cls_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_code(self,session,,org_code):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_code=org_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_desc(self,session,,org_desc):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_desc=org_desc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_desc Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_desc_alt(self,session,,org_desc_alt):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_desc_alt=org_desc_alt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_desc_alt Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_icon(self,session,,org_icon):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_icon=org_icon))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_icon Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_logo(self,session,,org_logo):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_logo=org_logo))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_logo Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_status(self,session,,org_status):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_status=org_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_website(self,session,,org_website):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_website=org_website))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_website Error :",str(e))
            return {'status' : "ERROR"}


    def update_override_err(self,session,,override_err):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(override_err=override_err))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_override_err Error :",str(e))
            return {'status' : "ERROR"}


    def update_priv_pol(self,session,,priv_pol):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(priv_pol=priv_pol))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_priv_pol Error :",str(e))
            return {'status' : "ERROR"}


    def update_pw_valid_period(self,session,,pw_valid_period):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pw_valid_period=pw_valid_period))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pw_valid_period Error :",str(e))
            return {'status' : "ERROR"}


    def update_reg_no(self,session,,reg_no):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reg_no=reg_no))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reg_no Error :",str(e))
            return {'status' : "ERROR"}


    def update_rekyc_req(self,session,,rekyc_req):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(rekyc_req=rekyc_req))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_rekyc_req Error :",str(e))
            return {'status' : "ERROR"}


    def update_scope(self,session,,scope):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(scope=scope))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_scope Error :",str(e))
            return {'status' : "ERROR"}


    def update_sign_mode(self,session,,sign_mode):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sign_mode=sign_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sign_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_spoof_thres(self,session,,spoof_thres):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(spoof_thres=spoof_thres))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_spoof_thres Error :",str(e))
            return {'status' : "ERROR"}


    def update_state(self,session,,state):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(state=state))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_state Error :",str(e))
            return {'status' : "ERROR"}


    def update_step_order(self,session,,step_order):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(step_order=step_order))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_step_order Error :",str(e))
            return {'status' : "ERROR"}


    def update_sub_id(self,session,,sub_id):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sub_id=sub_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sub_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sub_plan(self,session,,sub_plan):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sub_plan=sub_plan))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sub_plan Error :",str(e))
            return {'status' : "ERROR"}


    def update_sub_status(self,session,,sub_status):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sub_status=sub_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sub_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_sup_email(self,session,,sup_email):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sup_email=sup_email))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sup_email Error :",str(e))
            return {'status' : "ERROR"}


    def update_tandc(self,session,,tandc):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(tandc=tandc))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_tandc Error :",str(e))
            return {'status' : "ERROR"}


    def update_time_zone(self,session,,time_zone):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(time_zone=time_zone))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_time_zone Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_lim_crncy_code(self,session,,user_lim_crncy_code):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_lim_crncy_code=user_lim_crncy_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_lim_crncy_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_week_begins_on(self,session,,week_begins_on):
        try:
            session.query(OrgDtl).filter_by(
                org_id=self.org_id,
                
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(week_begins_on=week_begins_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_week_begins_on Error :",str(e))
            return {'status' : "ERROR"}
