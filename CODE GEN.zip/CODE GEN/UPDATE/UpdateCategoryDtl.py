from modelnew import *
class ClsUpCategoryDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_cat_cust_type(self,session,cat_id,cat_cust_type):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cat_cust_type=cat_cust_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cat_cust_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_cat_name(self,session,cat_id,cat_name):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cat_name=cat_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cat_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_cat_owner(self,session,cat_id,cat_owner):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cat_owner=cat_owner))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cat_owner Error :",str(e))
            return {'status' : "ERROR"}


    def update_cat_type(self,session,cat_id,cat_type):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cat_type=cat_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cat_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_category_color(self,session,cat_id,category_color):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(category_color=category_color))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_category_color Error :",str(e))
            return {'status' : "ERROR"}


    def update_category_img(self,session,cat_id,category_img):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(category_img=category_img))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_category_img Error :",str(e))
            return {'status' : "ERROR"}


    def update_coa_head(self,session,cat_id,coa_head):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(coa_head=coa_head))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_coa_head Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,cat_id,cust_id):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_level(self,session,cat_id,level):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(level=level))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_level Error :",str(e))
            return {'status' : "ERROR"}


    def update_parent_cat_id(self,session,cat_id,parent_cat_id):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(parent_cat_id=parent_cat_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_parent_cat_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_recurring(self,session,cat_id,recurring):
        try:
            session.query(CategoryDtl).filter_by(
                org_id=self.org_id,
                			if cat_id:
				query = query.filter(CategoryDtl.cat_id== cat_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(recurring=recurring))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_recurring Error :",str(e))
            return {'status' : "ERROR"}
