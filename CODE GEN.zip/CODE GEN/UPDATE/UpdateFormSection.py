from modelnew import *
class ClsUpFormSection:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_allowed_field_format(self,session,field_id,id,section_id,allowed_field_format):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(allowed_field_format=allowed_field_format))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_allowed_field_format Error :",str(e))
            return {'status' : "ERROR"}


    def update_condition(self,session,field_id,id,section_id,condition):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(condition=condition))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_condition Error :",str(e))
            return {'status' : "ERROR"}


    def update_default(self,session,field_id,id,section_id,default):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(default=default))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_default Error :",str(e))
            return {'status' : "ERROR"}


    def update_dependant_field_id(self,session,field_id,id,section_id,dependant_field_id):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dependant_field_id=dependant_field_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dependant_field_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_dependant_field_logic(self,session,field_id,id,section_id,dependant_field_logic):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dependant_field_logic=dependant_field_logic))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dependant_field_logic Error :",str(e))
            return {'status' : "ERROR"}


    def update_dependant_section_id(self,session,field_id,id,section_id,dependant_section_id):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dependant_section_id=dependant_section_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dependant_section_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_error_msg(self,session,field_id,id,section_id,error_msg):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(error_msg=error_msg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_error_msg Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_help_info(self,session,field_id,id,section_id,field_help_info):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_help_info=field_help_info))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_help_info Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_name(self,session,field_id,id,section_id,field_name):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_name=field_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_pattern(self,session,field_id,id,section_id,field_pattern):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_pattern=field_pattern))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_pattern Error :",str(e))
            return {'status' : "ERROR"}


    def update_field_type(self,session,field_id,id,section_id,field_type):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(field_type=field_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_field_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_data_owner(self,session,field_id,id,section_id,is_data_owner):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_data_owner=is_data_owner))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_data_owner Error :",str(e))
            return {'status' : "ERROR"}


    def update_is_mandatory(self,session,field_id,id,section_id,is_mandatory):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(is_mandatory=is_mandatory))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_is_mandatory Error :",str(e))
            return {'status' : "ERROR"}


    def update_logic_value(self,session,field_id,id,section_id,logic_value):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(logic_value=logic_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_logic_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_ocr_field(self,session,field_id,id,section_id,ocr_field):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(ocr_field=ocr_field))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_ocr_field Error :",str(e))
            return {'status' : "ERROR"}


    def update_order_id(self,session,field_id,id,section_id,order_id):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(order_id=order_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_order_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_section_identifier(self,session,field_id,id,section_id,section_identifier):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(section_identifier=section_identifier))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_section_identifier Error :",str(e))
            return {'status' : "ERROR"}


    def update_section_name(self,session,field_id,id,section_id,section_name):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(section_name=section_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_section_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_select_ref_type(self,session,field_id,id,section_id,select_ref_type):
        try:
            session.query(FormSection).filter_by(
                org_id=self.org_id,
                			if field_id:
				query = query.filter(FormSection.field_id== field_id)
			if id:
				query = query.filter(FormSection.id== id)
			if section_id:
				query = query.filter(FormSection.section_id== section_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(select_ref_type=select_ref_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_select_ref_type Error :",str(e))
            return {'status' : "ERROR"}
