from modelnew import *
class ClsUpAuthGroup:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_name(self,session,id,name):
        try:
            session.query(AuthGroup).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthGroup.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}
