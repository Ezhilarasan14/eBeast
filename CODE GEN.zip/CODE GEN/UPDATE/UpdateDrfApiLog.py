from modelnew import *
class ClsUpDrfApiLog:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_added_on(self,session,id,added_on):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(added_on=added_on))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_added_on Error :",str(e))
            return {'status' : "ERROR"}


    def update_api(self,session,id,api):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(api=api))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_api Error :",str(e))
            return {'status' : "ERROR"}


    def update_body(self,session,id,body):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(body=body))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_body Error :",str(e))
            return {'status' : "ERROR"}


    def update_client_ip_address(self,session,id,client_ip_address):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(client_ip_address=client_ip_address))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_client_ip_address Error :",str(e))
            return {'status' : "ERROR"}


    def update_execution_time(self,session,id,execution_time):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(execution_time=execution_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_execution_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_headers(self,session,id,headers):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(headers=headers))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_headers Error :",str(e))
            return {'status' : "ERROR"}


    def update_method(self,session,id,method):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(method=method))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_method Error :",str(e))
            return {'status' : "ERROR"}


    def update_response(self,session,id,response):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(response=response))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_response Error :",str(e))
            return {'status' : "ERROR"}


    def update_status_code(self,session,id,status_code):
        try:
            session.query(DrfApiLog).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DrfApiLog.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status_code=status_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status_code Error :",str(e))
            return {'status' : "ERROR"}
