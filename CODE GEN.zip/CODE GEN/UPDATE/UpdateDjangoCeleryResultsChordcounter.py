from modelnew import *
class ClsUpDjangoCeleryResultsChordcounter:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_count(self,session,id,count):
        try:
            session.query(DjangoCeleryResultsChordcounter).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsChordcounter.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(count=count))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_count Error :",str(e))
            return {'status' : "ERROR"}


    def update_group_id(self,session,id,group_id):
        try:
            session.query(DjangoCeleryResultsChordcounter).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsChordcounter.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(group_id=group_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_group_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sub_tasks(self,session,id,sub_tasks):
        try:
            session.query(DjangoCeleryResultsChordcounter).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(DjangoCeleryResultsChordcounter.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sub_tasks=sub_tasks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sub_tasks Error :",str(e))
            return {'status' : "ERROR"}
