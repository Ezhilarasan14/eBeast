from modelnew import *
class ClsUpSubDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_details(self,session,plan_id,details):
        try:
            session.query(SubDtl).filter_by(
                org_id=self.org_id,
                			if plan_id:
				query = query.filter(SubDtl.plan_id== plan_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(details=details))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_details Error :",str(e))
            return {'status' : "ERROR"}


    def update_end_date(self,session,plan_id,end_date):
        try:
            session.query(SubDtl).filter_by(
                org_id=self.org_id,
                			if plan_id:
				query = query.filter(SubDtl.plan_id== plan_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(end_date=end_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_end_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_plan_name(self,session,plan_id,plan_name):
        try:
            session.query(SubDtl).filter_by(
                org_id=self.org_id,
                			if plan_id:
				query = query.filter(SubDtl.plan_id== plan_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(plan_name=plan_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_plan_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_start_date(self,session,plan_id,start_date):
        try:
            session.query(SubDtl).filter_by(
                org_id=self.org_id,
                			if plan_id:
				query = query.filter(SubDtl.plan_id== plan_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(start_date=start_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_start_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_status(self,session,plan_id,status):
        try:
            session.query(SubDtl).filter_by(
                org_id=self.org_id,
                			if plan_id:
				query = query.filter(SubDtl.plan_id== plan_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(status=status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_status Error :",str(e))
            return {'status' : "ERROR"}
