from modelnew import *
class ClsUpYodleeProvider:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_aggregationSource(self,session,providerAccountId,providerId,aggregationSource):
        try:
            session.query(YodleeProvider).filter_by(
                org_id=self.org_id,
                			if providerAccountId:
				query = query.filter(YodleeProvider.providerAccountId== providerAccountId)
			if providerId:
				query = query.filter(YodleeProvider.providerId== providerId)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(aggregationSource=aggregationSource))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_aggregationSource Error :",str(e))
            return {'status' : "ERROR"}


    def update_requestId(self,session,providerAccountId,providerId,requestId):
        try:
            session.query(YodleeProvider).filter_by(
                org_id=self.org_id,
                			if providerAccountId:
				query = query.filter(YodleeProvider.providerAccountId== providerAccountId)
			if providerId:
				query = query.filter(YodleeProvider.providerId== providerId)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(requestId=requestId))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_requestId Error :",str(e))
            return {'status' : "ERROR"}


    def update_yodlee_status(self,session,providerAccountId,providerId,yodlee_status):
        try:
            session.query(YodleeProvider).filter_by(
                org_id=self.org_id,
                			if providerAccountId:
				query = query.filter(YodleeProvider.providerAccountId== providerAccountId)
			if providerId:
				query = query.filter(YodleeProvider.providerId== providerId)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(yodlee_status=yodlee_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_yodlee_status Error :",str(e))
            return {'status' : "ERROR"}
