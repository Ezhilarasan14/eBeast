from modelnew import *
class ClsUpAppDataVal:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_app(self,session,data_val_id,app):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app=app))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app Error :",str(e))
            return {'status' : "ERROR"}


    def update_app_id(self,session,data_val_id,app_id):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(app_id=app_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_app_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_cust_id(self,session,data_val_id,cust_id):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(cust_id=cust_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_cust_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_data_field(self,session,data_val_id,data_field):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(data_field=data_field))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_data_field Error :",str(e))
            return {'status' : "ERROR"}


    def update_data_val(self,session,data_val_id,data_val):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(data_val=data_val))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_data_val Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_code(self,session,data_val_id,doc_code):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_code=doc_code))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_code Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_id(self,session,data_val_id,doc_id):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_id=doc_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_doc_type(self,session,data_val_id,doc_type):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(doc_type=doc_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_doc_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_duplicated(self,session,data_val_id,duplicated):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(duplicated=duplicated))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_duplicated Error :",str(e))
            return {'status' : "ERROR"}


    def update_expired(self,session,data_val_id,expired):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(expired=expired))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_expired Error :",str(e))
            return {'status' : "ERROR"}


    def update_minor(self,session,data_val_id,minor):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minor=minor))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minor Error :",str(e))
            return {'status' : "ERROR"}


    def update_missing(self,session,data_val_id,missing):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(missing=missing))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_missing Error :",str(e))
            return {'status' : "ERROR"}


    def update_remarks(self,session,data_val_id,remarks):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(remarks=remarks))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_remarks Error :",str(e))
            return {'status' : "ERROR"}


    def update_sys_status(self,session,data_val_id,sys_status):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sys_status=sys_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sys_status Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_status(self,session,data_val_id,user_status):
        try:
            session.query(AppDataVal).filter_by(
                org_id=self.org_id,
                			if data_val_id:
				query = query.filter(AppDataVal.data_val_id== data_val_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_status=user_status))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_status Error :",str(e))
            return {'status' : "ERROR"}
