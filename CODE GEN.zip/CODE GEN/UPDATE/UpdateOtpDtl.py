from modelnew import *
class ClsUpOtpDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_device_id(self,session,otp_uniq_id,device_id):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_id=device_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_device_token(self,session,otp_uniq_id,device_token):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_token=device_token))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_token Error :",str(e))
            return {'status' : "ERROR"}


    def update_device_type(self,session,otp_uniq_id,device_type):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(device_type=device_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_device_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_logged_on_mode(self,session,otp_uniq_id,logged_on_mode):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(logged_on_mode=logged_on_mode))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_logged_on_mode Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_bod_date(self,session,otp_uniq_id,org_bod_date):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_bod_date=org_bod_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_bod_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_org_cls_date(self,session,otp_uniq_id,org_cls_date):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(org_cls_date=org_cls_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_org_cls_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_cre_time(self,session,otp_uniq_id,otp_cre_time):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_cre_time=otp_cre_time))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_cre_time Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_type(self,session,otp_uniq_id,otp_type):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_type=otp_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_valid_till(self,session,otp_uniq_id,otp_valid_till):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_valid_till=otp_valid_till))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_valid_till Error :",str(e))
            return {'status' : "ERROR"}


    def update_otp_value(self,session,otp_uniq_id,otp_value):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(otp_value=otp_value))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_otp_value Error :",str(e))
            return {'status' : "ERROR"}


    def update_todays_date(self,session,otp_uniq_id,todays_date):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(todays_date=todays_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_todays_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_user_id(self,session,otp_uniq_id,user_id):
        try:
            session.query(OtpDtl).filter_by(
                org_id=self.org_id,
                			if otp_uniq_id:
				query = query.filter(OtpDtl.otp_uniq_id== otp_uniq_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(user_id=user_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_user_id Error :",str(e))
            return {'status' : "ERROR"}
