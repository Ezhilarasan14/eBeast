from modelnew import *
class ClsUpPassPolicy:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_invalid_pw_atmpts(self,session,policy_id,invalid_pw_atmpts):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(invalid_pw_atmpts=invalid_pw_atmpts))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_invalid_pw_atmpts Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_pw_len(self,session,policy_id,max_pw_len):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_pw_len=max_pw_len))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_pw_len Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_dgt_cnt(self,session,policy_id,min_dgt_cnt):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_dgt_cnt=min_dgt_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_dgt_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_pw_len(self,session,policy_id,min_pw_len):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_pw_len=min_pw_len))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_pw_len Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_splchar_cnt(self,session,policy_id,min_splchar_cnt):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_splchar_cnt=min_splchar_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_splchar_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_uprcaseltr_cnt(self,session,policy_id,min_uprcaseltr_cnt):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_uprcaseltr_cnt=min_uprcaseltr_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_uprcaseltr_cnt Error :",str(e))
            return {'status' : "ERROR"}


    def update_pw_validity_days(self,session,policy_id,pw_validity_days):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pw_validity_days=pw_validity_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pw_validity_days Error :",str(e))
            return {'status' : "ERROR"}


    def update_reset_freq(self,session,policy_id,reset_freq):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reset_freq=reset_freq))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reset_freq Error :",str(e))
            return {'status' : "ERROR"}


    def update_reset_freq_duration(self,session,policy_id,reset_freq_duration):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reset_freq_duration=reset_freq_duration))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reset_freq_duration Error :",str(e))
            return {'status' : "ERROR"}


    def update_reuse_hist_cnt(self,session,policy_id,reuse_hist_cnt):
        try:
            session.query(PassPolicy).filter_by(
                org_id=self.org_id,
                			if policy_id:
				query = query.filter(PassPolicy.policy_id== policy_id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(reuse_hist_cnt=reuse_hist_cnt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_reuse_hist_cnt Error :",str(e))
            return {'status' : "ERROR"}
