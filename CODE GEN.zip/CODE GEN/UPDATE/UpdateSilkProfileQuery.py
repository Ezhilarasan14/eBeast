from modelnew import *
class ClsUpSilkProfileQuery:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_profile(self,session,id,profile):
        try:
            session.query(SilkProfileQuery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfileQuery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(profile=profile))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_profile Error :",str(e))
            return {'status' : "ERROR"}


    def update_profile_id(self,session,id,profile_id):
        try:
            session.query(SilkProfileQuery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfileQuery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(profile_id=profile_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_profile_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_sqlquery(self,session,id,sqlquery):
        try:
            session.query(SilkProfileQuery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfileQuery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sqlquery=sqlquery))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sqlquery Error :",str(e))
            return {'status' : "ERROR"}


    def update_sqlquery_id(self,session,id,sqlquery_id):
        try:
            session.query(SilkProfileQuery).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(SilkProfileQuery.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sqlquery_id=sqlquery_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sqlquery_id Error :",str(e))
            return {'status' : "ERROR"}
