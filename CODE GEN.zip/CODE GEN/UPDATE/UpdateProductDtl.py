from modelnew import *
class ClsUpProductDtl:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_acct_cls_form_name(self,session,crncy_code,finserv_id,prod_code,acct_cls_form_name):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(acct_cls_form_name=acct_cls_form_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_acct_cls_form_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_acct_opn_form_name(self,session,crncy_code,finserv_id,prod_code,acct_opn_form_name):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(acct_opn_form_name=acct_opn_form_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_acct_opn_form_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_adult_age(self,session,crncy_code,finserv_id,prod_code,adult_age):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(adult_age=adult_age))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_adult_age Error :",str(e))
            return {'status' : "ERROR"}


    def update_allowed_genders(self,session,crncy_code,finserv_id,prod_code,allowed_genders):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(allowed_genders=allowed_genders))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_allowed_genders Error :",str(e))
            return {'status' : "ERROR"}


    def update_allowed_int_freq(self,session,crncy_code,finserv_id,prod_code,allowed_int_freq):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(allowed_int_freq=allowed_int_freq))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_allowed_int_freq Error :",str(e))
            return {'status' : "ERROR"}


    def update_alt_prod_name(self,session,crncy_code,finserv_id,prod_code,alt_prod_name):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(alt_prod_name=alt_prod_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_alt_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_auto_renewal_allowed(self,session,crncy_code,finserv_id,prod_code,auto_renewal_allowed):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(auto_renewal_allowed=auto_renewal_allowed))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_auto_renewal_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def update_chq_allowed_flg(self,session,crncy_code,finserv_id,prod_code,chq_allowed_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(chq_allowed_flg=chq_allowed_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_chq_allowed_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_dr_bal_lim(self,session,crncy_code,finserv_id,prod_code,dr_bal_lim):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(dr_bal_lim=dr_bal_lim))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_dr_bal_lim Error :",str(e))
            return {'status' : "ERROR"}


    def update_grace_days(self,session,crncy_code,finserv_id,prod_code,grace_days):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(grace_days=grace_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_grace_days Error :",str(e))
            return {'status' : "ERROR"}


    def update_installment_amt(self,session,crncy_code,finserv_id,prod_code,installment_amt):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(installment_amt=installment_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_installment_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_installment_coll_mthd(self,session,crncy_code,finserv_id,prod_code,installment_coll_mthd):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(installment_coll_mthd=installment_coll_mthd))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_installment_coll_mthd Error :",str(e))
            return {'status' : "ERROR"}


    def update_installment_type(self,session,crncy_code,finserv_id,prod_code,installment_type):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(installment_type=installment_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_installment_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_int_on_bal(self,session,crncy_code,finserv_id,prod_code,int_on_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(int_on_bal=int_on_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_int_on_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_interest_rate(self,session,crncy_code,finserv_id,prod_code,interest_rate):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(interest_rate=interest_rate))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_interest_rate Error :",str(e))
            return {'status' : "ERROR"}


    def update_maturity_date(self,session,crncy_code,finserv_id,prod_code,maturity_date):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(maturity_date=maturity_date))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_maturity_date Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_cust_age(self,session,crncy_code,finserv_id,prod_code,max_cust_age):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_cust_age=max_cust_age))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_cust_age Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_num_of_withdrawal(self,session,crncy_code,finserv_id,prod_code,max_num_of_withdrawal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_num_of_withdrawal=max_num_of_withdrawal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_num_of_withdrawal Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_perd_days(self,session,crncy_code,finserv_id,prod_code,max_perd_days):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_perd_days=max_perd_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_perd_days Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_perd_mnths(self,session,crncy_code,finserv_id,prod_code,max_perd_mnths):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_perd_mnths=max_perd_mnths))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_perd_mnths Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_sanctioned_limit(self,session,crncy_code,finserv_id,prod_code,max_sanctioned_limit):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_sanctioned_limit=max_sanctioned_limit))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_sanctioned_limit Error :",str(e))
            return {'status' : "ERROR"}


    def update_max_slab_amt(self,session,crncy_code,finserv_id,prod_code,max_slab_amt):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(max_slab_amt=max_slab_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_max_slab_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_cust_age(self,session,crncy_code,finserv_id,prod_code,min_cust_age):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_cust_age=min_cust_age))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_cust_age Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_perd_days(self,session,crncy_code,finserv_id,prod_code,min_perd_days):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_perd_days=min_perd_days))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_perd_days Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_perd_mnths(self,session,crncy_code,finserv_id,prod_code,min_perd_mnths):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_perd_mnths=min_perd_mnths))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_perd_mnths Error :",str(e))
            return {'status' : "ERROR"}


    def update_min_slab_amt(self,session,crncy_code,finserv_id,prod_code,min_slab_amt):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(min_slab_amt=min_slab_amt))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_min_slab_amt Error :",str(e))
            return {'status' : "ERROR"}


    def update_minimum_bal(self,session,crncy_code,finserv_id,prod_code,minimum_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minimum_bal=minimum_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minimum_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_minimum_bal_basis(self,session,crncy_code,finserv_id,prod_code,minimum_bal_basis):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(minimum_bal_basis=minimum_bal_basis))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_minimum_bal_basis Error :",str(e))
            return {'status' : "ERROR"}


    def update_nre_only_flg(self,session,crncy_code,finserv_id,prod_code,nre_only_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(nre_only_flg=nre_only_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_nre_only_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_part_closure_allowed(self,session,crncy_code,finserv_id,prod_code,part_closure_allowed):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(part_closure_allowed=part_closure_allowed))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_part_closure_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def update_pre_closure_allowed(self,session,crncy_code,finserv_id,prod_code,pre_closure_allowed):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(pre_closure_allowed=pre_closure_allowed))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_pre_closure_allowed Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_allowed_cust(self,session,crncy_code,finserv_id,prod_code,prod_allowed_cust):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_allowed_cust=prod_allowed_cust))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_allowed_cust Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_name(self,session,crncy_code,finserv_id,prod_code,prod_name):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_name=prod_name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_name Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_nature(self,session,crncy_code,finserv_id,prod_code,prod_nature):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_nature=prod_nature))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_nature Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_sub_type(self,session,crncy_code,finserv_id,prod_code,prod_sub_type):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_sub_type=prod_sub_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_sub_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_prod_type(self,session,crncy_code,finserv_id,prod_code,prod_type):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(prod_type=prod_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_prod_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_product_img(self,session,crncy_code,finserv_id,prod_code,product_img):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(product_img=product_img))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_product_img Error :",str(e))
            return {'status' : "ERROR"}


    def update_response(self,session,crncy_code,finserv_id,prod_code,response):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(response=response))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_response Error :",str(e))
            return {'status' : "ERROR"}


    def update_sec_unsec_flg(self,session,crncy_code,finserv_id,prod_code,sec_unsec_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sec_unsec_flg=sec_unsec_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sec_unsec_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_set_id(self,session,crncy_code,finserv_id,prod_code,set_id):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(set_id=set_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_set_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_staff_only_flg(self,session,crncy_code,finserv_id,prod_code,staff_only_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(staff_only_flg=staff_only_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_staff_only_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_alwd_flg(self,session,crncy_code,finserv_id,prod_code,sweep_alwd_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_alwd_flg=sweep_alwd_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_alwd_flg Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_in_max_bal(self,session,crncy_code,finserv_id,prod_code,sweep_in_max_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_in_max_bal=sweep_in_max_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_in_max_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_in_min_bal(self,session,crncy_code,finserv_id,prod_code,sweep_in_min_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_in_min_bal=sweep_in_min_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_in_min_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_out_max_bal(self,session,crncy_code,finserv_id,prod_code,sweep_out_max_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_out_max_bal=sweep_out_max_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_out_max_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_sweep_out_min_bal(self,session,crncy_code,finserv_id,prod_code,sweep_out_min_bal):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(sweep_out_min_bal=sweep_out_min_bal))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_sweep_out_min_bal Error :",str(e))
            return {'status' : "ERROR"}


    def update_withdrawal_basis_flg(self,session,crncy_code,finserv_id,prod_code,withdrawal_basis_flg):
        try:
            session.query(ProductDtl).filter_by(
                org_id=self.org_id,
                			if crncy_code:
				query = query.filter(ProductDtl.crncy_code== crncy_code)
			if finserv_id:
				query = query.filter(ProductDtl.finserv_id== finserv_id)
			if prod_code:
				query = query.filter(ProductDtl.prod_code== prod_code)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(withdrawal_basis_flg=withdrawal_basis_flg))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_withdrawal_basis_flg Error :",str(e))
            return {'status' : "ERROR"}
