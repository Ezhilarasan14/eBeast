from modelnew import *
class ClsUpAuthPermission:
	def __init__(self,org_id):
		self.org_id=org_id
		self.entity_cre_flg='Y'
		self.del_flg='N'

    def update_codename(self,session,id,codename):
        try:
            session.query(AuthPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(codename=codename))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_codename Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type(self,session,id,content_type):
        try:
            session.query(AuthPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type=content_type))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type Error :",str(e))
            return {'status' : "ERROR"}


    def update_content_type_id(self,session,id,content_type_id):
        try:
            session.query(AuthPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(content_type_id=content_type_id))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_content_type_id Error :",str(e))
            return {'status' : "ERROR"}


    def update_name(self,session,id,name):
        try:
            session.query(AuthPermission).filter_by(
                org_id=self.org_id,
                			if id:
				query = query.filter(AuthPermission.id== id)
                entity_cre_flg=self.entity_cre_flg, 
                del_flg=self.del_flg
                ).update(dict(name=name))
            return {'status' : "SUCCESS"}
        except Exception as e:
            print(" {*} update_name Error :",str(e))
            return {'status' : "ERROR"}
