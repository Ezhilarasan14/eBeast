# simple client server

#### Note:
- Run **`server.py`** first.
- Now, run **`client.py`**.
- verify the output.
