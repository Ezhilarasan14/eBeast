#!/usr/bin/python3

import logging
import time,datetime,sys,os,pandas as pd 

from sqlalchemy import create_engine,exc,orm

def dbDisConnect(engine):
#{
	#engine.commit()
	#engine.close()

	return "SUCCESS"
#}
	
def execQry(engine,queryStmt,param):
#{
	if param:
		dataFrame = pd.read_sql(queryStmt, con=engine, params=param)
	else:
		dataFrame = pd.read_sql(queryStmt, con=engine)

	return dataFrame
#}


def execInsertQry(queryStmt,param):
#{
	engine = dbConnect()

	if not engine == "FAILURE":
		if param:
			engine.execute(queryStmt)
		else:
			engine.execute(queryStmt)

	dbDisConnect(engine)

	return

def dbConnect():
#{
	#readDBConf()
	
	engine = create_engine("mysql+pymysql://root:tocodetech@localhost/LOANPROCESS?charset=utf8?host=localhost?port=3306",echo=False)
	
	dbSession = orm.sessionmaker()
	dbSession.configure(bind=engine)

	session = dbSession()

	return engine
#}

def connectAndExec(queryStmt,param):
#{
	engine = dbConnect()

	if not engine == "FAILURE":
		outputDF = execQry(engine,queryStmt,param)

	dbDisConnect(engine)

	return outputDF
#}
