import ALGORITHM.Maths.abs as Abs
import ALGORITHM.Maths.average as Avg

def eBeast_Abs(val):
    return (Abs.getAbs(val))

def eBeast_Avg(list):
    return(Avg.getAvg(list))

val = -12
list = [2, 4, 6, 8, 20, 50, 70]
print(eBeast_Abs(val))
print("===")
print(eBeast_Avg(list))
print("===")