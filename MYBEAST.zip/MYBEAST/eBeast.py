import ALGORITHM.Maths.abs as Abs
import ALGORITHM.Maths.average as Avg
import ALGORITHM.Maths.PrimeCheck as Prime
import ALGORITHM.database.dbOperations as dbOperations

def eBeastABS(val):
    return (Abs.getAbs(val))

def eBeastAVG(list):
    return(Avg.getAvg(list))

def eBeastPrime(num):
    return(Prime.checkPrime(num))

def eBeastEntityResult():
    result = dbOperations.connectAndExec('SELECT * FROM entity_dtls','')
    return(result)


result = dbOperations.connectAndExec('SELECT * FROM entity_dtls','')
print(result)

val = -12
list = [2, 4, 6, 8, 20, 50, 70]
print(eBeastABS(val))
print("===")
print(eBeastAVG(list))
print("===")
print(eBeastPrime(7))
