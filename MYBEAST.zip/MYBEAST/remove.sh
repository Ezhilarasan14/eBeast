rm -rf OCR
rm -rf FACE
rm -rf VOICE
rm -rf SPEECH
rm -rf NLP
rm -rf CHAT

