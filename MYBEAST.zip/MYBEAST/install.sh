
python3 manage.py startapp OCR
python3 manage.py startapp FACE
python3 manage.py startapp VOICE
python3 manage.py startapp SPEECH
python3 manage.py startapp NLP
python3 manage.py startapp CHAT

