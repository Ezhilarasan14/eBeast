from django.http import HttpResponse
from django.http import JsonResponse
import datetime
import eBeast
import MYAPI.settings as settings

def isPrime(request):
    print(request.method)
    now = datetime.datetime.now()
    prime = eBeast.eBeastPrime(49)

    print(settings.BASE_DIR)

    #entity =eBeast.eBeastEntityResult()
    data = {"results": {
            "msg": 'SUCCESS',
            "created_by": '1',
            "isPrime": prime,
            #"entity":entity,
            }}
    return JsonResponse(data)
